#### 

# ***Charles Dickens***

## ***Opowieść wigilijna***

#### ***Magia Słowa***

#### 

#### ***Rozdział 1***

#### ***Duch Marleya***

#### ***Zaczęło się od tego, że Marley umarł. To nie ulegało wątpliwości. Świadectwo zgonu***

#### ***podpisali: ksiądz, urzędnik, grabarz i właściciel zakładu pogrzebowego. Scrooge, wspólnik***

#### ***Marleya, także je podpisał, a jego nazwisko było cenione, cokolwiek by podpisał. Zwłaszcza na***

#### ***giełdzie.***

#### ***Stary Marley był martwy jak ćwiek w drzwiach; tak mówi znane angielskie przysłowie.***

#### ***Czy Scrooge wiedział o śmierci Marleya? Oczywiście. Jakżeby mogło być inaczej? Scrooge i***

#### ***on byli wspólnikami przez wiele lat. Scrooge był też jedynym spadkobiercą, zarządcą,***

#### ***przyjacielem Marleya i jedynym człowiekiem, który szedł za jego trumną. Przy tym Scrooge nie***

#### ***był zbytnio dotknięty tym wypadkiem, bo okazał się doskonałym kupcem i w dniu pogrzebu***

#### ***obmyślił korzystny interes.***

#### ***Scrooge nie kazał zamalować nazwiska starego Marleya na szyldzie swego domu handlowego.***

#### ***Jeszcze po wielu latach na szyldzie nad drzwiami wejściowymi ich firmy można było czytać:***

#### ***„Scrooge i Marley”. Firma ta bowiem była znana powszechnie. Nowicjusze w sprawach***

#### ***handlowych zwracali się do Scrooge’a – Scrooge albo Marley, on zaś odpowiadał na obydwa***

#### ***nazwiska. Było mu wyraźnie wszystko jedno.***

#### ***Trzeba też przyznać, że Scrooge miał silną rękę, gdy szło o interes. Chwytała ona, ściskała, ze***

#### ***skóry obdzierała swoją ofiarę, nie wypuszczając jej, aż po doszczętnym wyzyskaniu. Był to***

#### ***jednym słowem chciwy i stary grzesznik. Twardy i ostry jak krzemień; zamknięty w sobie,***

#### ***milczący i samotny jak ostryga. Zimno wewnętrzne wyostrzyło jego starcze rysy, wydłużyło nos,***

#### ***zmarszczyło policzki, uczyniło jego chód sztywnym, zaczerwieniało oczy i zabarwiało na***

#### ***niebiesko usta. Gniewnie brzmiał jego ostry głos. Szron pokrywał jego głowę, brwi i chudą***

#### ***brodę. Wnosił ze sobą lodowatą temperaturę; zamrażał nią swe biuro podczas upału i nie***

#### ***podwyższał jej ani o jeden stopień nawet podczas wigilii Bożego Narodzenia.***

#### ***Zmiany pogody nie miały wpływu na Scrooge’a. Żadne ciepło nie mogło go ogrzać, żaden***

#### ***mróz bardziej oziębić. Niepogoda nie wiedziała, z której strony go zaatakować, największy***

#### ***deszcz, śnieg, grad czy zawierucha miały nad nim wyższość pod jednym tylko względem: one***

#### 

#### ***często okazywały się szczodrymi, spadały na świat i ludzi hojnie, dla Scrooge’a zaś takie pojęcia,***

#### ***jak szczodrość lub hojność w ogóle nie istniały.***

#### ***Nie zdarzyło się, aby ktoś z przyjaznym uśmiechem zatrzymał go na ulicy i powiedział: –***

#### ***Kochany Scrooge, jak się masz? Kiedy mnie odwiedzisz? – Żebracy nie prosili go o jałmużnę,***

#### ***dzieci nie pytały o godzinę, żadna kobieta ani mężczyzna nie pytali Scrooge’a o drogę. Nawet***

#### ***psy ślepców musiały go znać, bo gdy nadchodził – wciągały swych właścicieli do domów lub na***

#### ***podwórka, a potem machały ogonami jakby chcąc powiedzieć: „Brak oka jest lepszy od złego***

#### ***oka, mój niewidomy panie!”***

#### ***Co to obchodziło Scrooge’a? On tego właśnie pragnął. Iść samotnie przez życie, odpychać od***

#### ***siebie wszelką ludzką sympatię – to, zdawało się, wybrał Scrooge za cel i tego się trzymał***

#### ***niewzruszenie. Odstręczanie od siebie, przerażanie lodowatym chłodem spotykanych ludzi było***

#### ***dla niego tym, czym jest słodka legumina dla małych łakomczuchów.***

#### ***Pewnego razu – było to właśnie w wigilię Bożego Narodzenia – stary Scrooge siedział w***

#### ***kantorze i pracował. Dzień był przejmująco mroźny. Ludzie na ulicach chuchali w dłonie, bili***

#### ***rękoma o piersi i tupali dla rozgrzania. Zegary wybiły dopiero trzecią, a już było ciemno.***

#### ***Przez cały dzień nie widziało się słońca. W oknach sąsiednich biur migotały świece. Mgła***

#### ***wdzierała się do pomieszczeń, a była tak gęsta, że tonęły w niej domy na przeciwnej stronie***

#### ***wąskiej ulicy. Patrząc na niskie mgły, można było sądzić, że natura, rozsiadłszy się gdzieś w***

#### ***pobliżu, odbywała jakieś złowrogie praktyki.***

#### ***Drzwi biura były otwarte; Scrooge wolał mieć na oku swego pomocnika, który siedział obok***

#### ***w małej izdebce i kopiował listy. Na kominku w pobliżu Scrooge’a tlił się skromny ogień; w***

#### ***izdebce pomocnika ledwie żarzył się jeden węgielek. Zziębnięty pracownik nie mógł podsycać***

#### ***ognia, bo Scrooge trzymał skrzynię z węglem w swoim pokoju. Ile razy pomocnik wszedł z***

#### ***łopatką, pryncypał groził mu, że będą musieli się rozstać. Pomocnik owinął szyję białym***

#### ***szalikiem i usiłował ogrzać się od świecy; a ponieważ nie miał dość bujnej wyobraźni,***

#### ***usiłowania jego były bezskuteczne.***

#### ***– Wesołych świąt, wuju! Niech cię Bóg ma w swej opiece! – odezwał się sympatyczny głos.***

#### ***Był to siostrzeniec Scrooge’a, który wszedł tak nagle, że Scrooge zauważył jego obecność***

#### ***dopiero wtedy, kiedy ten do niego przemówił.***

#### ***– Cóż znowu za głupstwa?! – mruknął Scrooge.***

#### ***Siostrzeniec Scrooge’a rozgrzał się szybkim chodem i cały był rozpromieniony; piękna twarz***

#### ***jaśniała, oczy błyszczały.***

#### ***– Święta nazywasz głupstwem, wuju? – zawołał – Jestem pewny, że nie myślisz tak!***

#### ***– Przeciwnie, tak właśnie myślę – odrzekł Scrooge. – I mam rację. Wesołych świąt! Jaki ty***

#### ***masz powód, żeby być wesołym? Ty, biedaku?***

#### ***– Doskonale! – roześmiał się siostrzeniec. – A jaki ty masz powód, żeby być ponurym, wuju?***

#### ***Ty, bogacz?***

#### ***Scrooge, nie mając pod ręką odpowiedzi, powtórzył znowu:***

#### ***– Głupstwo!***

#### ***– Nie bądź taki kwaśny, wuju! – rzekł siostrzeniec.***

#### ***– Czy mogę być inny – gderał wuj – kiedy zmuszony jestem żyć w świecie głupców?***

#### ***Wesołych świąt!... Do licha z wesołymi świętami! Znać ich nie chcę! Czymże są święta Bożego***

#### ***Narodzenia dla ciebie, jeśli nie terminem płacenia rachunków, a zwykle wtedy jesteś bez grosza.***

#### ***Z każdym Bożym Narodzeniem jesteś o rok starszy, ale nie bogatszy. W ten dzień po***

#### ***sprawdzeniu ksiąg handlowych przekonujesz się, że po dwunastu miesiącach galerniczej pracy***

#### ***nie masz odrobiny zysku... Gdybym był pracodawcą, to każdy idiota, włóczący się z życzeniem***

#### 

#### ***„wesołych świąt”, zostałby ugotowany w jego świątecznej potrawie i pogrzebany z gałązką***

#### ***choinki zatkniętą w serce. To byłoby rozsądne i słuszne!***

#### ***– Wuju! – łagodnie mitygował go siostrzeniec.***

#### ***– Siostrzeńcze! – przerwał wuj surowo – święć dzień Bożego Narodzenia na swój sposób, a***

#### ***mnie pozwól obchodzić go po mojemu.***

#### ***– Obchodzić! – powtórzył siostrzeniec. – Ależ ty go wcale nie obchodzisz, wuju.***

#### ***– Dajże mi już pokój, do licha! – sarknął Scrooge. – Zobaczymy, co ci dobrego przyniosą***

#### ***tegoroczne święta. One ci zawsze dużo dobrego przynoszą!***

#### ***– Przyznaję, że wiele było sytuacji, z których mogłem wyciągnąć korzyści, a jednak nie***

#### ***wykorzystałem ich – odparł siostrzeniec. – Między innymi, święta Bożego Narodzenia! Mimo to***

#### ***zawsze myślę o nich nie tylko jak o czcigodnej pamiątce dla całego chrześcijańskiego świata, ale***

#### ***także jak o chwilach bardzo upragnionych. Są to bowiem chwile dobre, pokrzepiające, radosne.***

#### ***Zawsze oczekuję ich z serdecznym pragnieniem i obchodzę z radością. Są to w długim***

#### ***kalendarzu rocznym jedyne dnie, w których wszyscy, kobiety i mężczyźni, jakby na podstawie***

#### ***wspólnej ugody, otwierają swe często zaryglowane serca i myślą o biedniejszych bliźnich. I***

#### ***dlatego, wuju, choć święta te nigdy nie wzbogaciły mnie ani o ziarnko srebra czy złota, wierzę,***

#### ***że przyniosły mi niejedno dobro i jeszcze przyniosą mi wiele radości. Dlatego też chwalę je.***

#### ***Pomocnik Scrooge’a, ślęczący nad robotą w sąsiedniej izdebce, gorąco przyklasnął tym***

#### ***słowom, spostrzegłszy jednak niewłaściwość swego entuzjazmu, zaczął drętwymi z zimna***

#### ***palcami poprawiać ogień na swym kominku. W efekcie zgasił ostatnią iskierkę.***

#### ***– A to co znów za moda odrywania się od pracy i wtrącania się tam, gdzie nie potrzeba? –***

#### ***zgromił go ostro Scrooge. – Odezwij się pan choć słówkiem jeszcze, a upamiętnię ci dzień***

#### ***Bożego Narodzenia dymisją... Jesteś nie lada mówcą – dodał, zwracając się do siostrzeńca. –***

#### ***Dziwi mnie, dlaczego dotychczas nie zasiadasz w parlamencie.***

#### ***– Nie gniewaj się, wuju! Przyjdź do nas jutro na obiad.***

#### ***Scrooge odpowiedział z ironią, że z pewnością przyjdzie i że zaraz zaczyna się szykować. Nie***

#### ***ma nic lepszego do roboty. Siostrzeniec zrozumiał, że była to stanowcza odmowa. Zapytał więc***

#### ***łagodnie:***

#### ***– Dlaczego odmawiasz, wuju?***

#### ***– A dlaczego ożeniłeś się?***

#### ***– Ponieważ pokochałem!***

#### ***– Ponieważ po-ko-cha-łeś! – powtórzył Scrooge, przedrzeźniając go w ten sposób, jak gdyby***

#### ***miłość i małżeństwo były największym na świecie głupstwem po Bożym Narodzeniu. – Bywajże***

#### ***mi zdrów, drogi siostrzeńcze!***

#### ***– Lecz ty, wuju, nigdy nie odwiedziłeś mnie także przed ożenkiem. Dlaczegóż więc podajesz***

#### ***to obecnie za powód odmowy?***

#### ***– Bądź zdrów! – powtórzył Scrooge.***

#### ***– Niczego od ciebie nie potrzebuję i o nic cię nie proszę, dlaczegóż więc nie możemy być***

#### ***przyjaciółmi?***

#### ***– Bądź zdrów! - mruknął Scrooge.***

#### ***– Przykro mi bardzo, żeś taki twardy. Nigdy nie mieliśmy żadnego konfliktu, do którego ja***

#### ***dałbym powód. Trudno! Uczyniłem propozycję ze względu na Boże Narodzenie, a chociaż mi się***

#### ***nie udała, zachowam pogodny i radosny nastrój. Zatem wesołych świąt, wuju!***

#### ***– Bądź zdrów! – znów powtórzył Scrooge.***

#### ***– I pomyślności z Nowym Rokiem!***

#### ***– Bądźże zdrów i odczep się ode mnie! – zamruczał groźnie Scrooge. Siostrzeniec opuścił***

#### ***wuja. Przy drzwiach zatrzymał się, aby złożyć życzenia pomocnikowi, który – choć***

#### 

#### ***przemarznięty do kości – okazał się cieplejszy od pryncypała, odpowiadając na życzenia***

#### ***uprzejmie i serdecznie.***

#### ***– Macie drugiego idiotę! – mruczał Scrooge, słysząc wymianę życzeń. – Mój pomocnik,***

#### ***obarczony rodziną i zarabiający piętnaście szylingów tygodniowo na jej utrzymanie, mówi o***

#### ***„wesołych świętach”! Komuś tu chyba potrzebny szpital wariatów!***

#### ***Pomocnik, odprowadziwszy do drzwi siostrzeńca Scrooge’a, wpuścił jakichś dwóch***

#### ***jegomościów. Byli to poważni obywatele, o przyjemnej powierzchowności; zdjąwszy kapelusze,***

#### ***stanęli przy biurku Scrooge’a. Trzymając w rękach portfele i papiery, skłonili się uprzejmie.***

#### ***– Firma Scrooge i Marley, jeżeli się nie mylę? – zapytał jeden z nich, zaglądając do swej listy.***

#### ***– Czy mam przyjemność mówić z panem Scrooge, czy z panem Marleyem?***

#### ***– Pan Marley umarł już siedem lat temu – odparł Scrooge.***

#### ***– Nie wątpimy, że jego następca jest równie jak on hojny i szczodrobliwy – powiedział gość,***

#### ***przedstawiając swoje pełnomocnictwo do zbierania ofiar dla biednych.***

#### ***Zaiste, Scrooge i Marley były to „dwie bliźniacze dusze”. Słysząc niemiły wyraz***

#### ***„szczodrobliwość”, Scrooge zmarszczył brwi, potrząsnął głową i zwrócił dokumenty.***

#### ***– Z okazji tak wielkiej uroczystości, panie Scrooge – mówił ów jegomość, nie zważając na to i***

#### ***ujmując pióro – ludzie zamożniejsi nie uchylają się od wsparcia nędzarzy i wydziedziczonych,***

#### ***którzy teraz właśnie, podczas silnych mrozów, narażeni są na wielkie cierpienia. Jest zresztą***

#### ***zwykłym obowiązkiem zamożnych, aby przychodzić z pomocą bliźnim pozbawionym***

#### ***jakichkolwiek środków do życia...***

#### ***– Alboż to nie ma więzień? - przerwał mu Scrooge.***

#### ***– Niestety, mamy ich bardzo wiele! – odparł jegomość, odkładając na bok pióro.***

#### ***– A przytułki, domy pracy i domy poprawcze, czy te instytucje przestały istnieć? – zapytał***

#### ***znów Scrooge.***

#### ***– I one, oczywiście, istnieją, chociaż należy pragnąć, żeby się stały niepotrzebne.***

#### ***– A zatem wszystkie te instytucje istnieją i są czynne? – badał gościa w dalszym ciągu***

#### ***Scrooge.***

#### ***– Są czynne bez przerwy – brzmiała odpowiedź.***

#### ***– Chwała Bogu! Pańskie żądanie i to, co pan na wstępie powiedział, wzbudziło we mnie***

#### ***obawę, że coś wstrzymało ich użyteczną działalność. Bardzo mnie cieszy, że tak nie jest.***

#### ***– Ponieważ powszechnie wiadomo, że wspomniane instytucje, pomimo usilnych zabiegów,***

#### ***nie są w stanie po chrześcijańsku zaspokoić ani duchowych, ani cielesnych potrzeb wszystkich***

#### ***biedaków, przychodzimy im z pomocą, zbierając ofiary na dostarczenie chociaż najbiedniejszym***

#### ***jadła, napojów i środków do ogrzania zlodowaciałych mieszkań. Wybieramy ten czas, ponieważ***

#### ***w tak wielkie święta bieda najwięcej daje się we znaki; zamożni zaś najwięcej się radują i***

#### ***używają sobie. Na jaką sumę mam pana zapisać?***

#### ***– Proszę mnie wcale nie zapisywać – odpowiedział Scrooge.***

#### ***– Rozumiem. Życzy pan sobie pozostać ofiarodawcą bezimiennym?***

#### ***– Życzę sobie, aby mnie zostawiono w spokoju – rzekł Scrooge. – Skoro mnie panowie***

#### ***pytacie o moje zapatrywania, oto jest odpowiedź: nie cieszę się ani też nie używam sobie podczas***

#### ***świąt Bożego Narodzenia i nie stać mnie na to, abym przyczyniał się do wesołości i używania***

#### ***próżniaków. Wspieram instytucje, o których wspomniałem; niech tam więc udadzą się ci, którym***

#### ***nie jest dobrze we własnych domach.***

#### ***– Wielu nie może się tam dostać, a wielu wolałoby raczej umrzeć, niż tam się znaleźć –***

#### ***zauważył jegomość.***

#### 

#### ***– Skoro wielu wolałoby raczej umrzeć – odparł Scrooge – niechże to uczynią i w ten sposób***

#### ***zmniejszą nadmiar ludności. Zresztą, proszę wybaczyć, ja się na tych sprawach nie znam i w***

#### ***ogóle mało mnie one obchodzą.***

#### ***– Może się pan z nimi łatwo zapoznać, trzeba tylko trochę serca i dobrej woli.***

#### ***– Ani myślę, to nie mój interes. Wystarczy, jeżeli człowiek zna i rozumie własny interes i nie***

#### ***miesza się do cudzego. Mój pochłania mnie całkowicie. Zatem mam honor pożegnać***

#### ***szanownych panów.***

#### ***Mężczyźni, widząc że nic nie wskórają, wzruszyli ramionami i wyszli. Scrooge zaś zabrał się***

#### ***do pracy, w znacznie lepszym niż zazwyczaj nastroju.***

#### ***Tymczasem mgła i ciemność jeszcze bardziej zgęstniały; na ulicach ludzie biegli z zapalonymi***

#### ***latarniami przed ciągnącymi powozy końmi, aby szły po właściwej drodze. Zabytkowa wieża***

#### ***kościoła, z której gotyckiego okna ciekawie spoglądał na Scrooge’a stary, uszkodzony dzwon,***

#### ***zniknęła. Dzwon wybijał teraz godziny oraz kwadranse wśród mgły z tak silnymi drganiami, jak***

#### ***gdyby mu zęby szczękały z zimna.***

#### ***Mróz bowiem z każdą chwilą się wzmagał.***

#### ***Na rogu głównej ulicy robotnicy, naprawiający rury gazowe, rozpalili wielkie ognisko, wokół***

#### ***którego zebrała się gromadka obdartych mężczyzn i dzieci; grzali oni swe skostniałe ręce i***

#### ***mrużyli oczy, rozkoszując się przyjemnym ciepłem. Ponieważ kranu wodociągowego nie***

#### ***zamknięto, przeto wypływająca z niego woda krzepła, tworząc ponure kręgi lodu. Wystawy***

#### ***sklepów zdobiły gałązki jodły. Lampy oświecały blade twarze przechodniów. Składy drobiu i***

#### ***żywności urządziły tak wspaniałe wystawy, że zdawało się, iż przyziemna myśl kupna, sprzedaży***

#### ***i targu nie ma z nimi nic wspólnego.***

#### ***Lord Major, burmistrz Londynu, w swoim pałacu wydawał rozkazy pięćdziesięciu kucharzom***

#### ***i piwniczym, aby odpowiednio przystroili stół świąteczny, jak na dom takiego dygnitarza***

#### ***przystało. Nawet skromny krawiec, którego przed tygodniem skazano na pięć szylingów kary za***

#### ***pijaństwo i awanturę na ulicy, dał żonie kilka szylingów: wyszła ona z wychudłym dzieckiem po***

#### ***sprawunki do miasta.***

#### ***Mgła i mrok zwiększały się. Zimno przejmowało do szpiku kości.***

#### ***Pewien młody właściciel chudego nosa pochylił się przy dziurce od klucza do drzwi***

#### ***wejściowych kantoru Scrooge’a, aby przedstawiciela firmy uraczyć świąteczną pieśnią; lecz***

#### ***zaledwie zdążył wyśpiewać pierwsze wyrazy:***

#### ***„Niech Ci nic nie zamąci radości...”,***

#### ***gdy Scrooge pochwycił linię tak groźnym ruchem, że biedak przerażony uciekł.***

#### ***Wreszcie nadeszła godzina zamknięcia kantoru.***

#### ***Scrooge z niechęcią opuścił swój stołek i w milczeniu dał znak pomocnikowi, który***

#### ***natychmiast zgasił świecę i włożył kapelusz na głowę.***

#### ***– Sądzę, że pan życzy sobie być wolny przez cały dzień jutrzejszy? – zapytał Scrooge.***

#### ***– Jeśli pan uważa za właściwe... – szepnął nieśmiało pomocnik.***

#### ***– Ja nie uważam tego za właściwe. Jestem też pewny, że gdybym potrącił panu z pensji***

#### ***należność za ten dzień, poczułby się pan pokrzywdzony?***

#### ***Pomocnik uśmiechnął się łagodnie.***

#### ***– A jednak – ciągnął Scrooge – pan nawet nie pomyśli o tym, że to ja mogę się poczuć***

#### ***pokrzywdzony, płacąc panu wynagrodzenie za dzień świąteczny.***

#### ***Pomocnik zauważył lękliwie, że święto Bożego Narodzenia przypada raz do roku.***

#### ***– Liche to usprawiedliwienie okradania kieszeni swego pracodawcy – zrzędził Scrooge,***

#### ***zapinając palto aż pod brodę. – Mniejsza z tym. Ważniejsze jest to, żeby pan, zmarnowawszy na***

#### ***próżniactwie cały jutrzejszy dzień, przyszedł do pracy wcześniej dnia następnego.***

#### 

#### ***Pomocnik przyrzekł zastosować się do żądania, po czym Scrooge wyszedł, wciąż mrucząc***

#### ***gderliwie.***

#### ***Kantor został zamknięty w mgnieniu oka i pomocnik, otuliwszy szyję białym, długim***

#### ***szalikiem (biedak nie miał palta...), wesoło wybiegł na ulicę. Chcąc uczcić wieczór wigilijny,***

#### ***przejechał się ze dwadzieścia razy po lodzie na Cornhill, następnie szybko popędził do domu***

#### ***przy Camden Town, aby się jeszcze zabawić z dziećmi w „ciuciubabkę”.***

#### ***Scrooge spożył skromny obiad w lichej garkuchni, do której codziennie uczęszczał, przeczytał***

#### ***znajdujące się tam dzienniki, po czym udał się do domu.***

#### ***Zajmował lokal, w którym ongiś mieszkał jego zmarły wspólnik. Składał się on z szeregu***

#### ***ponurych i pustych pokojów; mieścił się w starym, ciemnym budynku, wznoszącym się przy***

#### ***końcu głuchego zaułka. Wielki dom nie harmonizował z wąską i krótką uliczką. Robił wrażenie,***

#### ***jakby znalazł się tu przypadkowo, bawiąc się w czasie swej młodości z innymi domami w***

#### ***„chowanego”, a zapomniawszy drogi powrotnej – pozostał tu na zawsze.***

#### ***Dziś był stary i ponury. Oprócz Scrooge’a nikt w nim nie mieszkał. Reszta lokali była***

#### ***wynajęta na biura i kantory. Dziedziniec domu był tak ciemny, że nawet Scrooge, który znał***

#### ***każdy kamień, przechodził go po omacku. Mgła i szron osnuły czarną bramę tak szczelnie, iż***

#### ***zdawało się, że to duch smutku usiadł na jej progu.***

#### ***Przy furtce tej bramy wisiała wielka kołatka. Scrooge widywał ją każdego dnia rano i***

#### ***wieczorem, podczas swego długoletniego zamieszkiwania w tym domu, Pewne jest, iż posiadał***

#### ***tak mało fantazji, jak może żaden człowiek w Londynie, nie wyłączając nawet członków***

#### ***Parlamentu i Rady Miejskiej. Można też śmiało powiedzieć, że Scrooge nie pomyślał o Marleyu***

#### ***ani przez chwilę do czasu, kiedy wspomniał o jego śmierci tegoż popołudnia. Jak to się więc***

#### ***stało, że Scrooge, wsunąwszy klucz w zamek drzwi, zamiast kołatki zobaczył twarz Marleya...***

#### ***Tak, to była twarz zmarłego Marleya.***

#### ***Otaczało ją słabe światło, które zdawało się z niej promieniować. Nie miała ona ani groźnego,***

#### ***ani przerażającego wyrazu, spoglądała na Scrooge’a tak, jak zwykle spoglądał Marley na niego***

#### ***za życia: podniósłszy okulary na czoło. Włosy jego były dziwnie zmierzwione, jakby***

#### ***gwałtownym wichrem lub silnym strumieniem pary, a oczy, choć szeroko otwarte, były martwe,***

#### ***co, w połączeniu z szarą barwą skóry, czyniło tę twarz odrażającą. Zdawało się jednak, że***

#### ***przerażenie, jakie budził jej widok, pochodziło nie z samej twarzy, lecz wywoływał je jakiś inny,***

#### ***niezwykły powód.***

#### ***Gdy Scrooge zaczął się uważniej przypatrywać, zjawa zniknęła i pozostała tylko znana mu***

#### ***dobrze kołatka.***

#### ***Mijalibyśmy się z prawdą sądząc, że Scrooge nie był tym zjawiskiem wstrząśnięty i że nie***

#### ***doznał uczucia przerażenia, obcego mu od dzieciństwa. Lecz rychło się opanował, ujął za klucz,***

#### ***który przed chwilą puścił, obrócił go śmiało, wszedł do sieni i zapalił świecę.***

#### ***Zatrzymał się chwilę w niepewności, zanim zamknął drzwi, i najpierw obejrzał się uważnie***

#### ***poza siebie, jak gdyby obawiał się ujrzeć tył głowy Marleya. Lecz na tylnej stronie drzwi nie***

#### ***było nic, prócz śrub i gwoździ, utrzymujących kołatkę; mruknął więc coś niezrozumiale i***

#### ***zatrzasnął drzwi.***

#### ***Nagle rozległ się w domu trzask podobny do grzmotu. Każdy pokój na piętrze i każda beczka***

#### ***w piwnicy zdawały się odpowiadać mu echem. Scrooge nie był człowiekiem, którego podobne***

#### ***głosy mogły zatrwożyć. Zaryglował więc drzwi i przeszedł spokojnie przez sień; idąc na górę po***

#### ***schodach, posuwał się bardzo wolno oświetlając drogę świecą.***

#### ***Może ktoś wyobraża sobie, że były to wspaniałe schody z dawnych czasów, gdzie łatwo by się***

#### ***zmieściła kareta, zaprzężona w szóstkę koni. Otóż schody, prowadzące do mieszkania Scrooge’a***

#### ***były jeszcze szersze. Zmieściłby się na nich nawet karawan i jeszcze zostałoby sporo miejsca.***

#### 

#### ***Pół tuzina ulicznych lamp gazowych nie oświetliłoby dostatecznie tych schodów, można więc***

#### ***przypuszczać, że przy jednej mdłej świeczce, którą Scrooge sobie przyświecał, było dosyć***

#### ***ciemno i ponuro.***

#### ***Szedł jednak na górę, nic sobie z tego nie robiąc. Ciemność jest tania, a to było słabą stroną***

#### ***Scrooge’a. Znalazłszy się w mieszkaniu, przeszedł się po pokojach dla stwierdzenia, czy***

#### ***wszystko jest w porządku. Być może tajemnicze przeistoczenie się kołatki skłoniło go do***

#### ***ostrożności.***

#### ***Bawialnię, jadalnię, sypialnię, schowek – znalazł w zupełnym porządku. Nikogo pod stołem,***

#### ***nikogo pod sofą; mały ogień na kominku, na stole talerz i łyżka, mały rondelek z kleikiem***

#### ***(Scrooge dostał z przeziębienia kataru) na maszynce kuchennej. Nikogo pod łóżkiem, nikogo w***

#### ***komórce, nikogo w szlafroku, wiszącym na ścianie. W schowku też nic osobliwego: stare***

#### ***obuwie, dwa kosze na ryby, dwie zdarte szczotki, umywalnia na trzech nogach i pogrzebacz.***

#### ***Scrooge, uspokojony, zamknął drzwi na dwa spusty, co nie było jego zwyczajem i tak***

#### ***ubezpieczywszy się od możliwych niespodzianek, zdjął chustkę z szyi, włożył szlafrok, pantofle i***

#### ***czepek, po czym usiadł przed kominkiem, zabierając się do spożycia kleiku.***

#### ***Szczerze mówiąc, ogień na kominku był marny, zgoła niewystarczający na tak mroźną***

#### ***pogodę. Scrooge musiał przysunąć się blisko i długo czekać, zanim uczuł nieco ciepła ze***

#### ***skromnej garstki paliwa.***

#### ***Kominek był stary, zbudowany dawno temu przez jakiegoś holenderskiego kupca i wyłożony***

#### ***dziwacznymi flamandzkimi kaflami, przedstawiającymi różne sceny z Pisma Świętego. Był tam***

#### ***Kain i Abel, córki faraona, królowa Saba, anielscy posłańcy, zstępujący z nieba po schodach z***

#### ***obłoków. Był też Abraham, Baltazar i apostołowie, wybierający się na morze w łodziach o***

#### ***kształcie sosjerek; wreszcie setki innych postaci, mogących zająć uwagę Scrooge’a. A jednak to***

#### ***twarz Marleya zjawiła się przed jego oczyma, zasłaniając sobą wszystko. Gdyby wszystkie kafle***

#### ***kominka były czyste i gdyby posiadały właściwość pokrywania się obrazami bezładnych myśli***

#### ***Scrooge’a, wówczas na każdym z nich zjawiłaby się podobizna zmarłego wspólnika.***

#### ***– Głupstwo! – mruknął Scrooge i, machnąwszy ręką, zaczął się przechadzać po pokoju.***

#### ***Po pewnym czasie znowu usiadł.***

#### ***Oparłszy głowę o poręcz krzesła, spojrzał przypadkiem na dzwonek, łączący pokój, w którym***

#### ***Scrooge teraz siedział, z pokojem na najwyższym piętrze domu, od dawna opuszczonym.***

#### ***Spojrzawszy osłupiał, spostrzegł bowiem, że dzwonek zaczyna się poruszać. Z początku poruszał***

#### ***się tak wolno, że ledwie go było słychać; wkrótce jednak zabrzmiał głośno, a jakby na hasło***

#### ***odpowiedziały mu wszystkie dzwonki w całym domu.***

#### ***Trwało to wszystko może pół minuty, ale ta krótka chwila wydała się Scrooge’owi***

#### ***nieskończenie długa. Naraz dzwonki ucichły jednocześnie. Potem, wśród grobowej ciszy, gdzieś***

#### ***w piwnicy odezwało się przytłumione brzęczenie i łoskot, jak gdyby ktoś wlókł ciężkie łańcuchy***

#### ***po beczkach z winem. Wtedy Scrooge przypomniał sobie, że duchy zwykle zjawiają się wlokąc***

#### ***za sobą łańcuchy.***

#### ***Nagle drzwi piwnicy otworzyły się z głośnym hukiem i Scrooge usłyszał głośniejsze***

#### ***brzęczenie; wyszło ono z piwnicy, powoli wstępowało po schodach, a wreszcie zatrzymało się***

#### ***przy drzwiach jego pokoju.***

#### ***– Ależ to głupstwo! – mruczał Scrooge. – Nie wierzę, żeby to była rzeczywistość.***

#### ***W tej chwili pobladł z przerażenia, gdyż to coś brzęczącego, nie otwierając drzwi, weszło do***

#### ***pokoju i posuwało się z wolna ku niemu. Zamierający płomień na kominku wyciągnął się,***

#### ***zajaśniał, jakby mówiąc:***

#### ***– Poznaję go, to duch Marleya!***

#### ***Po czym znów wygasł.***

#### 

#### ***Tak, to był on. Ta sama twarz. Ubrany był tak, jak się zwykle ubierał Marley. Ta sama***

#### ***kamizelka, te same spodnie, buty i surdut; chwasty przy butach dziwnie były najeżone, jak***

#### ***również warkocz peruki i włosy na głowie.***

#### ***Widmo wlokło za sobą długi łańcuch, który obejmował je w pasie i obwijał jeszcze***

#### ***kilkakrotnie; był on utworzony (Scrooge dobrze mu się przypatrzył) z kas metalowych, kluczy i***

#### ***zamków, ksiąg kupieckich oraz mocnych, stalowych sakiewek. Cala postać widma była tak***

#### ***przezroczysta, że Scrooge widział przez nią dwa guziki na tyle surduta.***

#### ***Scrooge często słyszał, jak mówiono, że Marley nie miał serca ani żadnych wnętrzności, ale***

#### ***nigdy w to nie wierzył.***

#### ***I teraz jeszcze nie wierzył, chociaż widział zjawę tuż przed sobą i czuł lodowaty chłód jej***

#### ***martwych oczu. Dziwnie zainteresował go gatunek płótna chustki, którą obwiązana była jak***

#### ***bandażem twarz widma, czego Marley za życia nie robił. Wciąż jeszcze nie wierzył w to, co***

#### ***widział i usiłował przeczyć swoim zmysłom.***

#### ***– Co to znaczy? – zapytał wreszcie swoim zwykłym, mrukliwym tonem. – Czego chcesz ode***

#### ***mnie?***

#### ***– Wiele! Bardzo wiele! – odparło widmo.***

#### ***Głos był Marleya; nie można było w to wątpić.***

#### ***– Kim jesteś?***

#### ***– Zapytaj raczej: kim byłem – zabrzmiała głucha, przytłumiona odpowiedź.***

#### ***– Kimże więc byłeś? – zapytał Scrooge, podnosząc głos. – Jak na ducha, jesteś bardzo***

#### ***drobiazgowy.***

#### ***– Za życia byłem twoim wspólnikiem, Jakubem Marleyem.***

#### ***– Czy możesz... czy chcesz usiąść? – zapytał Scrooge, nie wierząc własnym uszom.***

#### ***– Mogę.***

#### ***– Uczyń to więc.***

#### ***Scrooge zapytał o to, gdyż nie był pewny, czy istota tak przejrzysta może usiąść na krześle.***

#### ***Lecz duch usiadł po przeciwnej stronie kominka tak spokojnie i z taką swobodą, jak gdyby to***

#### ***było dla niego rzeczą najzwyklejszą.***

#### ***– Widocznie nie wierzysz we mnie? – zagadnął duch po chwili.***

#### ***– Nie wierzę – odpowiedział Scrooge.***

#### ***– Jakiego pragniesz dowodu mego istnienia, oprócz twoich własnych zmysłów?***

#### ***– Nie wiem.***

#### ***– Dlaczego nie ufasz swoim zmysłom?***

#### ***– Ponieważ często błahostka wyprowadza je z równowagi. Lekka niedyspozycja żołądka***

#### ***zmienia je. Pomimo wszystko, wydajesz mi się raczej istotą cielesną a nie duchem.***

#### ***Scrooge nigdy nie miał skłonności do żartów, a w tej chwili bardziej jeszcze niż kiedykolwiek***

#### ***był daleki od tego. Jeżeli usiłował być dowcipny, to dlatego, by zmienić kierunek swych myśli i***

#### ***opanować coraz silniej przejmujący go strach.***

#### ***Scrooge czuł, że tak siedzieć i patrzeć w martwe oczy widma nie może, doznawał bowiem***

#### ***piekielnych udręk. Istotnie, coś piekielnego było w atmosferze otaczającej widmo. Chociaż duch***

#### ***siedział całkiem nieruchomo, jego włosy, poły surduta i chwasty przy butach wciąż się poruszały,***

#### ***jakby pod wpływem gorącego powietrza wydobywającego się z rozpalonego pieca.***

#### ***– Widzisz tę wykałaczkę? – zapytał Scrooge, usiłując otrząsnąć się z ogarniającego go coraz***

#### ***silniej przerażenia oraz odwrócić od siebie, choćby na chwilę, lodowaty wzrok widma.***

#### ***– Widzę – odparł duch.***

#### ***– Ale nie patrzysz na nią – podchwycił Scrooge.***

#### ***– Mimo to widzę ją – rzekł duch.***

#### 

#### ***– Och! – roześmiał się z przymusem Scrooge – wystarczy mi połknąć ją, abym przez resztę***

#### ***mych dni, do końca życia, był prześladowany przez legion złych duchów mojej własnej***

#### ***fabrykacji... Głupstwo, powtarzam! Wierutne, kapitalne głupstwo!***

#### ***Zaledwie Scrooge wymówił te słowa, duch zajęczał i zatrząsł łańcuchami w tak ponury i***

#### ***przerażający sposób, że Scrooge przycisnął się do krzesła, aby nie upaść na ziemię ze strachu.***

#### ***Przerażenie jego doszło do najwyższego stopnia, gdy widmo zdjęło bandaż z głowy, jakby mu***

#### ***było za ciepło w pokoju, a jego dolna szczęka opadła aż na piersi.***

#### ***Scrooge upadł na kolana i zasłonił twarz dłońmi.***

#### ***– Litości – zawołał. – Straszna zjawo, dlaczego mnie dręczysz?!***

#### ***– Człowieku o nędznym duchu, zaprzątniętym jedynie marnymi sprawami ziemskimi,***

#### ***wierzysz we mnie, czy nie?***

#### ***– Wierzę! – westchnął Scrooge. – Muszę wierzyć. Powiedz mi jednak, dlaczego duchy włóczą***

#### ***się po świecie? Dlaczego przychodzisz mnie męczyć?***

#### ***– Obowiązkiem każdego człowieka jest – odparło widmo – aby jego dusza zjednoczyła się z***

#### ***duszą jego bliźnich i pozostawała w braterskiej z nimi łączności przez cały czas wędrówki***

#### ***ziemskiej. Ten, który obowiązku tego zaniedbał za życia, musi go wypełnić po śmierci. Duch***

#### ***jego po śmierci musi wędrować po świecie – och, biada mi! – i patrzeć biernie na to wszystko,***

#### ***czego nie może już używać, a co mógł czynić za życia ku swej radości i szczęściu!***

#### ***To rzekłszy, widmo znów wydało jęk i wstrząsnęło łańcuchami.***

#### ***– Jesteś, jak widzę, w okowach – rzekł Scrooge z drżeniem. – Powiedz mi, dlaczego?***

#### ***– Noszę łańcuch, który sobie ukułem za życia – odparł duch. – Sam przygotowałem każde***

#### ***jego ogniwo. Włożyłem go na siebie dobrowolnie, dobrowolnie nosiłem, a teraz dźwigać go***

#### ***muszę przez wieczność. Czy nie znasz materiału, z którego jest utworzony?***

#### ***Scrooge drżał coraz bardziej.***

#### ***– A może chciałbyś poznać – ciągnął dalej duch – wagę i długość łańcucha, który sam***

#### ***dźwigasz? Co? Siedem lat temu był tak ciężki i tak długi jak mój. Od tego czasu jednak***

#### ***pracowałeś usilnie, ażeby go doprowadzić do kolosalnych rozmiarów. O tak, twój łańcuch jest***

#### ***potężny!***

#### ***Scrooge obejrzał się skwapliwie, obawiając się, czy nie ujrzy dookoła siebie żelaznego***

#### ***powrozu; lecz jakoś niczego nie dostrzegł.***

#### ***– Jakubie Marley – odezwał się błagalnie – mój dobry przyjacielu, powiedz mi wszystko, co***

#### ***wiesz! Pociesz mnie, Jakubie, choć słówkiem!***

#### ***– Nie mogę – odrzekł duch. – Pociecha przychodzi z innych sfer, Ebenezerze Scrooge, i bywa***

#### ***przysyłana przez innych posłańców. Nie mogę ci też powiedzieć wszystkiego, bo wolno mi***

#### ***wyjawić niewiele. Przy tym nie rozporządzam czasem. Nie mogę nigdy odpocząć ani pozostawać***

#### ***w jednym miejscu, nie mogę też zatrzymać się nigdzie. Dusza moja za życia nigdy nie wyszła***

#### ***poza ściany naszego kantoru, nie wyjrzała poza ciasny krąg naszych marnych interesów. Wiesz o***

#### ***tym dobrze. Dlatego po śmierci zostałem skazany na nieskończoną, dręczącą wędrówkę...***

#### ***Scrooge, wpadając w zamyślenie, miał zwyczaj trzymać ręce w kieszeniach spodni. Teraz,***

#### ***rozmyślając nad słowami ducha, uczynił to samo, nie odważając się jednak podnieść oczu i wstać***

#### ***z klęczek.***

#### ***– Musiałeś się teraz bardzo spóźnić, Jakubie – zauważył tonem zatroskanego ważnym***

#### ***szczegółem finansisty.***

#### ***– To prawda! – potwierdził duch;***

#### ***– Nieżywy od siedmiu lat – szepnął Scrooge – i przez cały ten czas w podróży!***

#### ***– Przez cały ten czas – znów potakiwał duch. – Bez wytchnienia, bez odpoczynku, z***

#### ***ustawicznymi wyrzutami sumienia; niewypowiedzianie straszne tortury!***

#### 

#### ***– Jak prędko podróżujesz? – badał Scrooge.***

#### ***– Na skrzydłach wiatru.***

#### ***– Musiałeś zatem przebyć olbrzymią przestrzeń – rzekł Scrooge. Usłyszawszy to, duch jęknął***

#### ***po raz trzeci i zabrzęczał łańcuchem w głuchej ciszy nocy.***

#### ***– O! ja nieszczęsny, podwójnie ujarzmiony niewolnik! – wyrzekał. – Nie wiedziałem, iż wieki***

#### ***nieustannej pracy, dokonywanej przez nieśmiertelne istoty dla tej ziemi, muszą zlać się z***

#### ***wiecznością, nim zamierzone dobro zostanie osiągnięte... Nie wiedziałem, że każdy człowiek***

#### ***powinien ofiarować część swej pracy dla wielkiego dzieła ludzkości, współdziałać w***

#### ***doskonaleniu go. Nie wiedziałem, że żaden żal, nawet najgłębszy, nie może być***

#### ***zadośćuczynieniem za źle spędzone życie, nie może okupić jednego nawet ominięcia***

#### ***sposobności spełnienia dobrego uczynku! A ja właśnie tym grzeszyłem! Ja właśnie byłem taki za***

#### ***życia!***

#### ***– Przecież ty, Jakubie, byłeś zawsze uczciwym i dobrym pracownikiem... – bąknął Scrooge,***

#### ***myśląc też o sobie – zawsze sumiennie pilnowałeś interesu...***

#### ***– Interes! – przerwał duch, załamując ręce. – To właśnie było moim błędem, i grzechem!***

#### ***Ludzkość powinna była być moim interesem; dobroczynność, litość, wyrozumiałość i łagodność***

#### ***powinny były być dla mnie najważniejsze. Sprawy osobiste, handel, wszelkiego rodzaju***

#### ***spekulacje – to wszystko należało uważać za rzecz drugorzędną, za znikomą kroplę w oceanie***

#### ***obowiązków dla dobra ludzkości.***

#### ***Przy tych słowach, jak gdyby chcąc dosadniej wyrazić bezowocność swej spóźnionej skruchy,***

#### ***podniósł wysoko rękę z łańcuchem i z zamachem opuścił ją po chwili.***

#### ***– W tej porze roku – podjął znowu – cierpię najbardziej. Za życia szedłem przez tłumy swych***

#### ***bliźnich z oczyma zwróconymi w dół, zajęty własnymi marnymi sprawami, nie podnosząc***

#### ***wzroku ku niebiosom, gdzie błyszczy gwiazda betlejemska. Czy nie było dosyć ubogich***

#### ***domostw, do których byłaby mnie zawiodła?!***

#### ***Scrooge był przerażony, słysząc przemawiającego w ten sposób Marleya.***

#### ***– Słuchaj mnie – zawołał duch. – Czas mój prawie już upłynął.***

#### ***– Owszem, słucham cię z uwagą – rzekł Scrooge. – Ale, Jakubie, nie bądź za srogi dla mnie!***

#### ***Nie bądź też, Jakubie, tak kwiecisty, powiedz krótko i węzłowato, o co ci chodzi?***

#### ***– W jaki sposób staję przed tobą w tej postaci nie wolno mi powiedzieć. Często zbliżałem się***

#### ***do ciebie niewidzialny, bardzo często...***

#### ***Ta niemiła wiadomość sprowadziła na czoło Scrooge’a kroplisty pot. – Zapewniam cię, że nie***

#### ***jest to lekka część mej kary – ciągnął duch. – Przyszedłem, aby cię ostrzec i zawiadomić, że***

#### ***możesz jeszcze uniknąć mego losu. Sposobność ku temu ja ci nastręczę, Ebenezerze.***

#### ***– Zawsze byłeś moim dobrym przyjacielem – rzekł Scrooge. – Dziękuję ci, Jakubie!***

#### ***– Odwiedzą cię – mówił dalej Marley – trzy duchy.***

#### ***Twarz Scrooge’a z przerażenia stała się równie blada jak bezcielesne oblicze widma.***

#### ***– Czy to ma być ta nadzieja, o której wspomniałeś, Jakubie? – zapytał drżącym głosem.***

#### ***– Tak.***

#### ***– W takim razie, drogi Jakubie, może lepiej dać temu pokój – rzekł wystraszony Scrooge.***

#### ***– Bez tych odwiedzin – kończył duch – nie możesz uniknąć mego – nieszczęsnego losu. Bądź***

#### ***gotów na przyjęcie pierwszych odwiedzin jutro, gdy zegar uderzy pierwszą po północy.***

#### ***– Czy ci goście nie mogliby przyjść wszyscy razem, abym z nimi mógł prędzej sprawę***

#### ***załatwić? – szepnął Scrooge.***

#### ***– Drugi zjawi się następnej nocy, o tej samej godzinie. Trzeci znów następnej nocy, gdy zegar***

#### ***wybije dwunastą. Nie spodziewaj się zobaczyć mnie. Radzę ci, zapamiętaj to wszystko, co dzisiaj***

#### ***ode mnie usłyszałeś.***

#### 

#### ***Wypowiedziawszy te słowa, widmo wzięło swoją chustkę ze stołu i obwiązało nią twarz.***

#### ***Scrooge domyślił się tego po kłapnięciu, jakie wydały zęby. Gdy ośmielił się znowu podnieść***

#### ***oczy, ujrzał gościa zza grobu stojącego z nawiniętym na rękach łańcuchem.***

#### ***Po chwili widmo zaczęło się cofać; za każdym j ego krokiem okno powoli otwierało się, a gdy***

#### ***duch znalazł się tuż przy nim – było już szeroko otwarte.***

#### ***Wtedy duch dał znak Scrooge’owi, aby się zbliżył, co też uczynił. Kiedy się znaleźli o dwa***

#### ***kroki od siebie, duch Marleya podniósł rękę, nie pozwalając Scrooge’owi zbliżyć się więcej.***

#### ***Scrooge zatrzymał się.***

#### ***Uczynił to nie tyle z uległości, ile ze strachu, ponieważ w chwili gdy duch podniósł rękę,***

#### ***usłyszał jakieś nieokreślone głosy w powietrzu: jakby jęki rozpaczy, skargi niewypowiedzianie***

#### ***bolesne, lamenty żalu i skruchy... Duch słuchał przez chwilę, po czym przyłączył się do***

#### ***żałobnego chóru i, wypłynąwszy przez okno, znikł wśród ciemności.***

#### ***Scrooge, zaciekawiony i przerażony, wyjrzał przez okno.***

#### ***Powietrze było zapełnione milionami widm, błądzącymi we wszystkich kierunkach z***

#### ***gorączkowym pośpiechem i żałośnie jęczącymi. Wszystkie dźwigały takie same łańcuchy jak***

#### ***duch Marleya; niektóre były skute po kilka razem; ani jedno nie było bez okowów. Wielu***

#### ***Scrooge dobrze znał za ich życia. Teraz zaś wiedział już, że wszystkie te widma cierpiały***

#### ***straszną karę dlatego, ponieważ za życia uchylały się od obowiązku pracy dla dobra ludzkości.***

#### ***Teraz, po śmierci, mimo najgorętszych pragnień, nie mogły naprawić złego.***

#### ***Czy w końcu istoty te rozpłynęły się w mgle, czy też mgła je zasłoniła? – Scrooge nie***

#### ***wiedział. Znikły, ich głosy przestały rozbrzmiewać, a noc stała się taka sama jak wtedy, gdy***

#### ***wracał do domu.***

#### ***Scrooge zamknął okno i starannie zbadał drzwi, przez które wszedł duch Marleya. Były***

#### ***zamknięte na dwa spusty. Chciał już powiedzieć zwykłe swoje: „Głupstwo!” – ale zatrzymał się***

#### ***przy pierwszej sylabie. Naraz poczuł się bardzo znużony. Może był to skutek doznanych wrażeń,***

#### ***może całodziennej pracy, może wreszcie wizji spoza grobu i męczącej rozmowy z duchem; dość,***

#### ***że rzucił się na łóżko w ubraniu i natychmiast zasnął.***

#### 

#### ***Rozdział 2***

#### ***Wizyta pierwszego ducha***

#### ***Kiedy Scrooge obudził się, było tak ciemno, że ledwie mógł odróżnić przejrzyste okno od***

#### ***ciemnych ścian pokoju.***

#### ***W chwili gdy usiłował przeniknąć ciemność – zegar z wieży sąsiedniego kościoła wybił cztery***

#### ***kwadranse. Słuchał pilnie, która wybije godzina?***

#### ***Ku jego wielkiemu zdziwieniu, ciężki dzwon wybił sześć, siedem, osiem i tak dalej aż do***

#### ***dwunastu. Dwunasta? To niemożliwe. Było przecież już po drugiej, gdy poszedł spać. Zegar***

#### ***mylił się. Lód musiał się dostać między jego koła i tryby. Dwunasta!***

#### ***Przycisnął sprężynę swego repetiera1***

#### &#x20;***w celu skontrolowania ogłupiałego zegara, lecz repetier***

#### ***także wybił dwunastą.***

#### ***– To niepodobna – mruczał Scrooge – żebym przespał dzień i część drugiej nocy. Niepodobna***

#### ***również, żeby słońcu przytrafiło się coś nadzwyczajnego i żeby zamiast południa była teraz***

#### ***północ.***

#### ***Zaniepokojony, najprędzej jak mógł wygrzebał się z łóżka i po omacku zbliżył się do okna.***

#### ***Rękawem szlafroka starł mróz z szyby, ale zobaczył niewiele. Zauważył tylko, że było bardzo***

#### ***mglisto i nadzwyczaj zimno. Nie było słychać ludzi, biegnących w różne strony i sprawiających***

#### ***zwykły hałas. Spostrzeżenie to przyniosło mu wielką ulgę. Interesy załatwia się w dzień, nie w***

#### ***nocy.***

#### ***Scrooge wrócił tedy do łóżka i zaczął rozmyślać o wszystkim, co mu się przytrafiło; pomimo***

#### ***wysiłków nie mógł nic zrozumieć.***

#### ***Duch Marleya wzburzył go niesłychanie. Ile razy, po dojrzałej rozwadze dochodził do***

#### ***wewnętrznego przekonania, że był to po prostu sen, myśl jego znów wracała, jak uwolniona od***

#### ***nacisku sprężyna, do dręczącego pytania;***

#### ***– Czy to był sen, czy rzeczywistość?***

#### &#x20;

#### &#x20;***repetier - ręczny zegarek z mechanizmem wydzwaniającym godzinę.***

#### 

#### ***Scrooge leżał, dręczony niepewnością, dopóki zegar nie wybił trzech kwadransów. Wtedy***

#### ***przypomniał sobie nagle, że, według zapowiedzi widma Marleya, o godzinie pierwszej ma się***

#### ***spodziewać odwiedzin jakiegoś ducha. Postanowił czuwać, dopóki zegar nie wybije tej godziny.***

#### ***Wiedział, że dopóki oznaczony termin nie minie, nie zmruży oka. To było pewne. Uznał, iż nic***

#### ***rozsądniejszego przedsięwziąć niepodobna.***

#### ***Czekanie jednak tak go znużyło, że chyba zdrzemnął się. Lecz niebawem w jego wytężonych***

#### ***uszach rozległo się złowrogie:***

#### ***– Ding-dong!***

#### ***– Kwadrans po dwunastej – zaczął rachować Scrooge.***

#### ***– Ding-dong!***

#### ***– Pół do pierwszej – szepnął Scrooge.***

#### ***– Ding-dong!***

#### ***– Trzy kwadranse na pierwszą – policzył znów Scrooge.***

#### ***– Ding-dong!***

#### ***– Pierwsza! – zawołał Scrooge tryumfalnie. – Pierwsza. Nikt się nie zjawia!***

#### ***W chwili jednak, gdy rozległo się ostatnie głuche, groźne uderzenie, cały pokój nagle zajaśniał***

#### ***silnym blaskiem i kotara łóżka Scrooge’a rozsunęła się.***

#### ***Ściślej mówiąc – kotarę rozsunęła jakaś ręka. I to w dodatku tę część zasłony, na którą***

#### ***Scrooge miał w tej chwili zwrócone oczy.***

#### ***Scrooge przysiadł na łóżku i znalazł się oko w oko z nadziemskim gościem.***

#### ***Dziwna to była postać. Niby dziecko, a jednak podobna nie tyle do dziecka, ile do starca,***

#### ***widzianego przez jakąś dziwną atmosferę, która, oddalając go, zmniejszała do rozmiarów***

#### ***dziecka. Włosy, rozwiane i spadające na ramiona, były białe jak włosy starca; natomiast twarz,***

#### ***bez śladu nawet zmarszczek, miała cerę świeżą i rumianą, po prostu młodzieńczą. Barki były***

#### ***szerokie, ręce długie i muskularne, dłonie tak rozwinięte, że zdawało się, iż posiadają***

#### ***nadzwyczajną siłę. Obnażone nogi i stopy były pięknie ukształtowane.***

#### ***Zjawa przybrana była w śnieżnej białości tunikę, ściągniętą pasem, połyskującym tysiącem***

#### ***brylantów. W ręce trzymała gałązkę świeżego, zielonego świerku, suknię zaś, w dziwnej***

#### ***sprzeczności z tym symbolem zimy, zdobiły świeże kwiaty. Lecz najdziwniejsze ze wszystkiego***

#### ***było to, że z wierzchołka głowy wytryskał jasny promień światła, który rozjaśniał wszystko***

#### ***dookoła. W chwilach smutku duch ten kładł na głowę, zamiast czapki, wielki kaptur do gaszenia***

#### ***świec, który teraz trzymał pod pachą.***

#### ***Dla Scrooge’a, który ze wzrastającym zainteresowaniem przypatrywał się gościowi,***

#### ***największą osobliwością całej postaci był pas. Pas ten lśnił, skrzył się, raz w jednym miejscu, to***

#### ***znów w innym tak, że to, co było jasne, za chwilę stawało się ciemną plamą i tak na przemian.***

#### ***Cała postać zjawy też odbijała owe zmiany świetlne, a wskutek tego przedstawiała się co chwilę***

#### ***inaczej. To zdawała się mieć jedną tylko nogę, to jedną rękę, to znów parę nóg, to korpus bez***

#### ***głowy, to wreszcie głowę bez korpusu. Zmiany te następowały bardzo szybko.***

#### ***– Czy ty jesteś tym duchem, którego przyjście mi zapowiedziano? – spytał Scrooge.***

#### ***– Tak, jestem nim!***

#### ***Głos był miły, dźwięczny, lecz tak słaby, jak gdyby dochodził z oddalenia.***

#### ***– Kim ty jesteś? - badał Scrooge.***

#### ***– Jestem duchem wigilijnym przeszłości.***

#### ***– Bardzo dawnej przeszłości? – zapytał Scrooge, wpatrując się w zjawę.***

#### ***– Nie. Duchem twoich minionych Wigilii. Zapewne Scrooge nie byłby w stanie powiedzieć,***

#### ***dlaczego zapragnął widzieć ducha w osobliwej czapce na głowie. Ale faktem jest, że nie mógł się***

#### ***pohamować i poprosił ducha o nakrycie głowy.***

#### 

#### ***– Co?! – zawołał duch. – Chcesz swymi występnymi rękoma zagasić dobroczynne światło,***

#### ***które ci przynoszę? Czy mało ci jeszcze, że jesteś jednym z tych, których namiętności złożyły się***

#### ***na utworzenie tej czapki i skazały mnie do noszenia jej przez całe wieki?***

#### ***Scrooge pokornie wyparł się wszelkiej intencji obrażenia ducha i zapewnił, że nigdy w życiu***

#### ***świadomie nie przyczynił się do skazania go na taką przykrość. W końcu odważył się zapytać***

#### ***gościa, co go właściwie sprowadza.***

#### ***– Twoje dobro! – odparł duch.***

#### ***Scrooge wyraził serdeczne podziękowanie, lecz pomyślał, że spokojny, niczym nie zamącony***

#### ***sen byłby właściwszy.***

#### ***Duch musiał odgadnąć jego myśli, gdyż odezwał się:***

#### ***– Ściślej mówiąc, sprowadza mnie tu pragnienie twojej poprawy. Jeżeli ci się to nie podoba,***

#### ***biada ci!***

#### ***Rzekłszy to, wyciągnął swą muskularną dłoń i dotknął jego ramienia, dodając:***

#### ***– Wstań i pójdź ze mną!***

#### ***Przestraszony Scrooge próbował tłumaczyć się, że nie jest ubrany i ma katar oraz że w takim***

#### ***stanie lepiej jest pozostawać w ciepłym łóżku, niż spacerować po nocy. Duch nie pozwolił mu***

#### ***jednak przyjść do słowa, wziął go za rękę i pociągnął za sobą. Dotknięcie zjawy, chociaż***

#### ***delikatne jak wytwornej damy, uniemożliwiało opór. Scrooge wstał, lecz widząc, że duch***

#### ***prowadzi go ku oknu, schwycił go za tunikę, wołając błagalnie:***

#### ***- O, duchu łaskawy! Ja przecież jestem zwykłym śmiertelnikiem, łatwo mogę upaść...***

#### ***- Dotknę cię moją ręką, o, tutaj – rzekł duch, kładąc rękę na sercu Scrooge’a – a dotknięcie to***

#### ***sprawi, że wytrzymasz jeszcze cięższe próby.***

#### ***Podczas tej rozmowy przeszli przez ścianę domu i znaleźli się daleko za miastem, na otwartej***

#### ***drodze wiejskiej. Miasto zniknęło, nigdzie ani śladu zabudowań. Razem z miastem znikły***

#### ***ciemność i mgła. Jaśniał teraz mroźny, lecz pogodny dzień zimowy. Ziemię pokrywał całun***

#### ***śniegu.***

#### ***– Sprawiedliwe nieba! – zawołał Scrooge, rozglądając się dokoła – przecież to moja rodzinna***

#### ***wioska... Wychowałem się tutaj, bawiłem się z rówieśnikami... Tak, tu spędziłem lata chłopięce...***

#### ***Duch spoglądał na niego z łagodnym uśmiechem. Jego lekkie, przelotne dotknięcie obudziło***

#### ***uczucia starego Scrooge’a, który teraz chciwie wdychał balsamiczne wonie, unoszące się w***

#### ***powietrzu, a każda wskrzeszała w nim tysiące wspomnień, nadziei, radości i trosk – dawno***

#### ***zapomnianych...***

#### ***– Twe usta drżą - odezwał się duch. – A co tam błyszczy na twoim policzku?***

#### ***– Nic! Nic! – wykrztusił wzruszony Scrooge. – Zapewniam cię, że wcale nie czuję obawy.***

#### ***Prowadź mnie, dokąd chcesz!***

#### ***– Poznajesz tę drogę? – zapytał duch.***

#### ***– Czyją poznaję?! – zawołał Scrooge z zapałem. – Mógłbym iść po niej z zawiązanymi***

#### ***oczami!***

#### ***– Tym bardziej więc dziwne jest, że nie przypomniałeś jej sobie przez tyle lat – zauważył***

#### ***duch. – Idźmy dalej.***

#### ***Szli więc wzdłuż drogi.***

#### ***Scrooge poznawał każdy wzgórek, każdą bramę, słup lub drzewo.***

#### ***Wreszcie w oddali ukazało się małe miasteczko z mostem, kościołem i wijącą się srebrną***

#### ***wstęgą rzeczki.***

#### ***Jednocześnie zjawiły się kosmate kuce, biegnące ku nim truchtem, z małymi chłopcami na***

#### ***grzbietach, którzy nawoływali wesoło innych chłopców, jadących na wozach wiejskich. Wszyscy***

#### 

#### ***byli w doskonałych humorach i tak ochoczo pokrzykiwali, że cała przestrzeń wypełniła się***

#### ***wesołym gwarem.***

#### ***– To są tylko cienie przeszłości, które kiedyś istniały – rzekł duch. Nas te istoty nie***

#### ***przeczuwają nawet.***

#### ***Rozbawieni mali podróżni zbliżali się, a Scrooge poznawał i nazywał każdego z nich po***

#### ***imieniu.***

#### ***Byli to jego rówieśnicy, weseli towarzysze lat młodzieńczych.***

#### ***Dlaczego ich widok sprawiał mu taką niewypowiedzianą radość? Dlaczego, gdy go mijali,***

#### ***jego wzrok, zwykle zimny i surowy, płonął teraz jasno, a serce w piersi biło gwałtownie?***

#### ***Dlaczego, gdy ci dziarscy, rozbawieni chłopcy rozstawali się na rozdrożach i życzyli sobie***

#### ***wzajem wesołych świąt Bożego Narodzenia, wesołość wypełniała mu duszę?***

#### ***Czymże były wesołe święta dla Scrooge’a? Precz z wesołymi świętami! Cóż dobrego***

#### ***przyniosły mu kiedykolwiek?***

#### ***– Szkoła nie jest jeszcze zupełnie pusta – zauważył duch. – Znajduje się tam jakieś samotne,***

#### ***opuszczone przez wszystkich dziecko.***

#### ***Scrooge szepnął, że wie o tym i gorzko zapłakał.***

#### ***Minęli szeroką szosę i dobrze znajomą Scrooge’owi ścieżką zbliżyli się do wielkiego***

#### ***budynku, zbudowanego z czerwonej cegły, na którym trzymała się jeszcze wieżyczka z***

#### ***dzwonem.***

#### ***Był to niegdyś wspaniały dom, ale spotkały go smutne losy i teraz przedstawiał wymowne***

#### ***świadectwo znikomości rzeczy doczesnych. Jego zewnętrzne ściany przeżarła wilgoć, okna były***

#### ***wybite, bramy i drzwi spróchniałe. Drób gdakał i gospodarował po stajniach, a spichrze,***

#### ***wozownie i szopy porosły chwastem.***

#### ***Wnętrze niczym nie przypominało dawnej świetności. Znalazłszy się w ciemnym, pełnym***

#### ***śmieci i błota korytarzu, można było przez otwarte drzwi ujrzeć szereg pokojów, pustych i***

#### ***zimnych. Powietrze było przesycone wilgocią, z każdego kąta wyzierało opuszczenie.***

#### ***Duch i Scrooge szli przez sień do umieszczonych w tyle domu drzwi, które same otworzyły***

#### ***się przed nimi, odsłaniając długą, pustą i posępną, izbę, zastawioną ławami i pulpitami. Przy***

#### ***jednym z pulpitów samotny chłopiec czytał coś przy dopalającym się ogarku.***

#### ***Scrooge zakrył twarz dłońmi i zapłakał: w tym opuszczonym chłopcu poznał samego siebie...***

#### ***Najmniejsze echo w tej pustce, pisk i bieganie myszy, krople spadające z na wpół***

#### ***odmarzniętej rynny gdzieś w tylnej części domu, słaby szmer bezlistnych gałęzi topoli,***

#### ***skrzypienie drzwi pustego spichrza, wiszących na naderwanym zawiasie, pryskanie dogasającego***

#### ***na kominku ognia – wszystkie te szmery i odgłosy spadały niby kojący balsam na duszę***

#### ***Scrooge’a, przynosząc mu ulgę.***

#### ***Duch dotknął jego ramienia, wskazując mu jego dawne „ja”, pogrążone w czytaniu.***

#### ***Wtem jakiś człowiek w dziwacznym stroju i z zatkniętą za pas siekierą zjawił się przed***

#### ***oknem, prowadząc za sobą osła obładowanego drzewem.***

#### ***– Ależ to Ali Baba! – zawołał uradowany Scrooge. – To stary, dobry, drogi, poczciwy Ali***

#### ***Baba! Poznaję go doskonale! Pewnego wieczoru wigilijnego – dawno, bardzo dawno temu! –***

#### ***gdy to opuszczone dziecko zostało zupełnie samo, on przyszedł do niego, po raz pierwszy,***

#### ***właśnie w takim ubiorze jak teraz. Biedny chłopiec!***

#### ***– A to Walentyn! – ciągnął dalej Scrooge – i jego dziki brat, Orson. A ten, jakże się on***

#### ***nazywa – no ten, którego położono śpiącego u bram Damaszku? Czy go nie widzisz? O,***

#### ***koniuszy sułtana, postawiony przez wróżkę na głowie nogami do góry... Ha... ha... wciąż stoi na***

#### ***głowie! Dobrze mu tak! Bardzo mnie to cieszy! Jakim prawem chciał się żenić z córką sułtana?***

#### 

#### ***– A tam papuga! – snuł swoje wspomnienia Scrooge. – Zielona, z żółtym ogonem, z czubem***

#### ***wyrastającym z głowy, podobnym do liści sałaty! Znalazł ją Robinson Kruzoe, gdy wrócił do***

#### ***domu po opłynięciu swej wyspy. Nauczył ją wołać: „Biedny Robinsonie Kruzoe!”. Gdy papuga***

#### ***tak przemówiła, sądził, że śni; a to istotnie mówiła papuga... A tam Piętaszek pędzi do zatoki,***

#### ***uciekając przed ludożercami... Szybciej! Śmiało! Nie trać odwagi! Robinson cię ocali...***

#### ***Przechodząc od jednego wspomnienia do drugiego, z energią, jakiej by nikt w nim nie***

#### ***podejrzewał, Scrooge nagle uniósł się litością nad swym dawnym „ja”.***

#### ***– Biedny, biedny chłopiec! – szepnął i zapłakał.***

#### ***– Pragnąłbym – mruknął po chwili, otarłszy łzy rękawem szlafroka – pragnąłbym bardzo... ale***

#### ***teraz pewnie już za późno!***

#### ***– O co ci chodzi? - zapytał duch.***

#### ***– Nic – odparł Scrooge – ot, drobnostka. Przypomniałem sobie jakiegoś wyrostka, który***

#### ***wczoraj wieczorem śpiewał pieśń świąteczną przed drzwiami mego kantoru. Żałuję, że mu nic***

#### ***nie dałem. Ot, wszystko.***

#### ***Duch uśmiechnął się, skinął ręką i rzekł:***

#### ***– Teraz zobaczymy inną Wigilię.***

#### ***W tej chwili chłopiec był już o kilka lat starszy, a izba szkolna stała się jeszcze ciemniejsza i***

#### ***bardziej brudna. W ścianach ukazały się szczeliny, okna pokrzywiły się, tynk poodpadał***

#### ***kawałkami z sufitu, odkrywając nagie deski.***

#### ***W jaki sposób wszystkie te zmiany mogły odbywać się tak szybko? Scrooge tego nie wiedział.***

#### ***Wiedział tylko, że gdy inni chłopcy udali się na wesołe święta, do domów rodzinnych, on***

#### ***pozostał w szkole sam jeden, zapomniany i opuszczony.***

#### ***Teraz jednak nie czytał, natomiast zrozpaczony chodził po izbie szkolnej wzdłuż i wszerz.***

#### ***Scrooge spojrzał na ducha, potrząsł żałośnie głową, po czym niespokojny i wyczekujący***

#### ***wzrok skierował ku drzwiom.***

#### ***Drzwi te otworzyły się i do szkoły wpadła mała dziewczynka, znacznie młodsza od chłopca,***

#### ***rzuciła mu się na szyję i całując go wołała:***

#### ***– Mój drogi, dobry braciszku!***

#### ***Wycałowawszy go zaś, klaszcząc drobnymi wychudłymi rączkami i śmiejąc się mówiła***

#### ***szybko:***

#### ***– Przybyłam, mój kochany, ażeby cię zabrać do domu! Tak! Ażeby cię zabrać do domu, do***

#### ***domu!***

#### ***– Do domu, Fanny? – powtórzył chłopiec.***

#### ***– Tak, to prawda! – potakiwała rozpromieniona dziewczynka. - Do domu na dobre. Do domu***

#### ***na zawsze. Ojciec jest teraz o wiele lepszy niż był dawniej, nasz dom jest teraz miły! Pewnego***

#### ***wieczoru przemawiał do mnie tak łagodnie, że ośmieliłam się zapytać go jeszcze raz, czybyś***

#### ***mógł wrócić do domu? Odpowiedział, że możesz. I dziś wysłał mnie pocztowym powozem,***

#### ***żebym ciebie, braciszku, przywiozła. Ty niedługo będziesz prawdziwym mężczyzną – dodała z***

#### ***dumą, szeroko otwierając swoje duże oczy – i nigdy już tutaj nie wrócisz. Teraz spędzimy razem***

#### ***święta Bożego Narodzenia, będziemy doskonale się bawili. Ach! co to będzie za rozkosz!***

#### ***– Jesteś już prawie kobietą, moja mała siostrzyczko! – zawołał chłopiec.***

#### ***Ona zaś radośnie klasnęła w ręce i śmiejąc się próbowała dosięgnąć jego głowy; widząc***

#### ***jednak, że jest za mała, znów wybuchnęła śmiechem i podniosła się na palcach, aby go jeszcze***

#### ***raz ucałować. Wreszcie zaczęła go ciągnąć ku drzwiom, a on szedł za nią ulegle, nie mając nic***

#### ***przeciwko opuszczeniu tej ponurej izby.***

#### ***Naraz w sieni rozległ się straszny głos:***

#### ***Znieść na dół rzeczy pana Scrooge’a! Żywo!***

#### 

#### ***Prawie jednocześnie w drzwiach izby szkolnej ukazał się nauczyciel. Przez chwilę spoglądał***

#### ***na chłopca z dziwną uprzejmością, po czym ujął jego rękę i uścisnął tak gwałtownie, że chłopiec***

#### ***zmieszał się i omal nie stracił przytomności. Następnie zaprowadził dzieci do niskiego,***

#### ***odrapanego pokoju, w którym mapy na ścianach i globusy w oknach pokrywał szron. Wyjął teraz***

#### ***karafkę przedziwnie lekkiego wina oraz kawał ciężkiego ciasta i poczęstował młodych gości tymi***

#### ***przysmakami. Równocześnie wysłał chudego służącego, aby ofiarował szklankę „czegoś”***

#### ***chłopcu pocztowemu. Ten odrzekł, że jest bardzo wdzięczny za poczęstunek, jednak jeśli to jest***

#### ***taki sam napój, którego już kiedyś kosztował, woli raczej nie pić. Tymczasem kufer Scrooge’a***

#### ***został już przymocowany na wierzchu dyliżansu, więc dzieci pożegnały nauczyciela i, zająwszy***

#### ***miejsca w dyliżansie, odjechały drogą ogrodową, na której rozpryskiwał się szron i śnieg.***

#### ***– Ona zawsze była wątła i delikatna – zauważył duch – zdawało się, iż lada wietrzyk ją***

#### ***zmiecie. Ale serce miała wielkie!***

#### ***– To prawda – potwierdził Scrooge. – Masz rację. Boże broń, żebym miał temu przeczyć!***

#### ***– Umarła zamężna i zostawiła, o ile mi się zdaje, dzieci – rzekł duch.***

#### ***– Jedno dziecko – poprawił Scrooge.***

#### ***– Prawda – przyznał duch – a tym dzieckiem jest twój siostrzeniec.***

#### ***Scrooge zmieszał się, niespokojnie poruszył i jakby ze skruchą szepnął:***

#### ***– Tak!***

#### ***Chociaż zaledwie przed chwilą opuścili szkolny gmach, to już znajdowali się na ruchliwych***

#### ***ulicach Londynu. Przechadzały się tu różne duchy, a cienie wozów i powozów walczyły o***

#### ***miejsce dla siebie wśród zamieszania i zgiełku wielkiego miasta. Po ożywionym ruchu w***

#### ***sklepach można było poznać, że był to dzień wigilijny. Wieczór już zapadł, latarnie oświecały***

#### ***ulice.***

#### ***Duch zatrzymał się przed jakimś składem i zapytał Scrooge’a, czy poznaje to miejsce.***

#### ***– Czy poznaję? – zawołał Scrooge. – Przecież praktykowałem tutaj! Weszli.***

#### ***Przy wysokim biurku siedział stary człowiek w walijskiej peruce. Na jego widok Scrooge***

#### ***zawołał z uniesieniem:***

#### ***– Ależ to Fezziwig! Daj mu Boże zdrowie.***

#### ***Wtedy stary Fezziwig położył pióro, spojrzał na zegar ścienny, który wskazywał godzinę***

#### ***siódmą, zatarł ręce, poprawił swą obszerną kamizelkę, roześmiał się głośno, potem klasnął w***

#### ***dłonie i zawołał dźwięcznym, jowialnym, wesołym głosem:***

#### ***– Hej tam! Ebenezer! Dick!***

#### ***Scrooge, teraz już w postaci młodzieńca, wszedł żywo w towarzystwie swego kolegi.***

#### ***– Z pewnością Dick Wilkins! – zawołał Scrooge do ducha. – Przysięgam, że to on! Dick był***

#### ***bardzo do mnie przywiązany. Biedny Dick! Biedny!***

#### ***– Hej tam, chłopcy! – rzekł Fezziwig. – Kończcie już pracę, na dziś dosyć! Przecież to***

#### ***wieczór wigilijny! Zamykajcie okiennice.***

#### ***Trudno wyrazić, z jakim zapałem zabrali się chłopcy do roboty. Wybiegli na ulicę, zamknęli i***

#### ***zaryglowali okiennice i zanim mogłeś doliczyć do dwunastu, już wrócili, dysząc jak konie***

#### ***wyścigowe.***

#### ***– Brawo! Doskonale! – zawołał stary Fezziwig, zeskakując z wysokiego stołka ze zwinnością***

#### ***godną podziwu. – Uprzątnąć, chłopcy, z pokoju rzeczy zbyteczne, żebyśmy mieli sporo miejsca!***

#### ***Hej-ho, Dick! Hej-ho, Ebenezer!***

#### ***Uprzątnąć! Nie było takiej rzeczy, której nie uprzątnęliby, gdy stary Fezziwig patrzył na nich.***

#### ***Załatwili to w minutę. Każda rzecz ruchoma została gdzieś usunięta, podłogę skropiono i***

#### ***zamieciono, lampy opatrzono, nałożono świeżego paliwa do kominka; lokal sklepowy***

#### 

#### ***przedstawiał miłą, zaciszną, jasną i suchą salę balową, jaką sobie można wymarzyć w noc***

#### ***zimową.***

#### ***Zjawił się skrzypek z nutami pod pachą, podszedł do wysokiego biurka, zamieniając je na***

#### ***pulpit, i zaczął stroić instrument, który jęczał i skrzypiał przy tej operacji. Weszła pani Fezziwig,***

#### ***dobrze odżywiona, wiecznie uśmiechnięta dama, uosobienie dobroci i wyrozumiałości. Weszły***

#### ***trzy panny Fezziwig, promieniejące i rozkoszne. Za nimi wkroczyło sześciu młodych adoratorów***

#### ***z pogruchotanymi sercami. Przybyli młodzi mężczyźni i kobiety, zatrudnieni w tym domu. Z***

#### ***nimi służąca ze swym kuzynem piekarzem. Weszła kucharka z przyjacielem swego brata,***

#### ***rozwozicielem mleka. Zjawił się maleńki podmajstrzy z naprzeciwka, którego podejrzewano o to,***

#### ***że go pracodawca głodzi; chował się on za służącą z sąsiedniego domu, którą jego pryncypałowa***

#### ***za coś szczególnie prześladowała. Wszyscy wchodzili spokojnie, bez tłoczenia się; jedni***

#### ***nieśmiało, inni zuchwale, jedni z wdziękiem, inni niezgrabnie, aż wreszcie wszyscy znaleźli się***

#### ***w pokoju.***

#### ***Niebawem rozpoczęły się ochocze tańce. Najprzód wszyscy tańczyli razem, ze dwadzieścia***

#### ***par, trzymając się za ręce i tworząc wielkie koło. Polowa wysuwała się naprzód, druga cofała się***

#### ***w tył. Kołysali się do taktu, to znów wszyscy kręcili się, grupami lub tworząc długiego węża.***

#### ***Stare pary wciąż się myliły, sprawiały zamieszanie, a młode, bardzo z tego zadowolone,***

#### ***przesuwały się z błyskawiczną szybkością z jednego końca sali na drugi. Wreszcie wszyscy się***

#### ***zmieszali, skotłowali, wytworzył się istny radosny chaos.***

#### ***Korzystając z nastroju zapału, stary Fezziwig wstrzymał tańczących klaśnięciem w dłonie i***

#### ***zawołał:***

#### ***– Brawo! Doskonale!***

#### ***Wówczas skrzypek zanurzył swą twarz w kuflu porteru, umyślnie na ten cel przygotowanym.***

#### ***Nie dopijając do końca, podniósł głowę i natychmiast rozpoczął ponownie grać, z jeszcze***

#### ***większą fantazją.***

#### ***Gdy już nahasano się do woli, rozpoczęła się gra w fanty, a potem znowu były tańce. W***

#### ***przerwach rozdawano ciastka i lemoniadę, pieczyste na zimno i mnóstwo piwa.***

#### ***Główny punkt programu nastąpił po pieczystym, gdy skrzypek (podstępny był to hultaj; znał***

#### ***on lepiej swoje rzemiosło niż można było sądzić z pozoru!) zagrał popularną melodię ludową.***

#### ***Wtedy stary Fezziwig stanął z panią Fezziwig na czele wszystkich tancerzy.***

#### ***Pierwsza para miała do spełnienia nie lada zadanie, bo za nią sunęło dwadzieścia kilka par***

#### ***utworzonych z ludzi, z którymi nie można było żartować, bo niewiele wiedzieli o tanecznych***

#### ***krokach, a bardzo pragnęli tańczyć.***

#### ***Ale gdyby ich było i dwa razy tyle – ba, cztery razy – stary Fezziwig dałby im radę, i pani***

#### ***Fezziwig także. To nie ulega wątpliwości.***

#### ***Pani Fezziwig była godną towarzyszką swego małżonka w pełnym tego słowa znaczeniu.***

#### ***Z ruchów i kroków pana Fezziwiga jak gdyby sypały się iskry. Przy każdej jego nowej figurze***

#### ***była niespodzianka. Nie dało się odgadnąć w danej chwili, co będzie dalej. A gdy państwo***

#### ***Fezziwig przeszli przez wszystkie fazy tańca, gdy wykonali wszystkie figury: naprzód, w tył,***

#### ***krzyże, kołysania się, koszyki itp., pan Fezziwig zdobył się na śmiały skok, tak że nogi lekko***

#### ***zaplątały mu się w powietrzu i zdawało się, że je połamie; na szczęście, do katastrofy nie doszło.***

#### ***Zabawa skończyła się z chwilą gdy zegar uderzył jedenastą. Państwo Fezziwig zajęli swoje***

#### ***stanowiska po obydwu stronach drzwi i ściskając ręce każdego wychodzącego gościa, życzyli mu***

#### ***uprzejmie wesołych świąt. Gdy już wszyscy wyszli, dwóch praktykantów spotkała ta sama***

#### ***grzeczność. Potem wesołe głosy umilkły, chłopcy zaś pozostali, aby położyć się na posłaniach,***

#### ***które znajdowały się pod stołami w tylnym warsztacie; długo jeszcze gawędzili, ożywieni i***

#### ***rozradowani.***

#### 

#### ***Scrooge, patrząc na wskrzeszone chwile przeszłości, tak był wzburzony, że zdawało się, iż***

#### ***postradał zmysły. Całym sercem uczestniczył w tej zabawie. Pamiętał wszystko i cieszył się***

#### ***wszystkim, doznawał niewypowiedzianych wzruszeń. Dopiero gdy rozjaśnione twarze jego***

#### ***dawnego „ja” i Dicka odwróciły się ku ścianie, przypomniał sobie ducha i zauważył, że***

#### ***przygląda mu się badawczo, a światło na jego głowie jaśnieje silniejszym blaskiem.***

#### ***– Niewiele potrzeba – odezwał się duch – dla zjednania sobie wdzięczności prostych ludzi.***

#### ***– Niewiele! – powtórzył, jak echo, Scrooge. Duch dał mu znak, aby posłuchał rozmowy***

#### ***dwóch praktykantów, którzy z zapałem wychwalali Fezziwiga, po czym rzekł:***

#### ***– Czy nie mam racji? Ów Fezziwig wydał zaledwie trzy lub cztery funty szterlingi; to przecież***

#### ***nie powód, żeby go wychwalać pod niebiosy. Jakaż tu zasługa?***

#### ***– Ależ to nie o to chodzi – zaoponował Scrooge, podniecony wspomnieniem, nie pamiętając,***

#### ***że wypowiada przekonania dawnego Scrooge’a. – To nie o to chodzi, duchu. On ma możność***

#### ***uczynienia nas szczęśliwymi lub nie; uczynienia życia naszego lżejszym lub cięższym, a naszą***

#### ***pracę przyjemną lub przykrą. Cóż z tego, że jego władza przejawia się tylko w dobrym słowie,***

#### ***poczciwym spojrzeniu, w drobiazgach wręcz nieuchwytnych? To nic nie znaczy, gdyż nie w tym***

#### ***istota rzeczy. Życzliwość, jaką on roztacza dokoła siebie, jest tak wielka, a dla nas tak droga, że***

#### ***się niczym opłacić nie da.***

#### ***Spotkawszy przenikliwy wzrok ducha, zamilkł.***

#### ***– Cóż się z tobą dzieje? – zapytał duch.***

#### ***– Nic szczególnego – odrzekł Scrooge.***

#### ***– A jednak coś się dzieje? – powtórzył.***

#### ***– Ależ nic, nic... Chciałbym tylko powiedzieć w tej chwili słów kilka memu pomocnikowi. To***

#### ***wszystko.***

#### ***Gdy wygłosił to życzenie, jego dawna postać przykręciła lampę i wraz z duchem znaleźli się***

#### ***znów na ulicy.***

#### ***– Czas mój mija – zauważył duch. – Śpieszmy się!***

#### ***Słowa te nie były skierowane do Scrooge’a czy jakiejkolwiek istoty widzialnej mimo to***

#### ***wywołały niezwykły skutek; Scrooge znowu ujrzał samego siebie. Był już starszy. Twarz jego***

#### ***nie miała jeszcze surowych linii lat późniejszych, lecz w rysach jej już się przejawiały pierwsze***

#### ***ślady skąpstwa i niepokoju. W oczach zaś migotał wyraz drapieżnej chciwości, która zaczynała***

#### ***się rozrastać w jego duszy. Nie ulegało wątpliwości, w jakim kierunku potoczy się jego życie.***

#### ***Nie był sam. Obok siedziała młoda i piękna dziewczyna w żałobie, z oczyma pełnymi łez.***

#### ***– Wiem, że to rzecz obojętna – mówiła dziewczyna zgnębionym głosem. – Zwłaszcza***

#### ***obojętna dla pana, gdyż inne bóstwo zajęło w pańskim sercu moje miejsce. Jeżeli ono zdoła***

#### ***dostarczyć ci w przyszłości takiej słodyczy, ukojenia i radości, jaką ja pragnęłabym cię otoczyć,***

#### ***to nie mam powodu do troski.***

#### ***– Jakież to bóstwo cię zastąpiło? – zapytał dawny Scrooge.***

#### ***– Pieniądz.***

#### ***– Oto sprawiedliwość ludzka! – zawołał dawny Scrooge. – Przeklinają ubóstwo, a***

#### ***jednocześnie potępiają tych, którzy w pocie czoła starają się o dostatek.***

#### ***– Przesądzasz pan sprawiedliwość świata – zauważyła dziewczyna. – Pan wszystkie swoje***

#### ***myśli i pragnienia skierował na jeden cel: wzbogacenia się. Widziałam, jak wszystkie twoje***

#### ***szlachetne uczucia gasły, jedno po drugim, tłumione tą namiętnością, która ostatecznie***

#### ***zwyciężyła. Czy to nieprawda?***

#### ***– I cóż z tego? – zapytał. – Jeżeli stałem się praktyczniejszy i rozsądniejszy, to nie znaczy,***

#### ***żebym się zmienił względem ciebie. Potrząsnęła główką.***

#### ***– Czy zmieniłem się?***

#### 

#### ***– Pomiędzy nami istnieje umowa, którą zawarliśmy wówczas, kiedy byliśmy oboje biedni.***

#### ***Wówczas nie uskarżaliśmy się na los, lecz pracowaliśmy pełni nadziei, że przyjdą dla nas lepsze***

#### ***czasy, praca zapewni nam skromny byt. Od tego czasu zmieniłeś się. Gdy zawieraliśmy umowę,***

#### ***byłeś innym człowiekiem.***

#### ***– Byłem wtedy prawie dzieckiem – przerwał niecierpliwie.***

#### ***– To sprawa twojego sumienia i sam zapewne wesz, że byłeś zupełnie inny – odparła. – Co do***

#### ***mnie, nie zmieniłam się. To, co nam obiecywało szczęście, gdy jednako czuliśmy i myśleliśmy,***

#### ***teraz jest dla nas źródłem cierpienia i męki. Często o tym myślałam i z tak wielkim bólem, że nie***

#### ***jestem w stanie tego wypowiedzieć. Teraz zwracam ci słowo.***

#### ***– Czy kiedykolwiek żądałem tego?***

#### ***– Słowami – nie.***

#### ***– W jaki więc sposób?***

#### ***– Zmianą usposobienia, widocznym zniecierpliwieniem i niepokojem. Zmieniłeś się we***

#### ***wszystkim, odmieniłeś treść swego życia i jego cel. Gdybyś dawniej nie dał mi słowa, powiedz***

#### ***szczerze – czy teraz zechciałbyś mnie pojąć za żonę? Z pewnością nie!***

#### ***Zdawał się uznawać słuszność jej przypuszczenia, a mimo to odparł:***

#### ***– Sama nie wierzysz w to, co mówisz.***

#### ***– Byłabym szczęśliwa, gdybym mogła myśleć inaczej! – szepnęła ze smutkiem. – Bóg***

#### ***świadkiem, że byłabym bardzo szczęśliwa. Jedynie wymowa faktów doprowadziła mnie do tak***

#### ***bolesnych wniosków. Gdybyś był wolny w tej chwili, czy wybrałbyś sobie za żonę biedną***

#### ***dziewczynę, ty, który w chwilach najgorętszych uniesień nie przestajesz ważyć spraw na szalach***

#### ***zysku i patrzeć na wszystko jak na interes? Gdybyś się nawet zapomniał na chwilę, i połączył ze***

#### ***mną dozgonnie, to jestem pewna, że wkrótce żałowałbyś tego kroku. Wiem, że przyszłoby do***

#### ***tego niebawem i to jest powodem, że zwracam ci dane słowo. Czynię to szczerze, w imię miłości,***

#### ***jaką kiedyś żywiłam dla ciebie.***

#### ***Chciał coś powiedzieć, lecz ona ciągnęła dalej:***

#### ***– Jestem przekonana, że zerwanie zaboli cię. Lecz krótko będziesz cierpiał. Potrafisz pozbyć***

#### ***się wszelkich wspomnień o naszej miłości. Obyś był szczęśliwy w życiu, jakie sobie obrałeś!...***

#### ***W ten sposób się rozstali.***

#### ***– Dosyć już, duchu! – zawołał Scrooge – zaprowadź mnie do domu. Nie jestem w stanie***

#### ***dłużej znosić podobnych udręczeń!***

#### ***– Jeszcze jeden cień! – odparł duch.***

#### ***– Nie nie, dosyć! – błagał Scrooge. – Nie chcę nic więcej widzieć! To ponad moje siły!...***

#### ***Nieubłagany duch pochwycił go jednak mocno w ramiona i kazał mu patrzeć na następny***

#### ***obraz.***

#### ***Znajdowali się teraz w niewielkim pokoju, urządzonym zacisznie i wygodnie. Przy kominku,***

#### ***na którym płonął jasny ogień, siedziała dziewczyna tak podobna do poprzedniej, iż Scrooge***

#### ***myślał, że to ta sama, dopóki nie zauważył, że tamta jest teraz poważną mężatką, a obok siedzi***

#### ***jej córka.***

#### ***W pokoju było gwarno, a nawet hałas, sprawiany przez gromadkę dzieci, których Scrooge w***

#### ***pierwszej chwili nie zauważył. Ta dzieciarnia zachowywała się swobodnie: każdy z malców***

#### ***swawolił i krzyczał za czterdziestu. Dlatego panowała olbrzymia wrzawa, która jednak nikomu***

#### ***nie przeszkadzała. Matka i córka były zadowolone i serdecznie się śmiały. Wreszcie córka,***

#### ***wmieszawszy się do zabawy, została przez małych swawolników opadnięta ze wszystkich stron...***

#### ***Czego bym nie dał, żeby być jednym z nich! Lecz nie byłbym tak okrutny, jak oni, wierzcie!***

#### ***Za wszystkie skarby świata nie ośmieliłbym się potargać gładko uczesanych włosów pięknej***

#### ***siostrzyczki ani też zabrać jej pantofelka! Nie ośmieliłbym się również objąć wiotkiej jej kibici.***

#### 

#### ***A jednak, wyznaję, pragnąłbym dotknąć jej ust; pragnąłbym zapytać ją o coś; patrzeć na jej***

#### ***spuszczone skromnie oczy, tak żeby nie wywołać rumieńca; pragnąłbym rozpleść jej włosy,***

#### ***których najmniejszy loczek przechowałbym jako drogą pamiątkę. Słowem, pragnąłbym wobec***

#### ***niej posiadać wszelkie przywileje dziecka i jednocześnie pozostać dojrzałym mężczyzną.***

#### ***Po chwili rozległo się pukanie i dzieciarnia rzuciła się ku drzwiom tak gwałtownie, że piękna***

#### ***siostrzyczka została porwana przez rozigraną gromadkę i pociągnięta na powitanie ojca,***

#### ***wchodzącego z posłańcem obładowanym gwiazdkowymi podarkami.***

#### ***Teraz, wśród krzyku i wrzawy, nastąpił atak na posłańca. Dzieci wdrapywały się na niego po***

#### ***krzesłach, aby zanurzyć ręce w jego kieszeniach, pozbawić go paczek, wieszały mu się na szyi,***

#### ***siadały na barkach i kopały go po nogach – a wszystko to z radości, której oprzeć się nie były***

#### ***zdolne.***

#### ***Z jakim podziwem i uciechą witano zawartość każdej, choćby najmniejszej paczki! Ile było***

#### ***radości i zachwytu! Jakąż rozpacz wywołało przypuszczenie, że jedno z dzieci, wziąwszy do ust***

#### ***maleńką brytfannę z kuchni dla lalek, połknęło znajdującego się w niej indyka z cukru... Jaką***

#### ***ulgę uczuli wszyscy, gdy okazało się, że to był fałszywy alarm... To wszystko nie da się opisać...***

#### ***Nadeszła wreszcie godzina spoczynku. Dzieci, uspokojone już nieco, udały się z otrzymanymi***

#### ***zabawkami do swego pokoju na piętrze, gdzie ułożono je w łóżeczkach. Dopiero wtedy w domu***

#### ***zapanował spokój.***

#### ***Teraz Scrooge ujrzał, jak ojciec tej rodziny przytulił serdecznie do siebie młodą żonę i z nią***

#### ***oraz z najstarszą córką zasiedli przy kominku. Pomyślał, że on również mógł być ojcem takich***

#### ***milutkich i pełnych nadziei istot, i twarz jego spochmurniała jeszcze bardziej, a w oczach ukazały***

#### ***się łzy.***

#### ***– Bello – odezwał się w tej chwili mąż, zwracając się do małżonki z łagodnym uśmiechem –***

#### ***widziałem dziś po południu twego dawnego przyjaciela.***

#### ***– Kogóż to?***

#### ***– Zgadnij.***

#### ***– Nie wiem doprawdy o kim myślisz?***

#### ***– Szczura!***

#### ***– Cóż znowu! Ach, teraz już wiem – podchwyciła, śmiejąc się równie szczerze jak mąż. –***

#### ***Pana Scrooge’a?***

#### ***– Tak, pana Scrooge’a. Przechodziłem koło okna jego kantoru, a ponieważ nie było zasłonięte***

#### ***i wewnątrz świeciło się, przeto mimo woli zobaczyłem go. Mówią, że jego wspólnik umarł, więc***

#### ***siedzi tam teraz sam. A sądzę, że jest on naprawdę samotny i że nie ma na całym świecie żadnej***

#### ***bliskiej, życzliwej istoty.***

#### ***– Duchu – szepnął Scrooge drżącym głosem – zabierz mnie stąd...***

#### ***– Uprzedziłem cię przecież, że pokażę ci cienie twego dawnego życia – odparł duch. – Nie***

#### ***wiń mnie, lecz samego siebie, że jest takie, jak widzisz.***

#### ***– Wyprowadź mnie stąd! – wołał Scrooge. – Nie mogę znieść tego widoku!***

#### ***Zwrócił się ku duchowi, a zauważywszy, że na jego obliczu w niepojęty sposób odbiły się***

#### ***niektóre rysy tych twarzy, które niedawno widział – rzucił się na niego z rozpaczliwym***

#### ***krzykiem:***

#### ***– Wyprowadź mnie stąd! Nie dręcz dłużej!***

#### ***Podczas zmagania się z duchem Scrooge spostrzegł, że nad głową zjawy unosi się teraz***

#### ***jeszcze jaśniejszy snop światła; sądząc, że owo światło daje duchowi przewagę nad nim, chwycił***

#### ***gasidło i wtłoczył mu je na głowę.***

#### ***Duch skurczył się, a choć gasidło przykryło całą jego postać i Scrooge przyciskał je z całej***

#### ***siły, nie mógł jednak stłumić światła, które wydobywało się spod spodu.***

#### 

#### ***Nagle Scrooge poczuł, że jego siły wyczerpują się i ogarnia go senność. Po chwili spostrzegł,***

#### ***że znajduje się w swojej sypialni. Dowlókł się do łóżka, rzucił się na nie i natychmiast twardo***

#### ***zasnął.***

#### 

#### ***Rozdział 3***

#### ***Odwiedziny drugiego ducha***

#### ***Scrooge’a obudziło własne chrapanie. Natychmiast usiadł na łóżku, by pozbierać myśli.***

#### ***Czuł, że obudził się o właściwej porze i wyraźnie w tym celu, aby odbyć konferencję z drugim***

#### ***gościem, przysłanym mu przez Jakuba Marleya. Na myśl jednak, że którąś z kotar jego łóżka***

#### ***mogłoby odsunąć nowe widmo, niemiły dreszcz przebiegł jego członki; sam przeto rozsunął***

#### ***kotary. Potem znów się położył i postanowił czuwać. Chciał pierwszy odezwać się do ducha w***

#### ***chwili jego zjawienia się, nie lubił bowiem być zaskakiwany.***

#### ***Ludzie szczególnej odwagi, którzy nigdy nie tracą zimnej krwi, zwykle o sobie mówią:***

#### ***„Jesteśmy zdolni do wszystkiego – od zjadania chleba aż do połykania ludzi”. Między tymi***

#### ***dwiema ostatecznościami znajduje się niewątpliwie szerokie pole do popisu.***

#### ***Nie pragnę bynajmniej przedstawić Scrooge’a jako samochwała, mogę was jednak zapewnić,***

#### ***że był on przygotowany na wszystkie nadzwyczajne zjawiska. Wmawiał w siebie, że teraz nic nie***

#### ***może go wprawić w zdumienie, poczynając od kolebki dziecka, a na olbrzymim nosorożcu***

#### ***kończąc.***

#### ***Ponieważ był przygotowany na wszystko, nie spodziewał się niczego nadzwyczajnego. Gdy***

#### ***zegar wybił pierwszą i nie zjawił się nikt, uczuł lodowate zimno, a ciało jego przebiegły***

#### ***dreszcze. Minęło pięć minut, dziesięć, kwadrans – żadnego widma!***

#### ***Kiedy tak leżał na łóżku, nagle oblało go czerwone światło. Zaniepokoiło go to o wiele więcej***

#### ***niż gdyby ukazał się cały tuzin duchów, ponieważ niepodobna było odgadnąć, co ono znaczy i do***

#### ***czego ma służyć. Przez chwilę obawiał się, że może nagle spłonąć. Wreszcie przyszło mu na***

#### ***myśl, że źródło tego dziwnego światła znajduje się w sąsiednim pokoju, z którego – jak to***

#### ***stwierdził po bliższej obserwacji – istotnie promieniowało. Wstał po cichu i w pantoflach***

#### ***podreptał do drzwi.***

#### ***Gdy Scrooge położył rękę na klamce, jakiś obcy głos kazał mu wejść. Usłuchał.***

#### ***Był to jego własny pokój. To nie ulegało wątpliwości. Ale zaszła w nim dziwna zmiana!***

#### ***Ściany i sufit były przystrojone zielonymi gałęziami, a cały pokój wyglądał jak altana,***

#### ***ozdobiona mnóstwem purpurowych jagód. Liście bluszczu, jemioły i świerku odbijały światło i***

#### 

#### ***wyglądały jak mnóstwo małych zwierciadełek. Na kominie płonął tak silny ogień, jakiego ten***

#### ***komin od wielu lat nie znał.***

#### ***Na podłodze był urządzony wielki bufet z indyków, gęsi, kaczek, dziczyzny, dużych kawałów***

#### ***pieczeni, prosiąt, długich wianków kiełbas, ciast i budyniów, beczułek z ostrygami, pieczonych***

#### ***kasztanów, różnych jabłek, soczystych pomarańczy, apetycznych gruszek, olbrzymich placków i***

#### ***naczyń z wrzącym ponczem. Napełniało to pokój przedziwnym zapachem. Pośrodku bufetu***

#### ***rozparł się wygodnie olbrzym o wspaniałym wyglądzie i wesołym obliczu. W ręku trzymał***

#### ***płonącą pochodnię w kształcie rogu obfitości; uniósł ją wysoko, aby oświecić Scrooge’a w***

#### ***chwili, gdy ten ostrożnie zaglądał do pokoju.***

#### ***– Wejdź! – zawołał ów duch. – Wejdź, przyjacielu, musimy się poznać. Scrooge wszedł nie***

#### ***bez trwogi i pochylił głowę przed duchem. Nie był to już śmiały, niczego się nie obawiający,***

#### ***dawny Scrooge; chociaż oczy ducha miały wyraz pogodny, on unikał ich spojrzenia.***

#### ***– Jestem duchem tegorocznego Bożego Narodzenia – przemówiło widmo – przypatrz mi się***

#### ***dobrze.***

#### ***Scrooge lękliwie podniósł oczy i spojrzał na ducha z szacunkiem.***

#### ***Był on przybrany w rodzaj ciemnozielonej opończy, obramowanej białym futrem. Szerokie***

#### ***piersi były odsłonięte. Także nogi, wyglądające spod szerokich fałd opończy, były bose, na***

#### ***głowie zaś miał wieniec z liści dębowych, wśród których tu i ówdzie przebłyskiwały sopelki***

#### ***lodu. Jego ciemne włosy spadały w luźnych lokach na barki. Pogodne oblicze, błyszczące oczy,***

#### ***rubaszny głos, swobodne zachowanie się – wszystko mówiło o otwartości i wesołym***

#### ***usposobieniu. Przy jego boku wisiała u pasa stara pochwa, na poły zjedzona przez rdzę, bez***

#### ***miecza.***

#### ***– Nie widziałeś dotychczas nikogo podobnego do mnie? - zapytał duch.***

#### ***– Nigdy - potwierdził Scrooge.***

#### ***– Nie spotkałeś na drodze swego życia młodszych członków mojej rodziny? Mam na myśli***

#### ***moich starszych braci? – pytał duch dalej.***

#### ***– Nie sądzę – odparł Scrooge. – A nawet jestem pewien, że nie. Dużo masz braci, duchu?***

#### ***– Przeszło dziewięciuset – odpowiedział.***

#### ***– Przerażająco liczna rodzina, szczególnie dla tego, kto musi troszczyć się o jej utrzymanie –***

#### ***mruknął Scrooge. Tegoroczny duch powstał.***

#### ***– Duchu – rzekł Scrooge pokornie – prowadź mnie, dokąd chcesz. Wczorajszej nocy***

#### ***wyprowadzono mnie przemocą i dano lekcję, która teraz zaczyna działać. Dziś jestem gotów iść***

#### ***za tobą i nie omieszkam skwapliwie z twych nauk skorzystać.***

#### ***– Dotknij ręką mojej szaty – odezwał się duch.***

#### ***Scrooge chwycił ją z całej siły.***

#### ***Zielone gałęzie, czerwone jagody, indyki, gęsi, pieczenie, prosięta, kiełbasy, pasztety,***

#### ***budynie, owoce i poncz znikły w jednej chwili. Znikł także pokój, ogień, czerwony blask, nocna***

#### ***pora, i Scrooge z duchem znaleźli się na ulicach miasta.***

#### ***Był to ranek pierwszego dnia Bożego Narodzenia. Z chodników i z dachów zmiatano śnieg,***

#### ***który rozsypując się w powietrzu tworzył śnieżycę, ku niemałej uciesze bawiących się na ulicy***

#### ***dzieci.***

#### ***Ściany domów, a zwłaszcza ich okna, wydawały się czarne, nie tylko w porównaniu z białym***

#### ***całunem śniegu na dachach, ale i z brudnym śniegiem na jezdniach, w którym ciężkie koła***

#### ***wozów i pojazdów wyorały głębokie bruzdy. Krzyżowały się one w najrozmaitszych kierunkach***

#### ***tworząc istny labirynt wąskich kanałów w brunatnym, zakrzepłym błocie i przemienionej w lód***

#### ***wodzie.***

#### 

#### ***Niebo było pochmurne, nawet najkrótsze ulice ginęły w gęstej mgle, która opadała na ulice w***

#### ***postaci szronu. W całym otoczeniu nie było nic wesołego – a jednak unosiło się w powietrzu coś***

#### ***uroczystego i radosnego; nawet najpiękniejsza letnia pogoda i promienie słońca nie zdołałyby***

#### ***wytworzyć podobnego nastroju.***

#### ***Również robotnicy zmiatający śnieg z dachów byli pogodni. Nawoływali się wzajem z***

#### ***dachów, od czasu do czasu rzucali jeden w drugiego kulą śniegową – poczciwszy to pocisk***

#### ***aniżeli niejedno słówko – i zanosili się śmiechem zarówno trafiając do celu, jak w razie***

#### ***chybienia.***

#### ***Niektóre sklepy spożywcze były otwarte, natomiast owocarnie imponowały bogactwem.***

#### ***Widać było ogromne, pękate kosze kasztanów, przypominające swoją wypukłością brzuchy***

#### ***starych smakoszów. Ustawiono je w drzwiach sklepów i wydawało się, że lada chwila wypadną***

#### ***na ulicę. Czerwonawe, przysadziste główki hiszpańskiego czosnku zdawały się spoglądać***

#### ***wyzywająco na skromnie snujące się dziewczęta. One zaś tylko spod oka spoglądały na wiszące***

#### ***wszędzie girlandy uwite z gałązek świerku. Dalej piętrzyły się apetyczne piramidy jabłek i***

#### ***gruszek. Ówdzie ułożono stosy winogron, budzących ślinkę w ustach. Dalej umieszczono całe***

#### ***stosy ciemnych, puszkiem okrytych orzechów, przypominających swoim aromatem zapomniane***

#### ***przechadzki po lasach. Tutaj pieczone, suszone i świeże jabłka norfolskie, prześlicznie***

#### ***wyglądające na tle cytryn i pomarańcz zdawały się wręcz napraszać, aby je zawinięto w papier i***

#### ***zabrano do domu na deser. Złote i srebrne rybki, chociaż zimnokrwiste, teraz wystawione w***

#### ***małych, szklanych akwariach, wśród bogactwa owoców, jakby odgadywały, że dzieje się coś***

#### ***niezwykłego, gdyż z wielkim wzburzeniem przepływały tam i z powrotem swoje siedziby.***

#### ***A sklepy kolonialne... Co tam za skarby! Chociaż drzwi do niektórych sklepów były tylko do***

#### ***połowy uchylone, to przez szpary można było podziwiać ich zasoby. Zwracały tam uwagę nie***

#### ***tylko wesołe szczękania talerzy wag; nie tylko furkot sznurków, szybko odwijanych z żelaznych***

#### ***kółek, aby nimi zręcznie owinąć paczki zakupionych towarów; nie tylko nieustanny brzęk***

#### ***blaszanych szufelek, nabierających kawę lub herbatę; nie tylko dźwięk wydawany przez***

#### ***różnorodne paczki, rzucane na kontuar, które zjawiały się i znikały, jak kule w rękach żonglera...***

#### ***Nade wszystko zwracał uwagę zmieszany aromat kawy i herbaty, tak przyjemny dla***

#### ***powonienia. Pięknie pachniały stosy czerwonych, dużych rodzynków i śnieżnobiałych migdałów;***

#### ***góry cynamonu i innych aromatycznych korzeni; owoce smażone w cukrze, których sam widok***

#### ***łaskotał podniebienie; festony mięsistego i soczystego winogrona; koszyki pełne skromnie***

#### ***zarumienionych śliwek francuskich. Słowem – wszystkie te przeróżne smaczne rzeczy,***

#### ***przedstawiane w najponętniejszych postaciach...***

#### ***Główną uwagę zwracali kupujący, jakby niecierpliwie pragnący wypełnić dziś od dawna***

#### ***wymyślony plan. Tłoczyli się w drzwiach, uderzając jeden drugiego koszykami i paczkami,***

#### ***zapominając na kontuarze część zakupów i szybko wracając po nie; popełniając wiele pomyłek i***

#### ***przeoczeń z niezwyczajną dobrodusznością. Jednocześnie trzeba było podziwiać cierpliwość***

#### ***kupca i jego pomocników, ich uprzejmość, ugrzecznienie, z jakim starali się dziś zwracać do***

#### ***wszystkich. Zdawało się, że gdybyś od nich zażądał serca, bez wahania ofiarowaliby je z równą***

#### ***skwapliwością, jak herbatę lub kawę.***

#### ***Wtem zabrzmiały dzwony, wzywające pobożnych do kościoła. Wkrótce ulice zaroiły się***

#### ***ludźmi, którzy przywdzieli nie tylko odświętne szaty, ale także uroczyste, świąteczne miny.***

#### ***Jednocześnie z bocznych ulic, uliczek i zaułków bez nazwy wypłynęło mnóstwo ludzi, którzy***

#### ***nieśli swój obiad do piekarza, aby go odgrzać.***

#### ***Widok tych biednych, a jednak tak szczęśliwych w tej chwili, zdawał się najwięcej***

#### ***interesować ducha, zatrzymał się bowiem wraz ze Scrooge’em przy drzwiach jednej z piekarń i***

#### 

#### ***podnosząc pokrywy naczyń w chwili gdy ludzie przechodzili obok niego, oświetlał ich posiłek***

#### ***swą pochodnią.***

#### ***Była to iście cudowna pochodnia; gdy bowiem kilku ludzi poczęło się o coś spierać i nawet***

#### ***padły dość ostre wyrazy, duch „pokropił” ich kilkoma kroplami ze światła swej pochodni, a***

#### ***natychmiast wrócił im pogodny nastrój. Przyznawali, że wstyd sprzeczać się w dzień Bożego***

#### ***Narodzenia.***

#### ***Niebawem dzwony umilkły, a sklepy piekarzy zamknięto. W powietrzu unosiły się smaczne***

#### ***zapachy odgrzewanych obiadów, a kominy pieców wyrzucały kłęby dymu pomieszanego z parą.***

#### ***– Zapewne twoja pochodnia ma jakąś szczególną właściwość? – zapytał Scrooge.***

#### ***– Tak, czynienia wszystkiego przyjemnym i dobrym.***

#### ***– Czy działa tak na każdy obiad w tym dniu? – pytał dalej Scrooge.***

#### ***– Na każdy podawany z dobrą wolą. Szczególnie na obiad ubogich.***

#### ***– Dlaczego?***

#### ***– Ponieważ oni tego najwięcej potrzebują.***

#### ***Wciąż niewidzialni, duch wraz ze Scrooge’em, udali się na przedmieście.***

#### ***Duch, pomimo olbrzymiej postaci, wszędzie dostawał się z łatwością, i zarówno w niskiej***

#### ***lepiance, jak i we wspaniałej sali pałacu przedstawiał się imponująco.***

#### ***Być może powodowany radością, jaką odczuwał z posiadania władzy, a może powodowany***

#### ***serdeczną naturą i współczuciem dla biednych – duch zaprowadził Scrooge’a, wciąż***

#### ***trzymającego się jego szaty, do mieszkania jego pomocnika. Na progu duch zatrzymał się z***

#### ***uśmiechem i pobłogosławił mieszkanie Boba Cratchita światłem ze swej pochodni.***

#### ***Pomyślcie – Bob miał tylko piętnaście szylingów na tydzień, które każdej soboty chował do***

#### ***kieszeni, jednak duch błogosławił dzisiejszej nocy jego domowi.***

#### ***Małżonka Cratchita, w ubogiej, dwa razy już przerabianej sukni, przystrojonej tanimi***

#### ***wstążkami, ale wyglądająca wcale ładnie, nakrywała właśnie stół. Pomagała jej córka Belinda. W***

#### ***tym czasie syn Piotr sprawdzał, czy gotują się ziemniaki w garnku. Założył dziś olbrzymi***

#### ***kołnierzyk, który pożyczył od ojca, aby wyglądać świątecznie. Napełniło go to taką dumą, że był***

#### ***nawet w parku, aby pokazać się rówieśnikom.***

#### ***Po chwili wbiegły dwie młodsze latorośle rodziny Cratchit, dziewczynka i chłopczyk,***

#### ***opowiadając głośno, że zza drzwi piekarza doszedł ich zapach pieczonej gęsi i że ta gęś należy do***

#### ***nich. Z wielkiej radości dzieciaki zaczęły tańczyć dookoła stołu, podnosząc Piotra Cratchita pod***

#### ***niebiosa, podczas gdy on dmuchał w ogień, a ziemniaki gotujące się w garnku pukały o pokrywę,***

#### ***jakby błagały, by je wypuszczono i obrano z łupiny.***

#### ***– Gdzie też ojciec tak długo siedzi? – odezwała się pani Cratchit – i twój brat, Tiny Tim? A***

#### ***Marta zeszłorocznej Wigilii przyszła o pół godziny wcześniej.***

#### ***– Oto jest Marta, mateczko – odpowiedziała dziewczyna, która w tej właśnie chwili weszła do***

#### ***pokoju.***

#### ***– Bóg z tobą, drogie dziecko! Jakże późno przychodzisz! – rzekła pani Cratchit, całując córkę***

#### ***a równocześnie zdejmując z niej szal i kapelusz.***

#### ***– Miałyśmy wiele roboty - odparła dziewczyna—na dziś trzeba było wykończyć ją, mamo.***

#### ***– Wszystko już dobrze, skoro jesteś – rzekła pani Cratchit. – Usiądź przy kominku, drogie***

#### ***dziecko, ogrzej się.***

#### ***– Ojciec idzie – odezwało się dwoje najmłodszych dzieci, które zawsze trzymały się razem –***

#### ***schowaj się, Marto, schowaj się!***

#### ***Marta ukryła się, a po chwili wkroczył uroczyście do pokoju Bob, ojciec.***

#### ***Długi szal zwieszał się z szyi, znoszone zaś okrycie było w wielu miejscach połatane i***

#### ***powycierane szczotką, aby ratować jakoś przyzwoity pozór. Na jego barkach siedział Tiny Tim.***

#### 

#### ***Biedny Tiny Tim.***

#### ***W rączkach miał kule do podpierania, a jego członki opasywały metalowe taśmy, które***

#### ***utrzymywały go na słabych nóżkach.***

#### ***– Gdzie nasza Marta? – zapytał Bob Cratchit, rozglądając się po pokoju.***

#### ***– Nie przyjdzie – odrzekła pani Cratchit.***

#### ***– Nie przyjdzie? – powtórzył Bob, tracąc humor. Był w tak dobrym nastroju, że w drodze z***

#### ***kościoła do domu dziarsko galopował, udając konia dla Tiny Tima, który był tym zachwycony.***

#### ***– Nie przyjdzie? – powtórzył raz jeszcze z żalem. – Nie spędzi z nami wieczoru wigilijnego?***

#### ***Marta nie chciała dłużej sprawiać ojcu przykrości. Wyszła z ukrycia i otoczyła rękoma jego***

#### ***szyję. Dwoje małych Cratchitów zajęło się Tiny Timem i zaprowadziło go do kuchni, aby***

#### ***pokazać mu, jak się gotuje świąteczny budyń.***

#### ***– Czy mały Tim dobrze się sprawował? – zapytała matka, gdy już nażartowała się do syta z***

#### ***łatwowierności Boba.***

#### ***– Bardzo dobrze – odrzekł Bob. – To złote dziecko. Nie wiem, jak to się dzieje, może to z***

#### ***powodu przesiadywania w samotności, robi się teraz marzycielem i wymyśla dziwne rzeczy.***

#### ***Dziś, gdy wracaliśmy do domu, powiedział mi, że wszyscy ludzie w kościele zwrócili na niego***

#### ***uwagę dlatego, ponieważ jest kaleką i że kalectwo jego powinno im w dniu Bożego Narodzenia***

#### ***przypomnieć Boga, który sprawił, iż chromi chodzili, a ślepi widzieli.***

#### ***Głos Boba drżał, gdy wymawiał te słowa. Dodał, że Tiny Tim z każdym dniem nabiera sił i***

#### ***energii.***

#### ***Tymczasem dało się słyszeć stukanie kul o podłogę i po chwili do pokoju wrócił mały Tim,***

#### ***któremu pomagało rodzeństwo.***

#### ***Bob zawinął teraz rękawy surduta i wziął się do przygotowania z jałowcówki i cytryn czegoś***

#### ***w rodzaju grogu. Mieszaninę tę rozgrzewał przy ogniu kominka, aby ją doprowadzić do***

#### ***właściwej temperatury.***

#### ***Gdy Bob był zajęty tą ważną czynnością, Piotr w towarzystwie dwójki najmłodszego***

#### ***rodzeństwa wybrał się po gęś, którą niebawem w uroczystym pochodzie wniósł do pokoju.***

#### ***Powstał taki hałas, jak gdyby gęś była najrzadszym ze wszystkich ptaków – upierzonym***

#### ***dziwem, przy którym nawet czarny łabędź byłby czymś zwyczajnym.***

#### ***Istotnie, była ona rzadkim zjawiskiem w tym domu.***

#### ***Pani Cratchit grzała przy kominku zawczasu przygotowany sos, Piotr z ogromnym zapałem***

#### ***przysmażał kartofle, Belinda słodziła kompot z jabłek, Marta ścierała kurz z ogrzanych talerzy,***

#### ***Bob wziął na ręce Tiny Tima i posadził go przy stole obok siebie w najwygodniejszym miejscu.***

#### ***Dwoje małych Cratchitów przystawiło krzesła do stołu; żadne z nich nie zapomniało o sobie i,***

#### ***zająwszy swoje miejsca, powsadzały w buzie łyżki, czekając na gęś.***

#### ***Wreszcie wniesiono potrawy i odmówiono modlitwę. Potem wszyscy zamilkli, wstrzymując***

#### ***oddech w piersiach. Pani Cratchit, przyjrzawszy się doświadczonym okiem ostrzu noża, zabrała***

#### ***się do dzielenia ptaka. Gdy dokonała dzieła, dokoła stołu rozległ się radosny szmer i nawet Tiny***

#### ***Tim, ośmielony przez dwoje małych Cratchitów, uderzył trzonkiem noża o stół i zawołał słabym***

#### ***głosikiem:***

#### ***– Wiwat!***

#### ***Chyba jeszcze nigdy na świecie nie było takiej gęsi. Bob zapewniał, iż uważa to za***

#### ***niemożliwe, aby w ogóle kiedykolwiek upieczono tak smaczną gęś. Jej delikatne mięso, jej***

#### ***wielkość i taniość były przedmiotem ogólnego podziwu. Z dodatkiem kompotu jabłecznego i***

#### ***przysmażonych kartofli stanowiła ona świetne danie dla całej rodziny. Gdy pani Cratchit***

#### ***zauważyła jedną małą kosteczkę pozostawioną na półmisku, oświadczyła, że przecież nie***

#### 

#### ***wszystko zostało spożyte! A każdy z biesiadników jadł, ile chciał! Najlepszym tego dowodem***

#### ***byli malcy, policzki ich bowiem świeciły się od tłuszczu.***

#### ***Teraz Belinda zmieniała talerze, a pani Cratchit poszła przynieść smakowity deser.***

#### ***Nie mogła tego zrobić przy świadkach, gdyż zanadto była przejęta i niespokojna.***

#### ***A nuż budyń się nie udał? Wyobraźmy sobie, że przy wyjmowaniu z piecyka rozpadł się w***

#### ***kawałki! Lub że złodziej wśliznął się do kuchni i ukradł, podczas gdy raczono się gęsią! Na tę***

#### ***myśl dwoje małych Cratchitów pobladło z przerażenia. W ogóle dopuszczano przez chwilę***

#### ***wszelkie możliwe okropności...***

#### ***Halo – chmura pary! Budyń wyjęty z naczynia...***

#### ***Co za przyjemny zapach bije z serwety, w którą go zawinięto. Mieszanina apetycznych woni.***

#### ***Przypominają one trochę kuchnię, trochę piekarnię, a odrobinę pralnię. Takie aromaty wydawał z***

#### ***siebie ów budyń.***

#### ***Wreszcie do pokoju weszła pani Cratchit, wzruszona, ale dumna i uśmiechnięta, niosąc przed***

#### ***sobą budyń, wyrośnięty i duży, oświetlony płomykami zapalonego rumu, ze świąteczną gałązką***

#### ***świerku, wetkniętą w sam środek.***

#### ***O, nadzwyczajny, cudowny budyń!***

#### ***Bob Cratchit spokojnym głosem oświadczył, że uważa go za największe arcydzieło kucharskie***

#### ***pani Cratchit od czasu, kiedy są małżeństwem. Pani Cratchit odpowiedziała na to, że teraz, kiedy***

#### ***ciężar spadł z jej serca, przyznaje, że była bardzo niespokojna, ponieważ zdawało się jej, że***

#### ***wzięła za dużo mąki.***

#### ***Każdy miał coś do powiedzenia, ale nikt nie ośmielił się zauważyć, że był to jednak za mały***

#### ***budyń dla tak licznej rodziny. Byłoby to bluźnierstwem. Każdy członek rodziny wstydziłby się,***

#### ***gdyby mu coś podobnego choćby przyszło do głowy.***

#### ***Wreszcie skończyli ucztę, posprzątano ze stołu i dorzucono węgla do ognia na kominku.***

#### ***Podsycone płomienie zajaśniały weselej niż przedtem.***

#### ***Teraz skosztowano przygotowanego przez Boba grogu i okazało się, że też jest znakomity.***

#### ***Na koniec ustawiono na stole jabłka i pomarańcze, a w ogień rzucono kilka garści kasztanów.***

#### ***Następnie rodzina Cratchitów zasiadła przed kominkiem – jak wyraził się Bob Cratchit – kołem,***

#### ***chociaż było to właściwie półkole: Bob pośrodku, a obok niego cały zapas szklanek.***

#### ***Naczynia te, napełnione gorącym grogiem, wyglądały tak, jak gdyby to były złote puchary.***

#### ***Bob rozlewał napój z promieniejącym wzrokiem, podczas gdy w ogniu podskakiwały i strzelały***

#### ***kasztany. Potem wzniósł toast:***

#### ***– Daj nam Boże, moi drodzy, spędzić szczęśliwie święta! Niech nas Bóg błogosławi!***

#### ***Cała rodzina powtórzyła toast.***

#### ***– Niech Bóg błogosławi nas wszystkich i każdego z osobna! - rzekł jako ostatni Tiny Tim.***

#### ***Siedział tuż obok ojca; na małym krzesełku. Bob trzymał jego małą rączkę w swojej dłoni,***

#### ***chcąc okazać dziecku swoją szczególną dla niego miłość.***

#### ***– Duchu – odezwał się Scrooge ze współczuciem, którego nigdy dotychczas nie doznawał –***

#### ***powiedz mi, czy Tiny Tim będzie żyć?***

#### ***– Widzę próżne krzesło przy kominku – odparł duch – i starannie przechowywane kule bez***

#### ***właściciela. Jeżeli przyszłość nie zmieni tego, dziecko umrze.***

#### ***– Nie, nie! - zawołał Scrooge. – O, dobry duchu, powiedz, że ono będzie żyło...***

#### ***– Jeżeli przyszłość nie zmieni tego obrazu – powtórzył duch – to żaden z moich następców nie***

#### ***zastanie tutaj tego dziecka. O co ci chodzi? Skoro musi umrzeć, to lepiej, żeby umarło zaraz i***

#### ***zmniejszyło przez to nadmiar ludności.***

#### ***Scrooge, słysząc swoje wcześniejsze słowa powtórzone przez ducha, pochylił głowę, przejęty***

#### ***skruchą i żalem.***

#### 

#### ***– Człowieku – rzekł duch – jeśli masz serce a nie kamień, to nigdy nie wypowiadaj tak***

#### ***ohydnych słów, dopóki nie zrozumiesz, czym jest nadmiar ludności i gdzie on się znajduje. Czy***

#### ***ty masz prawo rozstrzygać, którzy ludzie mają żyć, a którzy umrzeć? Być może, iż ty w oczach***

#### ***Stwórcy jesteś o wiele mniej wart życia, niż miliony istot podobnych do tego dziecka, biednego***

#### ***człowieka.***

#### ***Scrooge wysłuchał upomnień ducha w pokorze i spuścił oczy. Naraz usłyszał wymówione***

#### ***swoje nazwisko.***

#### ***– Niech żyje pan Scrooge! – przemówił Bob. – Wypijmy jego zdrowie, gdyż jest on naszym***

#### ***chlebodawcą i jemu zawdzięczamy naszą ucztę!***

#### ***– Jemu zawdzięczamy? – zawołała pani Cratchit z oburzeniem. – Pragnęłabym bardzo, żeby***

#### ***tu się zjawił. Wyprawiłabym mu ucztę po swojemu. Tak jest. Wypowiedziałabym mu w oczy***

#### ***wszystko, co o nim myślę, a spodziewam się, że nie przypadłoby mu to do smaku!***

#### ***– Droga żono, mówisz to przy dzieciach – upomniał ją łagodnie Bob. – Dzisiaj przecież mamy***

#### ***święto Bożego Narodzenia!***

#### ***– Istotnie, tylko w tak wielkie święto można wznosić toast za zdrowie tak podłego skąpca,***

#### ***człowieka bez serca, jakim jest Scrooge – oburzała się w dalszym ciągu pani Cratchit. – Ty***

#### ***wiesz, Robercie, jaki on jest. Nikt nie wie o tym lepiej od ciebie!***

#### ***– Droga żono – powtórzył Bob – dziś święto Bożego Narodzenia! Zastanów się!***

#### ***– A więc wychylę jego zdrowie, uczynię to przez miłość do ciebie i przez wzgląd na dzisiejsze***

#### ***święto – rzekła pani Cratchit. – Niech żyje długie lata! Życzę mu wesołych świąt i szczęśliwego***

#### ***Nowego Roku! Życzę mu tego, ale wątpię, czy się to spełni. Bardzo wątpię...***

#### ***Dzieci, idąc za przykładem matki, wypiły również zdrowie Scrooge’a.***

#### ***Był to pierwszy akt, którego dokonali tego wieczoru bez serdeczności i ciepła, jakby pod***

#### ***naciskiem przymusu. Tiny Tim wypił ostatni, ale nie dodał do tego żadnej uwagi. Widocznie***

#### ***Scrooge był postrachem rodziny. Wymienienie jego nazwiska rzuciło na nich ponury cień, który***

#### ***nie ustąpił przez całe pięć minut.***

#### ***Gdy wreszcie cień ustąpił, byli znów weseli, chyba dziesięć razy bardziej niż przedtem.***

#### ***Bob Cratchit uroczyście oznajmił, że ma obiecane dla Piotra miejsce, które mu przyniesie aż***

#### ***półszósta szylinga tygodniowo. Dwoje małych roześmiało się serdecznie na myśl, że będą***

#### ***widzieli Piotra jako człowieka pracy. Sam Piotr spoglądał w zamyśleniu w ogień, zastanawiając***

#### ***się zapewne nad tym, w jakich papierach ulokuje swoje oszczędności, skoro już znajdzie się w***

#### ***posiadaniu tak bajecznej pensji.***

#### ***Marta, która pracowała u modniarki, opowiadała, jak wiele ma teraz roboty, ile godzin w***

#### ***porze największego ruchu musi pracować i że zamierza jutro wyspać się za wszystkie czasy;***

#### ***będzie to dzień zupełnie wolny. Opowiadała także, iż przed kilku dniami widziała pewną hrabinę***

#### ***i lorda, a lord był prawie tego wzrostu co Piotr. Przy tych jej słowach Piotr podciągnął rogi***

#### ***swego kołnierzyka tak wysoko, że za nimi głowa jego prawie zniknęła.***

#### ***Tymczasem kasztany i poncz krążyły wciąż wśród rozbawionej rodziny, a Tiny Tim zaśpiewał***

#### ***swym cichym głosikiem piosenkę o dziecku zasypanym przez śnieg; śpiewał bardzo ładnie.***

#### ***W tym wszystkim nie było nic szczególnego. W rodzinie tej nie było ani jednej postaci***

#### ***pięknie ubranej. Ich obuwie dawno straciło właściwość nieprzepuszczania wody, ich odzież była***

#### ***podniszczona; dzieci wyglądały biednie, a Piotr z pewnością znał dobrze wnętrze lombardu.***

#### ***Mimo to byli szczęśliwi i przepełnieni wdzięcznością za skromne rozkosze, jakimi ich los***

#### ***obdarzał. Kochali się, panowała wśród nich zgoda i spokój ludzi uczciwych. Scrooge z***

#### ***trudnością oderwał od nich oczy, a zwłaszcza żal mu było rozstawać się z małym Timem.***

#### ***Zrobiło się ciemno i zaczął padać gęsty śnieg. Scrooge i duch szli teraz ulicami Londynu. W***

#### ***oknach domów błyszczały jasne światła. Można było zobaczyć przygotowania do wieczerzy,***

#### 

#### ***bogato nakryte stoły, stosy talerzy, ogrzewanych na gazie, kosztowne okrycia i meble. Oto dzieci***

#### ***wybiegały na pokrytą śniegiem ulicę, aby powitać przybywających gości: siostry i braci,***

#### ***kuzynów, wujów, ciotki; tu i ówdzie na oknach przesuwały się cienie zgromadzonych gości; tam***

#### ***znów dziewczęta, przybrane w futrzane kołnierze i takież buciki, szczebiocząc jedna przez drugą,***

#### ***lekkim krokiem spieszyły do sąsiadów. Biada kawalerom, którzy by teraz rzucili okiem na ich***

#### ***zarumienione twarzyczki i błyszczące, ożywione spojrzenia. Te figlarne czarodziejki wiedziały***

#### ***doskonale, jak są dla tych biedaków niebezpieczne!***

#### ***W każdym domu oczekiwano gości i na każdym kominku płonął wesoły ogień. Duch był***

#### ***bardzo szczęśliwy! Odsłaniał szeroką pierś i otwierał dłoń, hojnie rzucając na wszystko dokoła***

#### ***szczere, poczciwe, szlachetne rozradowanie. Nawet latarnik, przebiegający w odświętnym***

#### ***ubraniu ciemne ulice, aby ich ponurą mgłę rozjaśnić blaskami światła, i właśnie myślący o***

#### ***spędzeniu wieczoru u towarzysza pracy, roześmiał się głośno, gdy duch przeleciał obok niego.***

#### ***Ani się domyślał, że spotkał istotę tak ważną.***

#### ***Wtem, bez żadnego uprzedzenia, znaleźli się na rozległym błotnistym pustkowiu, na którym***

#### ***stały tu i ówdzie ogromne głazy, jak gdyby to było cmentarzysko olbrzymów. Woda, nie mająca***

#### ***tutaj żadnego odpływu, zalałaby całą przestrzeń, gdyby mróz nie ujął jej w lodowe okowy.***

#### ***Oprócz mchu, paproci i twardej, ostrej trawy, nic więcej tu nie rosło. Na zachodzie niknące***

#### ***słońce pozostawiło pas płonącej czerwieni, spoglądającej na to rozpaczliwe pustkowie, niby***

#### ***nabiegłe krwią oko rozjątrzonego tygrysa. Pas ten zapadał się coraz niżej i niżej, aż wreszcie***

#### ***całkiem pogrążył się w ciemnościach nocy.***

#### ***– Gdzie jesteśmy? – zapytał Scrooge.***

#### ***– Tu mieszkają górnicy, pracujący głęboko pod ziemią – odrzekł duch. – Patrz! Poznali mnie.***

#### ***W oknie jakiejś nędznej lepianki błyszczało światło; szybko tam pomknęli.***

#### ***Zastali wesołe towarzystwo siedzące dokoła wielkiego, jasno płonącego ogniska. Zgrzybiały***

#### ***starzec i jego sędziwa żona siedzieli w otoczeniu dzieci, wnuków i prawnuków, wszyscy w***

#### ***odświętnych szatach. Starzec śpiewał pieśń wigilijną głosem, który niekiedy tylko przygłuszał***

#### ***wycie wiatru. Była to bardzo stara pieśń, którą śpiewał jeszcze wówczas, kiedy był małym***

#### ***chłopcem. Od czasu do czasu wszyscy wtórowali mu. Za każdym razem, kiedy zabrzmiały ich***

#### ***głosy, starzec ożywiał się, a jego głos stawał się silniejszy; gdy zaś milkły, jego siły słabły.***

#### ***Duch nie bawił tu długo. Poleciwszy Scrooge’owi, by trzymał się silniej jego opończy, uniósł***

#### ***go w powietrze.***

#### ***Jak myślicie – dokąd go uniósł? Przecież nie na morze.***

#### ***A właśnie na morze!***

#### ***Ku wielkiemu przerażeniu, Scrooge ujrzał znikającą za sobą ziemię, a w dole usłyszał głuchy***

#### ***pomruk pieniących się fal, z wściekłością uderzających o skaliste brzegi.***

#### ***Na posępnej skale, do połowy zanurzonej w wodzie, w odległości mili od stałego lądu, stała***

#### ***samotna latarnia morska. Przez cały rok huczały dokoła niej fale. Ogromne połacie traw***

#### ***morskich osnuwały jej stopy, a mewy, jakby zrodzone z wiatru, unosiły się i opadały w***

#### ***powietrzu dokoła jej szczytu.***

#### ***Dwaj latarnicy rozpalili wewnątrz ogień, który rzucał jasny snop promieni na wzburzoną***

#### ***powierzchnię morza przez otwór w grubym murze latarni.***

#### ***Prości ludzie, którzy rozniecili ogień, wyciągnąwszy zgrubiałe od ciężkiej pracy ręce przez***

#### ***stół, przy którym zasiedli, życzyli sobie wzajem wesołych świąt, trącając się kubkami gorącego***

#### ***grogu. Starszy z nich, o twarzy zniszczonej przez ustawiczne zmiany pogody, pooranej***

#### ***zmarszczkami, podobnej do twarzy figur wyrzynanych ongiś na przodach okrętu, zaśpiewał***

#### ***ochrypłym głosem pieśń wigilijną.***

#### 

#### ***Duch znów uniósł Scrooge’a ponad czarne, piętrzące się morze, aż w końcu zatrzymali się na***

#### ***pokładzie jakiegoś okrętu. Najpierw stanęli przy sterniku, następnie przy strażniku, wreszcie przy***

#### ***oficerach na służbie. Wszystkie te surowe postacie pełniły swoje odpowiedzialne obowiązki i***

#### ***nuciły z cicha pieśń wigilijną bądź myślały o wielkim świecie; wreszcie opowiadały sobie***

#### ***wzajem wspomnienia dawnych świąt, spędzonych wśród rodziny, snując nadzieję rychłego***

#### ***powrotu do swoich.***

#### ***Każdy marynarz znajdujący się na okręcie, czuwający czy śpiący, zły czy dobry, miał w tym***

#### ***dniu dla towarzyszy lepsze, cieplejsze słowo niż kiedykolwiek w roku. Każdy w mniejszym lub***

#### ***większym stopniu doznawał radosnego uczucia, myślał o tych, którzy w tej chwili myślą też o***

#### ***nim.***

#### ***Scrooge przysłuchiwał się żałosnym jękom wichru i rozmyślał, jaka to wspaniała rzecz***

#### ***posuwać się wśród nieprzejrzanej ciemności ukrywającej na swoim dnie wielkie tajemnice.***

#### ***Nagle ze zdumieniem usłyszał głośny śmiech. Zdumienie jego wzrosło, gdy poznał głos***

#### ***siostrzeńca i gdy nie wiadomo jakim sposobem znalazł się w jasnym, ciepłym i schludnym***

#### ***pokoju. Obok niego stał duch i z życzliwym uśmiechem spoglądał na jego siostrzeńca.***

#### ***– Ha, ha, ha! – śmiał się wciąż siostrzeniec Scrooge'a. – Ha, ha, ha!***

#### ***Gdybyś, szanowny Czytelniku, znał człowieka śmiejącego się serdeczniej i szczerzej, to i ja***

#### ***pragnąłbym go poznać.***

#### ***Nie ma nic słuszniejszego i szlachetniejszego nad prawo równowagi, które sprawia, że o ile***

#### ***choroby i smutki udzielają się innym, to również radość i śmiech są zaraźliwe. Moc tego prawa***

#### ***można było właśnie tu zobaczyć. Gdy bowiem siostrzeniec Scrooge’a śmiał się na całe gardło,***

#### ***trzymając się za boki, żona jego śmiała się równie serdecznie, a i zebrani goście nie pozostawali***

#### ***w tyle. Wszyscy trzęśli się od śmiechu, a wraz z nimi zdawał się śmiać cały pokój:***

#### ***– Ha, ha! Ha, ha! Ha, ha!***

#### ***– Jak mnie tu żywym widzicie, powiedział, że wigilia to głupstwo! – wołał siostrzeniec***

#### ***Scrooge’a. – Tak powiedział i jestem przekonany, że rzeczywiście tak myśli.***

#### ***– Tym gorzej dla niego, Fredziu – z oburzeniem zauważyła jego żona. Błogosławione niech***

#### ***będą kobiety: one nic nie czynią połowicznie i zawsze biorą rzeczy na serio.***

#### ***Żona Freda była bardzo ładną kobietą. Miała milutką, naiwną twarzyczkę, z ponętnymi***

#### ***dołkami na policzkach, prześliczne, jakby stworzone do pocałunków usta i najsłoneczniejszą parę***

#### ***ocząt. W jej urodzie było coś zwracającego uwagę, ale w dobrym, szlachetnym znaczeniu.***

#### ***– On jest po prostu starym dziwakiem – ciągnął siostrzeniec Scrooge’a. – Do tego***

#### ***nieznośnym. Mógłby być chociaż cokolwiek milszy. Ale wady człowieka są zawsze karą dla***

#### ***niego samego. Jest to prawda niezbita i pamiętając o tym, nie będę mu czynił wymówek.***

#### ***– Zdaje się, Fredziu, że on jest bardzo bogaty – zauważyła żona. – Przynajmniej ty zawsze tak***

#### ***mówisz.***

#### ***– I cóż z tego, moja droga? – odparł Fred. – Bogactwo jest dla niego bez pożytku; nie używa***

#### ***go na nic dobrego. Sam z niego nie korzysta i nie pomaga nikomu. Odmawia sobie nawet***

#### ***wszelkich wygód. Nigdy mi też na myśl nie przyszło prosić go o jakąkolwiek pomoc. Ha! ha! ha!***

#### ***Ale chyba i on nigdy nie pomyślał o tym, że my kiedyś, wcześniej czy później, odziedziczymy***

#### ***jego skarby...***

#### ***– Nie cierpię go! - rzekła piękna kobieta, a wszyscy goście przyznali, że ma zupełną***

#### ***słuszność.***

#### ***– Co do mnie, nie mam do niego żalu – odezwał się siostrzeniec. – Żal mi go, ale nie***

#### ***mógłbym gniewać się na niego, gdybym nawet chciał. Któż bowiem cierpi przez jego kaprysy?***

#### ***Tylko on sam. Uroiwszy sobie na przykład, że powinien nas nie lubić, nie chciał przyjąć naszego***

#### ***zaproszenia. I jakiż tego rezultat? Uniknął niesmacznego obiadu!***

#### 

#### ***– Tak sądzisz? A mnie się zdaje, że stracił doskonały obiad! – zawołała dotknięta w najczulsze***

#### ***miejsce kobieta.***

#### ***Wszyscy przyłączyli się do jej zdania, a mogli być kompetentnymi sędziami, gdyż przed***

#### ***chwilą właśnie skończyli obiad.***

#### ***– Tym lepiej – rzekł siostrzeniec Scrooge’a. – Bardzo mnie to cieszy, gdyż co do mnie,***

#### ***wyznam szczerze, nie mam wielkiego zaufania do talentów kulinarnych młodych gospodyń. Jak***

#### ***sądzisz, Topper?***

#### ***Topper miał wyraźną słabość do jednej z sióstr żony Fredzla i zapewne dlatego odpowiedział,***

#### ***że będąc kawalerem, a więc niejako pariasem, nie ma prawa wydawać sądu w tym przedmiocie.***

#### ***Usłyszawszy to, owa siostra żony siostrzeńca Scrooge’a, pulchna panienka w koronkowej***

#### ***narzutce, spąsowiała jak piwonia.***

#### ***– Mów dalej, Fredziu – odezwała się żona siostrzeńca Scrooge’a, klaszcząc w dłonie. –***

#### ***Wypowiedz się, skończ, coś zaczął. On zawsze chowa wszystko pod korcem. Dziwny człowiek!***

#### ***Fred w odpowiedzi znowu wybuchnął śmiechem, a ponieważ było fizycznym***

#### ***niepodobieństwem uniknąć tej „zarazy”, więc wszyscy bez wyjątku poszli za jego przykładem.***

#### ***– Pozostaje mi tylko dodać – odezwał się Fred, gdy mu przeszedł paroksyzm śmiechu – że***

#### ***wuj, postąpiwszy z nami tak niegrzecznie i nieżyczliwie, sam się pozbawił pewnej dozy radości,***

#### ***która prawdopodobnie nie zaszkodziłaby mu. Jestem przekonany, że miałby tu towarzyszy***

#### ***milszych od tych, jakich posiada we własnych myślach – przesiadując w starym, zatęchłym***

#### ***kantorze czy w zakurzonych i pustych pokojach. Mam zamiar zapraszać go corocznie, bez***

#### ***względu na to, czy mu się to podoba czy nie, bo mi go żal. Może szydzić z wigilii Bożego***

#### ***Narodzenia do samej śmierci, ale zdaje mi się, że w końcu przekona się do niej, gdy będę chodził***

#### ***do niego co rok i pytał życzliwie: – Wuju Scrooge, jak się miewasz? – Gdyby go to natchnęło***

#### ***myślą zapisania swemu pomocnikowi jakichś pięćdziesięciu funtów, byłbym szczerze***

#### ***zadowolony. Nie jestem pewien, ale zdaje mi się, że wczoraj wuja wzruszyłem.***

#### ***Wszyscy zebrani zaczęli się śmiać z naiwności Freda. On sądził, że mógł wzruszyć Scrooge’a,***

#### ***jak gdyby tego starego kutwę mogło coś na świecie wzruszyć? Ale Fred miał przedziwny***

#### ***charakter. Mało go obchodziło, z czego się towarzystwo śmieje; jego cieszył ten dobry nastrój i***

#### ***aby go podtrzymać, otworzył nową butelkę wina.***

#### ***Po herbacie zaczęła się muzyka, była to bowiem muzykalna rodzina. Wiedzieli, co robią, gdy***

#### ***zaśpiewali chórem. Szczególnie wyróżniał się Topper, który umiał mruczeć basem jak***

#### ***niedźwiedź, a nigdy nie zaczerwienił się przy tym ani nie zeszpecił twarzy nabrzmiałymi żyłami***

#### ***na czole.***

#### ***Siostrzenica Scrooge’a grała wcale nieźle na harfie. Teraz, bez próbowania, uderzyła w struny***

#### ***i zagrała krótką, prostą melodię – tę, którą doskonale znała owa dziewczynka, która zabrała***

#### ***Scrooge’a ze szkoły...***

#### ***Gdy ta melodia zabrzmiała, wszystko, co Scrooge’owi przypomniał duch dawnych Wigilii,***

#### ***stanęło mu teraz przed oczami. Myślał, że gdyby mógł słuchać częściej tej piosenki sprzed lat,***

#### ***stałby się lepszy, i to bez pomocy łopaty grabarza, która pogrzebała Jakuba Marleya.***

#### ***Muzyka jednak nie zajęła całego wieczoru. Gdy już mieli jej dosyć, rozpoczęli zabawę w***

#### ***fanty. Bo dobrze jest czasem wrócić do dzieciństwa, zwłaszcza w dzień wigilijny, który jest***

#### ***przecież wielkim świętem dzieci.***

#### ***Naprzód więc bawiono się w „ciuciubabkę”. Nie chce mi się wierzyć, żeby Topper naprawdę***

#### ***nic nie widział, mając przewiązane oczy; wszakże oczu w trzewikach nie nosił.***

#### ***Moim zdaniem, była to rzecz ułożona pomiędzy nim i siostrzeńcem Scrooge’a; musiał też***

#### ***wiedzieć o tym duch wigilijny.***

#### 

#### ***Sposób, w jaki Topper uganiał się za piękną panienką w białym szaliku, naruszał zasady gry.***

#### ***Przewracając krzesła, obijając się o fortepian, dusząc się pomiędzy firankami, był wszędzie tam,***

#### ***gdzie ona! Wiedział, gdzie ją dopadnie. Nie chwytał nikogo innego. Gdy ktoś wpadł na niego,***

#### ***udawał, że pragnie go chwycić, i szybko zbaczał w kierunku swej ofiary. Na próżno panna***

#### ***kilkakrotnie protestowała, wołając, że sprzeciwia się to zasadom gry, bo Topper w końcu ją***

#### ***złapał, zapędziwszy w róg pokoju, skąd nie było już wyjścia. Jego zachowanie było oburzające.***

#### ***Udawał, że jej nie poznaje, że musi koniecznie dotknąć jej uczesania, upewnić się przez***

#### ***dotknięcie jakiegoś pierścionka na jej palcu i łańcuszka na szyi; to było po prostu występne. Na***

#### ***pewno powiedziała mu o tym, gdy podczas dalszego ciągu zabawy, w której już nie brali udziału,***

#### ***siedzieli i rozmawiali poufnie za firankami.***

#### ***Żona siostrzeńca Scrooge’a nie uczestniczyła w tej grze. Usiadła wygodnie w fotelu ze***

#### ***stołeczkiem pod nogami, w zacisznym kąciku, w którym tuż za nią stali duch i Scrooge.***

#### ***Przyłączyła się jednak do gry w fanty i okazała wiele dowcipu.***

#### ***Również w „sekretarzu” okazała niezwykłą bystrość umysłu i ku wielkiemu zadowoleniu***

#### ***siostrzeńca Scrooge’a pobiła na głowę swoje siostry, chociaż im także nie brakowało sprytu.***

#### ***Towarzystwo składało się coś ze dwudziestu osób, młodych i starych, wszyscy bawili się***

#### ***wybornie. Nawet Scrooge tak się zainteresował zabawą, że zapomniawszy, iż głos jego nie może***

#### ***być słyszany, włączał się często do niej, odgadywał zagadki, zwykle trafnie, gdyż trzeba***

#### ***przyznać, że najostrzejsza, najsubtelniejsza igła nie mogła się porównać z inteligencją Scrooge’a.***

#### ***Wyglądał dobrodusznie, a nawet głupkowato, lecz sam sobie nadawał taki wygląd, ażeby łatwiej***

#### ***móc wyzyskiwać ludzi.***

#### ***Duch był uradowany zmianą jego usposobienia i spoglądał na niego życzliwie; Scrooge prosił***

#### ***go pokornie, jak studencik, aby pozostali do końca zabawy. Ale duch odpowiedział, że nie może***

#### ***tego uczynić.***

#### ***– Zaczęli właśnie nową grę – prosił Scrooge. – Tylko pół godziny jeszcze, duchu, nie więcej!***

#### ***Była to zabawa „Tak i nie”. Siostrzeniec Scrooge’a miał prawo o czymś pomyśleć, a reszta***

#### ***towarzystwa powinna była odgadnąć, co to jest; na wszystkie pytania mógł odpowiadać: „tak”***

#### ***albo „nie”. Pod krzyżowym ogniem pytań musiał się przyznać, że kolejno myślał o zwierzęciu, o***

#### ***żywym zwierzęciu, o niemiłym zwierzęciu, o dzikim zwierzęciu, które czasami mruczało,***

#### ***czasami mówiło, mieszkało w Londynie, chodziło po ulicach, nie było wystawione na widok***

#### ***publiczny. Nie było też przez nikogo wodzone, nie znajdowało się w menażerii, nie było zabijane***

#### ***w rzeźni, nie było koniem, osłem, krową, bykiem, tygrysem, psem, świnią, kotem czy wreszcie***

#### ***niedźwiedziem.***

#### ***Przy każdej niewłaściwej odpowiedzi siostrzeniec wybuchał śmiechem, a nawet zrywał się z***

#### ***kanapy i skakał po pokoju. W końcu jego pulchna szwagierka, wpadłszy również w szał***

#### ***wesołości, zawołała:***

#### ***– Już mam! Wiem, kto to! Wiem!***

#### ***– Więc powiedz...***

#### ***– To twój wujaszek, Scro-o-ge!***

#### ***Zgadła.***

#### ***Wszyscy byli zachwyceni, chociaż ktoś słusznie zauważył, że na pytanie, czy to jest***

#### ***niedźwiedź, odpowiedź powinna była brzmieć: „tak”, ponieważ zaprzeczenie odwróciłoby myśli***

#### ***uczestników zabawy od Scrooge’a, jeśli istotnie o nim by myśleli.***

#### ***– Sprawiedliwość przede wszystkim! – odezwał się siostrzeniec Scrooge’a. – Bawimy się jego***

#### ***kosztem, więc byłoby niewdzięcznością nie wypić jego zdrowia. Dalej! Niech każdy weźmie***

#### ***szklankę wina i... zdrowie wuja Scrooge’a!***

#### ***– Zdrowie wuja Scrooge’a! – zawołali wszyscy.***

#### 

#### ***– Wesołych świąt i szczęśliwego Nowego Roku staruszkowi, jakikolwiek on jest! – ciągnął***

#### ***Fred dalej. – Nie chciał przyjąć ode mnie życzeń, jednak je składam. Niech żyje wuj Scrooge!***

#### ***Wujowi Scrooge zrobiło się tak wesoło i lekko na sercu, że chętnie podziękowałby***

#### ***siostrzeńcowi i całemu towarzystwu, chociażby nieuchwytnym dla nich głosem, gdyby duch***

#### ***pozwolił. Lecz cała scena znikła mu z oczu z ostatnimi słowami siostrzeńca i znów ruszyli dalej.***

#### ***Widzieli wiele ciekawych obrazów, zaszli daleko, odwiedzili wiele ognisk domowych, a***

#### ***wszędzie duch wnosił pogodę umysłu i szczerą radość.***

#### ***Zatrzymywał się przy łożach chorych ludzi, obdarzając ich zdrowiem; pocieszał wygnańców,***

#### ***którzy czuli się wtedy jakby w kraju rodzinnym; zrozpaczonym ciężką walką o byt ukazywał***

#### ***nadzieję lepszej przyszłości, godząc ich z losem; zbliżał się do nędzarzy, którzy zapominali***

#### ***wtedy o swoich cierpieniach.***

#### ***W przytułku, szpitalu, więzieniu, w każdym schronisku nędzy i nieszczęścia, wszędzie***

#### ***zostawiał cząstkę swoich dobrodziejstw, dając w ten sposób Scrooge’owi przykład miłosierdzia.***

#### ***Była to długa noc. Scrooge miał jednak co do tego wątpliwości. Zdawało mu się mianowicie,***

#### ***że w tym czasie, jaki spędza z duchem, było kilka świąt Bożego Narodzenia. Zauważył przy tym***

#### ***dziwną rzecz: w jego własnej powierzchowności nic się nie zmieniło, gdy tymczasem duch***

#### ***starzał się bardzo szybko. Scrooge ani jednym słowem nie napomykał o tym duchowi, dopóki nie***

#### ***spostrzegł, że włosy ducha zupełnie zbielały. Wtedy zapytał:***

#### ***– Czy życie duchów jest tak krótkie?***

#### ***– Moje życie na tym świecie jest bardzo krótkie – odrzekł duch – kończy się bowiem***

#### ***dzisiejszej nocy.***

#### ***– Dzisiejszej nocy!... – powtórzył Scrooge.***

#### ***– Tak, dziś o północy. Dlatego musimy się śpieszyć. Zegary na wieżach wydzwoniły właśnie***

#### ***w tej chwili trzy kwadranse na dwunastą.***

#### ***– Wybacz mi zbyt śmiałe pytanie – rzekł Scrooge, patrząc uparcie na dolny brzeg opończy***

#### ***ducha – lecz spostrzegam pod twoją szatą coś dziwnego, co nie należy do ciebie. Czy to noga,***

#### ***czy łapa zwierzęcia?***

#### ***– Prawdopodobnie łapa, gdyż obrasta ją ciało – brzmiała smutna odpowiedź ducha. – Patrz!***

#### ***Spod opończy wysunęło się dwoje dzieci, dwoje nędznych, przerażających istot. Uklękły one***

#### ***u stóp ducha, trzymając się silnie skraju jego szaty.***

#### ***– Och, człowieku! Spojrzyj, przypatrz się im dobrze! – zawołał duch.***

#### ***Był to chłopiec i dziewczyna. Żółte, chude, obdarte istoty czołgały się w pokorze po ziemi.***

#### ***Zamiast wdzięku dzieciństwa, który powinien był jaśnieć w ich twarzach i zdrowego***

#### ***rumieńca, wyschła ręka czasu pokryła ich lica zmarszczkami, usunęła z nich krew, napiętnowała***

#### ***strasznym zwyrodnieniem. Tam, gdzie powinien był znajdować się wyraz anielski – kryły się złe***

#### ***duchy, rzucając groźne spojrzenia. Nie można sobie wyobrazić bardziej przerażających***

#### ***potworów.***

#### ***Scrooge, blady jak płótno, odwrócił się, lecz obawiając się obrazić ducha, który może był***

#### ***ojcem tych istot, usiłował powiedzieć, że to są przedziwne dzieci; kłamstwo jednak byłoby zbyt***

#### ***rażące – wybełkotał zatem tylko:***

#### ***– Czy to twoje dzieci?***

#### ***– To są dzieci ludzkości! – odparł duch, spoglądając na nieszczęsne istoty z głębokim***

#### ***współczuciem. – Przychodzą one do mnie z błaganiem o obronę przed ich ojcami. To jest –***

#### ***dodał, wskazując na chłopca – Ciemnota, a dziewczynka nosi miano Nędza. Strzeż się obu jak***

#### ***ognia oraz tego wszystkiego, co od nich pochodzi, a przede wszystkim strzeż się chłopca, gdyż***

#### ***na jego czole wypisane jest straszne słowo: Zguba. Możesz się ich wyprzeć – ciągnął dalej duch,***

#### 

#### ***podnosząc głos i wyciągając rękę w kierunku miasta – możesz oburzać się na tych, co to mówią,***

#### ***możesz ich spotwarzać i potępiać: ale jeżeli nie postarasz się o usunięcie tych klęsk, biada ci!***

#### ***– Czy nie ma ratunku dla tych stworzeń? – wyszeptał Scrooge.***

#### ***– Tak – odparł duch z ironią, przypominając mu jego własne słowa – są przecież więzienia, są***

#### ***domy poprawcze!***

#### ***Wybiła północ.***

#### ***Scrooge szukał oczyma ducha, lecz nie mógł go dojrzeć.***

#### ***Z ostatnim uderzeniem zegara przypomniał sobie zapowiedź Jakuba Marleya. Wtedy,***

#### ***podniósłszy oczy, spostrzegł nowego ducha. Miał on postawę majestatyczną, uroczystą, był***

#### ***przybrany w długi, do ziemi sięgający płaszcz z kapturem. Zbliżał się do Scrooge’a powoli,***

#### ***ociężale, jak tuman mgły.***

#### 

#### ***Rozdział 4***

#### ***Ostatnie spotkanie z duchem***

#### ***Gdy widmo zbliżało się do Scrooge’a, on upadł przed nim na kolana. Przybysz wnosił ze sobą***

#### ***coś bardzo tajemniczego i groźnego.***

#### ***Długi, czarny płaszcz, podobny do całunu, szczelnie spowijał całą postać ducha, nawet głowę***

#### ***i twarz, wystawała z niego tylko jedna wyciągnięta ręka. Gdyby nie ta ręka, trudno byłoby***

#### ***dojrzeć postać w nocnej ciemności.***

#### ***Znalazłszy się tuż przy duchu, Scrooge zauważył jego niezwykły wzrost i poczuł, że ogarnia***

#### ***go niewypowiedziana trwoga. Tajemniczy przybysz wciąż milczał, stał w miejscu bez żadnego***

#### ***ruchu.***

#### ***– Zdaje się, że mam przed sobą ducha przyszłych świąt Bożego Narodzenia? – wyszeptał***

#### ***nieśmiało Scrooge.***

#### ***Duch nic nie odpowiedział, ale wciąż trzymał wyciągniętą rękę.***

#### ***– Pokażesz mi rzeczy, które staną się dopiero w przyszłości? Czy nie tak? – zapytał Scrooge.***

#### ***Duch kiwnął potakująco głową. Taką tylko otrzymał odpowiedź.***

#### ***Scrooge już przywykł do obcowania z duchami; jednak w obecności tego milczącego widma***

#### ***doznawał takiego strachu, że nogi się pod nim chwiały. Nie mógł więc podążać za duchem.***

#### ***Zauważywszy to, zjawa zatrzymała się, jakby chcąc mu dać przyjść do równowagi.***

#### ***Zmieszało to Scrooge’a jeszcze bardziej.***

#### ***Za każdym razem, gdy wyczuwał, że oczy widma przenikliwie wpatrują się w niego,***

#### ***przejmowała go groza i dreszcze niewypowiedzianej trwogi. Pomimo wysiłków, nie mógł nic***

#### ***rozróżnić pod tą czarną szatą; widział tylko wciąż wyciągniętą rękę widma i niewyraźne zarysy***

#### ***jego postaci.***

#### ***– Duchu przyszłości – zawołał wreszcie – napełniasz mnie przerażeniem, jakiego nie***

#### ***doznawałem wobec twoich poprzedników. Ponieważ wierzę, iż pragniesz mego dobra i szczerze***

#### ***pragnę poprawić się, dziękuję ci już z góry z całego serca i gotów jestem wszędzie iść za tobą.***

#### ***Ale dlaczego nie przemawiasz do mnie?***

#### ***Żadnej odpowiedzi. Ręka ducha wciąż była wyciągnięta wprost przed siebie.***

#### 

#### ***– Prowadź mnie zatem – rzekł Scrooge. – Czas szybko ucieka, a wiem, że jest dla mnie bardzo***

#### ***drogi. Chodźmy.***

#### ***Duch ruszył powoli, a Scrooge za nim; zdawało mu się, że cień ducha porywa go i***

#### ***podtrzymuje.***

#### ***Nie można powiedzieć, że weszli do miasta – to raczej miasto, wyrósłszy jakby spod ziemi,***

#### ***otoczyło ich nagle szumem i gwarem. Od razu znaleźli się w samym sercu Londynu, na giełdzie,***

#### ***wśród tłumu kupców, spiesznie przechodzących tam i z powrotem, brzęczących pełnymi***

#### ***kieszeniami złota i srebra, zbierających się w niewielkie grupy w celu odbycia narad lub zawarcia***

#### ***transakcji. Wszyscy oni byli bardzo zajęci; spoglądali na zegarki lub, zamyśleni, bawili się***

#### ***kosztownymi brelokami itp. Obraz ten Scrooge znał doskonale, widywał go bardzo często.***

#### ***Duch zatrzymał się przy niewielkiej grupce ludzi. Scrooge zauważywszy, że jego ręka tę***

#### ***właśnie grupkę wskazuje, przybliżył się i usłyszał następującą rozmowę:***

#### ***– Nie – mówił wysoki, tłusty jegomość, z dużym podbródkiem – wiem tylko tyle, że umarł.***

#### ***– Kiedy? – zapytał inny.***

#### ***– Podobno wczoraj w nocy.***

#### ***– Jaki powód? Co mu się stało? – zagadnął trzeci, racząc się obficie tabaką ze srebrnej***

#### ***tabakiery. Sądziłem, że on już nigdy nie umrze.***

#### &#x20;***Bóg raczy wiedzieć, co mu było - odparł pierwszy, ziewając przeciągle.***

#### ***– Ciekawa rzecz, co zrobił z pieniędzmi? – zapytał jegomość z purpurową twarzą i naroślą***

#### ***tłuszczu na końcu nosa, przypominającą korale indyka.***

#### ***– Nie wiem, doprawdy – odparł jegomość z dużym podbródkiem. – Może zapisał swoim***

#### ***wspólnikom... To wiem, że nie ja będę jego spadkobiercą.***

#### ***Dowcip ten przyjęto wybuchem śmiechu.***

#### ***– Zdaje mi się – ciągnął dalej jegomość z podbródkiem – że będzie miał marny pogrzeb.***

#### ***Jestem pewien, że wystrój kościoła i karawanu niedrogo będą kosztowały, bo nie znam nikogo,***

#### ***kto by chciał pójść za jego trumną. A gdybyśmy tak bez zaproszenia odprowadzili go do grobu?***

#### ***– Jeżeli wyprawią porządną stypę, to nie mam nic przeciwko temu – wtrącił jegomość w***

#### ***okularach. – Za takie poświęcenie coś się przecież należy.***

#### ***Gromadka znów się roześmiała.***

#### ***– Jak widzę, jestem najbardziej bezinteresowny – odezwał się jegomość z podbródkiem. –***

#### ***Nigdy nie chodzę na cmentarz i nie ubiegam się o stypy, ale jeżeli który z was wybierze się na***

#### ***ten pogrzeb, ja chętnie będę mu towarzyszyć. Prawdę mówiąc, poniekąd sympatyzowaliśmy ze***

#### ***sobą. Przy spotkaniu zawsze wymienialiśmy choć kilka słów. No, tymczasem do widzenia, moi***

#### ***panowie.***

#### ***Gromadka rozeszła się i zniknęła w tłumie, a Scrooge, który poznał wszystkich***

#### ***rozmawiających, zwrócił oczy na ducha, jak gdyby oczekując wyjaśnienia tego, co usłyszał.***

#### ***Zamiast odpowiedzi, duch pomknął na ulicę i palcem wskazał dwóch rozmawiających***

#### ***mężczyzn.***

#### ***Scrooge znów nadstawił uszu, w nadziei, że teraz zagadka się rozwiąże.***

#### ***Obu mężczyzn wskazanych przez ducha znał dobrze. Byli to bogaci i bardzo wpływowi***

#### ***giełdziarze. Scrooge usilnie zabiegał o pozyskanie ich szacunku i zaufania, oczywiście w***

#### ***znaczeniu czysto giełdowym.***

#### ***– Witam pana – mówił jeden z nich – jak zdrowie?***

#### ***– Niezgorzej – odparł zapytany – a pańskie?***

#### ***– Dziękuję, dobrze. A starego kutwę powołano nareszcie do obrachunku.***

#### ***– Słyszałem o tym. Ale nieznośne zimno dziś mamy...***

#### ***– Przecież to właściwa pora... święta Bożego Narodzenia. Pan nie jeździ na łyżwach?***

#### 

#### ***– Co mi po tym? Mam co innego na głowie. Do widzenia.***

#### ***– Do widzenia.***

#### ***Ani słowa więcej. Takie było ich przywitanie, rozmowa i pożegnanie.***

#### ***Scrooge’a z początku dziwiło, że duch przywiązuje wagę do tak w gruncie rzeczy błahych***

#### ***rozmów, lecz przeczuwając, że czyni to nie bez celu, zaczął się nad nimi zastanawiać.***

#### ***Było niemożliwe – rozmyślał – żeby rozmowy dotyczyły Jakuba Marleya, jego dawnego***

#### ***wspólnika, chociażby z tego tylko względu, że Marley umarł już dawno. Śmierć jego należała do***

#### ***przeszłości, a ten duch przecież miał związek jedynie z przyszłością.***

#### ***Na razie Scrooge nie mógł w żaden sposób wymiarkować, o którym z jego znajomych***

#### ***rozmawiano. Nie wątpił jednak, że kogokolwiek dotyczyły te rozmowy, musiały zawierać naukę,***

#### ***mającą na celu jego dobro, a on powinien przyjąć ją z uwagą i wdzięcznością. Przyszedłszy do***

#### ***tego przekonania, postanowił uważnie przysłuchiwać się wszystkiemu, co mu w uszy wpadnie;***

#### ***przede wszystkim bacznie obserwować własną postać, jeśli się ona zjawi, przewidując, że jej***

#### ***zachowanie da mu klucz do rozwiązania dręczących go pytań. Zaczął więc szukać samego siebie.***

#### ***Któż to zajął jego uprzywilejowane miejsce na giełdzie? Scrooge nie znał tego człowieka.***

#### ***Rozglądał się na wszystkie strony, ale nie mógł odnaleźć siebie, chociaż zegar giełdowy***

#### ***wskazywał godzinę, w której zwykle tu przebywał. Ta okoliczność nie zaniepokoiła go zbytnio,***

#### ***gdyż po odwiedzinach pierwszej zjawy postanowił w głębi duszy, że zmieni dotychczasowy***

#### ***sposób życia; przypuszczał więc, że jego nieobecność na giełdzie potwierdza, iż w postanowieniu***

#### ***swoim wytrwał.***

#### ***Duch, wciąż posępny i nieruchomy, stał przy nim z wyciągniętą ręką. Ocknąwszy się z***

#### ***zamyślenia, Scrooge zauważył, że duch nie spuszcza z niego oczu; dreszcz przebiegł po nim od***

#### ***stóp do głowy.***

#### ***Szybko opuścili gwarną część miasta i zapuścili się w jedną z oddalonych dzielnic, gdzie***

#### ***Scrooge nigdy nie zaglądał, wiedząc, że miała jak najgorszą opinię. Zobaczył ciemne, pełne błota***

#### ***ulice; domy zaś i sklepy były nędzne, mieszkańcy bosi, półnadzy, pijani, budzili obrzydzenie.***

#### ***Podwórza i korytarze nieprawdopodobnie wąskie, zagnojone, wydawały odór, dostrajały się do***

#### ***ludzi, od których tu się roiło. Była to dzielnica błota, nędzy i zbrodni.***

#### ***W tej oto strasznej dzielnicy znajdował się nędzny sklepik, w którym sprzedawano stare***

#### ***żelastwo, gałgany, stare butelki, kości. Na podłodze, wewnątrz sklepu, piętrzyły się stosy***

#### ***zardzewiałych kluczy, gwoździ, łańcuchów, zawiasów, pilników, talerzy wag, odważników.***

#### ***Dziwne tajemnice, których zbadania nie każdy odważyłby się podjąć, ukrywały się pod stosami***

#### ***cuchnących łachmanów.***

#### ***Przy piecu, skleconym niezdarnie z kawałków starych cegieł, w którym spalano szczątki***

#### ***zgniłego drzewa, siedział wśród swoich towarów siedemdziesięcioletni człowiek. Od ulicznego***

#### ***chłodu zasłonił się kotarą z gałganów, które rozwiesił na sznurku. Palił fajkę. Scrooge i duch***

#### ***zjawili się przy nim w chwili, kiedy do sklepu weszła kobieta dźwigająca ciężki tłumok. Tuż za***

#### ***nią, także z tłumokiem, weszła druga, potem mężczyzna, w czarnym, mocno spłowiałym ubraniu.***

#### ***Wszyscy troje niezmiernie się zdziwili, poznawszy się nawzajem.***

#### ***Przez chwilę panowało milczenie, wreszcie owa trójka wybuchnęła głośnym śmiechem.***

#### ***– To dopiero zdarzenie! – zawołała pierwsza kobieta. – Musi być porządek. Najpierw***

#### ***posługaczka, potem praczka, a w końcu przedsiębiorca pogrzebowy. No, patrz, Joe! Zeszliśmy***

#### ***się tu jak umówieni. Nieprawdaż?***

#### ***– W każdym razie nie mogliście wybrać lepszego miejsca na schadzkę – rzekł Joe, wyjmując z***

#### ***ust fajkę. – Chodźcie do salonu. Przecież znamy się wszyscy. Zaczekajcie, zamknę drzwi. Do***

#### ***licha! ale skrzypią... Sądzę, że w całym moim składzie nie można by znaleźć równie***

#### 

#### ***zardzewiałych i skrzypiących zawiasów jak te, i równie starych kości jak moje. Tak, tak.***

#### ***Wszystko jest dobrane, odpowiada swemu miejscu i przeznaczeniu. Ale chodźcie do salonu.***

#### ***Pomieszczenie nazwane „salonem” było częścią sklepu, oddzieloną od niego czymś w rodzaju***

#### ***złachmanionego parawanu.***

#### ***Stary poprawił płonący ogień kawałkiem żelaza, który niegdyś stanowił część ozdobnej***

#### ***poręczy schodów, usunął kopeć z lampy – był bowiem wieczór – cybuchem swej fajki, którą***

#### ***znów wsunął w usta.***

#### ***W tym czasie kobieta, która weszła pierwsza, rzuciła na podłogę swój tłumok, usiadła w***

#### ***swobodnej pozie na stołku i splótłszy dłonie na kolanie spoglądała na dwójkę towarzyszy.***

#### ***– Więc cóż? Przecież wszystko w porządku, moja pani Wilber? – odezwała się po chwili. –***

#### ***Jestem zdania, że każdy człowiek powinien myśleć o sobie. On przez całe życie tylko tym się***

#### ***zajmował.***

#### ***– Święta prawda! – odparła praczka. – Nikt na świecie nie dbał tak o siebie, jak on. Nikt na***

#### ***świecie.***

#### ***– Dlaczegoż więc ma pani takie wystraszone oczy, jakby się czegoś bała? Powiadam, że***

#### ***wszystko w porządku i koniec. Wilki przecież nie rzucają się na siebie, a kruk krukowi oka nie***

#### ***wykole. Byłoby głupio, gdybyśmy mieli przeszkadzać sobie nawzajem w interesach.***

#### ***– Zapewne! - potaknęła pani Wilber.***

#### ***– W takim razie wszystko w porządku – prawiła posługaczka. – Nie wracajmy do dnia***

#### ***wczorajszego, to do niczego nie doprowadzi. Zresztą, czego się obawiać? Trochę drobiazgów***

#### ***nikogo nie zuboży, a nieboszczyk się o nie nie upomni...***

#### ***– Zapewne! Zapewne! – znów potwierdziła pani Wilber.***

#### ***– Gdyby ten podły kutwa chciał uchronić swoje rzeczy od zmarnowania – mówiła***

#### ***posługaczka – mógł uczynić to łatwo, postępując jak wszyscy uczciwi ludzie. Dlaczegóż nie***

#### ***postarał się, żeby w chwili śmierci była przy nim jakaś dobra dusza. Nie chciał tego, nie postarał***

#### ***się, więc zginął marnie w kącie, gorzej niż pies.***

#### ***– Święta prawda! – potwierdziła pani Wilber. – Co posiał, to i zebrał.***

#### ***– Jeszcze więcej bym o nim powiedziała, gdybym nie miała głowy zajętej czym innym – tym,***

#### ***z czym tu przyszłam. No, Joe, rozwiąż tłumok, powiedz, co to warte. Nie obawiam się zacząć***

#### ***pierwsza... Owszem, niech oni wiedzą, co tu jest. Grzechu w tym nie ma. No, Joe, rozwiąż***

#### ***tłumok.***

#### ***Teraz nastąpiły prawdziwie chińskie ceremonie: jej towarzysze pragnęli okazać, iż są dobrze***

#### ***wychowani. W końcu przedsiębiorca pogrzebowy zdecydował się pierwszy przedstawić swoje***

#### ***łupy.***

#### ***Nie były one znaczące: kilka pieczątek, ołówek w futerale, para spinek, tania szpilka do***

#### ***spinania szala. I to było wszystko.***

#### ***Joe każdy przedmiot skrupulatnie badał, nawet obwąchiwał, kredą kreślił na ścianie cenę, a***

#### ***widząc, że już nic więcej nie ma, zsumował nakreślone liczby.***

#### ***– Tyle wynosi twój rachunek, kochany przyjacielu – rzekł do przedsiębiorcy pogrzebowego. –***

#### ***Nie dam ani pensa więcej, choćby mnie smażono na wolnym ogniu. Co dalej?***

#### ***Przyszła kolej na panią Wilber.***

#### ***W jej tłumoku znajdowały się prześcieradła, serwety i trochę ubrania; dalej staroświeckie,***

#### ***srebrne łyżeczki do herbaty, szczypce do cukru i trochę obuwia.***

#### ***Jej rachunek również został zapisany na ścianie.***

#### ***– Zawsze mam względy dla dam i dlatego więcej im płacę. Ta słabość doprowadzi mnie do***

#### ***ruiny – wyrzekał stary Joe. – Twój rachunek, pani Wilber. Jeżeli zażądasz choć o jednego pensa***

#### ***więcej, to gotów jestem cofnąć moją hojność.***

#### 

#### ***– A teraz, Joe – zajrzyj do mojego tłumoka – rzekła posługaczka. Joe ukląkł na ziemi i,***

#### ***rozmotawszy nieskończoną liczbę supłów, wydobył ogromny zwój ciemnej materii.***

#### ***– Co to takiego? – mruknął pod nosem – kotary od łóżka?***

#### ***– Zgadza się – odparła, śmiejąc się, posługaczka.***

#### ***– Czyżbyś, kochana przyjaciółko, ściągnęła firanki, kółka, chwasty, słowem – całe urządzenie,***

#### ***wtedy kiedy jeszcze leżał na łóżku? – zapytał Joe.***

#### ***– Zgadłeś – odparła posługaczka. – Czyżby to nie była odpowiednia pora na to?***

#### ***– W tej sprawie muszę ci oddać sprawiedliwość, droga przyjaciółko – rzekł Joe. – Urodziłaś***

#### ***się w czepku i jesteś na drodze do zrobienia majątku.***

#### ***– Zapewniam cię, ojcze Joe – rzekła poważnie posługaczka – że wobec takiego człowieka***

#### ***wszelkie skrupuły byłyby śmieszne. Tak jest, uważałabym się za naiwną, gdybym nie skorzystała***

#### ***z takiej okazji i niczego sobie nie wzięła. Ostrożnie z lampą, Joe – dodała – zatłuścisz kołdrę***

#### ***oliwą.***

#### ***– To jego kołdra? – zapytał Joe.***

#### ***– A czyja? Nie zaziębi się przecież bez niej i nie dostanie kataru.***

#### ***– Nie o to chodzi – przerwał Joe. – Obawiam się, czy nie umarł na jakąś zaraźliwą chorobę...***

#### ***– Bądź spokojny, ojcze Joe – zapewniła go posługaczka. – Nie byłam tak spragniona jego***

#### ***towarzystwa, żebym się miała narazić na niebezpieczeństwo. Nie kręciłabym się przy nim, gdyby***

#### ***go toczyła jakaś zaraza. Miłe mi jeszcze życie. Przypatrz się tej koszuli, ojcze Joe. Zaręczam, że***

#### ***możesz wypatrzeć oczy, a nie znajdziesz ani jednej dziurki, nawet śladu przetarcia. To najlepsza***

#### ***koszula, jaką nieboszczyk posiadał. Szczęście, że tam byłam, bo inaczej zmarnowaliby ją.***

#### ***– W jaki sposób? – zapytał zaciekawiony Joe.***

#### ***– Włożyliby ją na nieboszczyka i pochowaliby go w niej – odparła śmiejąc się posługaczka. –***

#### ***Znalazł się nawet jakiś głupiec, co ją już włożył na trupa. Spostrzegłam to w samą porę i zdjęłam***

#### ***z niego tę piękną sztukę białego płótna. W perkalu pójść do grobu nie łaska? Sądzę, że perkal jest***

#### ***najstosowniejszy dla nieboszczyków, a szczególnie dla tego starego sknery.***

#### ***Scrooge z przerażeniem przysłuchiwał się tej rozmowie. Ludzie ci, siedzący ciasno, jedno***

#### ***przy drugim, wokół zdobyczy, sprawiali wrażenie drapieżnych zwierząt, budzili w nim taki***

#### ***wstręt, jak bezwstydne demony prowadzące targ o świeżego trupa.***

#### ***– Ha! ha! ha! – rozprawiała w dalszym ciągu posługaczka, zaśmiewając się, podczas gdy Joe***

#### ***wydobywszy z ukrycia flanelowy worek z pieniędzmi, odliczał każdemu z trójki przypadającą***

#### ***należność – to była jedyna dobra rzecz, na jaką zdobył się w całym swoim życiu. Zawsze***

#### ***wszystkich odtrącał od siebie, pewnie po to, żebyśmy mogli pożywić się trochę po jego śmierci.***

#### ***Ha! ha! ha!***

#### ***– Duchu – szepnął Scrooge, drżąc jak w febrze. – Zrozumiałem, wszystko zrozumiałem. Los***

#### ***tego nieszczęśnika może być moim losem. Do takiego końca prowadzi życie jakie pędzę... Boże***

#### ***miłosierny, co ja widzę?!***

#### ***Po tym okrzyku, cofnął się przerażony.***

#### ***Obraz zmienił się nagle i Scrooge znalazł się tuż przy łóżku bez kotar, na którym pod***

#### ***brudnym prześcieradłem ktoś leżał. W straszny sposób wyjaśniało się wszystko, co przed chwilą***

#### ***widział i słyszał.***

#### ***Pokój był ciemny, tak ciemny, że nie można było dokładnie widzieć, co się w nim znajduje,***

#### ***chociaż Scrooge, poruszony jakimś wewnętrznym nakazem, uważnie rozglądał się na wszystkie***

#### ***strony. Słabe światło, przedostające się z zewnątrz padało prosto na łóżko, gdzie leżał trup***

#### ***ograbionego, opuszczonego przez wszystkich człowieka.***

#### 

#### ***Scrooge spojrzał na ducha; jego ręka wskazywała głowę trupa. Ciało było tak niedbale okryte,***

#### ***że wystarczyło jedno dotknięcie, aby ją odsłonić. Scrooge chciał to uczynić, pragnął zobaczyć***

#### ***twarz nieboszczyka, ale brakło mu sił.***

#### ***„O zimna, straszna śmierci! Możesz tu sobie wznieść tron i otoczyć go wszystkimi***

#### ***okropnościami, jakimi rozporządzasz, gdyż to jest twoje królestwo... Lecz nie jesteś w stanie***

#### ***skazić jednego włosa na głowie miłowanej; nie możesz skazić ani jednego rysu szlachetnej***

#### ***twarzy. Cóż z tego, że ręka takiego człowieka stężeje i bezwładna opadnie? Co z tego, że jego***

#### ***krew stężeje a serce przestanie bić? Ta ręka była otwarta, hojna i dobroczynna; to serce czuło i***

#### ***kochało gorąco.”***

#### ***Nikt tych słów nie wymówił, a jednak Scrooge dokładnie je słyszał, gdy patrzył na leżącego***

#### ***na łóżku nieboszczyka.***

#### ***– Gdyby ten człowiek ożył – myślał Scrooge – gdyby mógł rozpocząć nowe życie, co by***

#### ***powiedział o swojej przeszłości? Skąpstwo, chciwość, pragnienie wzbogacenia się... wszystko to***

#### ***sprawiło tak straszny koniec!***

#### ***Zastygły trup leży pod złachmanionym prześcieradłem, opuszczony w ponurym i pustym***

#### ***domu, i nie ma na świecie człowieka, który by powiedział: „On wyświadczył mi kiedyś***

#### ***przysługę, powiedział mi dobre słowo, kiedy potrzebowałem pociechy, teraz odwdzięczę mu się***

#### ***za to.”***

#### ***Kot tylko drapał do drzwi i gdzieś pod podłogą głośno harcowały myszy. Dlaczego mącą***

#### ***ciszę? Scrooge nie śmiał roztrząsać tych pytań.***

#### ***– Duchu – rzekł w końcu – to straszne miejsce. Nigdy nie zapomnę nauki, jaką tu otrzymałem.***

#### ***Chodźmy stąd!***

#### ***Lecz duch wciąż wskazywał mu ręką głowę trupa.***

#### ***– Wiem, duchu, czego żądasz ode mnie – szepnął Scrooge – lecz nie mogę tego spełnić, brak***

#### ***mi sił! Zdawało się, że duch bacznie przyjrzał mu się spod kaptura.***

#### ***– O, duchu! – zawołał Scrooge – jeżeli istnieje chociaż jeden człowiek, którego śmierć tego***

#### ***nieszczęśnika zmartwiła, pokaż mi go, błagam cię!***

#### ***Duch rozpostarł nad nim całun, jakby skrzydła, po czym opuścił go, i w chwilę potem Scrooge***

#### ***ujrzał jasny, słoneczny pokój, a w nim matkę z dziećmi.***

#### ***Matka oczekiwała kogoś z wielkim niepokojem; chodziła od okna do okna, wzdrygała się przy***

#### ***najmniejszym szeleście, wyglądała na ulicę, spoglądała na zegar ścienny. Na próżno próbowała***

#### ***zająć się robotą i z wyraźnym zniecierpliwieniem znosiła krzyki rozbawionych dzieci.***

#### ***Wreszcie usłyszała oczekiwane stuknięcie w drzwi.***

#### ***Podbiegła, by je otworzyć.***

#### ***Był to jej mąż, człowiek jeszcze młody, lecz już znużony i sterany ciężkim życiem. Jego twarz***

#### ***miała w tej chwili dziwny wyraz: malowała się na niej radość, której jakby się wstydził i chciał ją***

#### ***ukryć.***

#### ***Zasiedli do stołu, aby spożyć obiad, przygrzewany na piecu. Żona zapytała nieśmiało:***

#### ***– No i jakie nowiny?***

#### ***On milczał, wyraźnie zwlekał z odpowiedzią.***

#### ***– Dobre, czy złe? – delikatnie ponaglała żona.***

#### ***– Złe – odparł.***

#### ***– Więc jesteśmy zrujnowani?***

#### ***– Nie, Karolino, jest jeszcze nadzieja.***

#### ***– Czy on poczeka? – spytała ona. – Byłby to prawdziwy cud, ale po nim czegoś takiego***

#### ***spodziewać się nie można.***

#### ***– On już nic nie może zrobić. Umarł.***

#### 

#### ***Żona była dobrą, zacną kobietą; wystarczyło spojrzeć na nią, żeby się o tym przekonać. Po***

#### ***tym, co usłyszała od męża, poczuła taką ulgę, że podziękowała za nią Bogu, chociaż zaraz***

#### ***ogarnął ją żal i wstyd, że się poddała takiemu egoizmowi. W każdym razie jej pierwsze wrażenie***

#### ***było radosne.***

#### ***– Więc – rzekła do męża – owa na pół pijana baba, o której wspomniałam ci wczoraj,***

#### ***powiedziała mi prawdę, kiedy usiłowałam dostać się do niego, żeby wyprosić chociaż tydzień***

#### ***zwłoki. On naprawdę umarł. Zdawało mi się, że umyślnie skłamała, aby mnie się pozbyć.***

#### ***– Jak myślisz? – zapytał mąż. – Kto teraz przejmie nasz dług?***

#### ***– Nie wiem. W każdym razie, zanim ureguluje się sprawa spadku, znajdziemy potrzebne***

#### ***pieniądze. Musiałby nas prześladować szczególny pech, gdyby jego spadkobierca okazał się***

#### ***równie nieludzki. Na razie możemy spać spokojnie.***

#### ***Wielki ciężar jakby spadł im z serca. Nawet twarzyczki dzieci, przysłuchujących się rozmowie***

#### ***rodziców, której przecież dokładnie nie rozumiały, zajaśniały radością. Śmierć tego człowieka***

#### ***wniosła odrobinę szczęścia do biednego domu.***

#### ***– Duchu – odezwał się Scrooge – pokaż mi śmierć, której towarzyszy miłość i żal. Inaczej ów***

#### ***straszny pokój, któryśmy niedawno opuścili, wciąż będzie mnie prześladował.***

#### ***Duch powiódł go przez kilka dobrze mu znanych ulic. W drodze Scrooge rozglądał się na***

#### ***wszystkie strony, w nadziei, że zobaczy swą postać, ale daremnie.***

#### ***Weszli do domu biednego Boba Cratchita, do tego samego mieszkania, które Scrooge***

#### ***niedawno odwiedził. Zastali tam matkę z dziećmi.***

#### ***W pokoju panowała cisza. Zwykle swawolne maluchy, braciszek i siostra, siedziały teraz***

#### ***cichutko w kącie pokoju i nie spuszczały oczu z Piotra, pochylonego nad otwartą książką. Matka***

#### ***i starsza córka szyły.***

#### ***„On zaś wziął dziecko i postawił wśród nich”.***

#### ***Kto wypowiedział te słowa? Przecież to nie sen, Scrooge słyszał je wyraźnie? Widocznie Piotr***

#### ***je odczytał głośno w chwili, gdy duch ze Scrooge’em przestępowali próg pokoju. Dlaczego***

#### ***chłopiec tak nagle przerwał czytanie?***

#### ***Matka położyła robotę na stole i zakryła twarz dłońmi.***

#### ***– Oczy mnie bolą od koloru tej tkaniny... – szepnęła. Od koloru tkaniny? O, biedny, maleńki***

#### ***Tim!...***

#### ***– Już mi lepiej – rzekła po chwili. – Prawdopodobnie szycie przy świetle męczy moje oczy,***

#### ***ale nie chcę, żeby ojciec to zauważył. Zapewne niedługo wróci. Powinien już być w domu.***

#### ***– To prawda – potwierdził Piotr, zamykając książkę. – Czy zauważyłaś, mamo, że ojciec teraz***

#### ***chodzi znacznie wolniej niż dawniej?***

#### ***Zapanowała przykra cisza. Wreszcie matka spokojnie, głosem, który raz tylko zadrżał,***

#### ***powiedziała:***

#### ***– Pamiętam, jak chodził szybko, nawet bardzo szybko z... maleńkim Timem na plecach...***

#### ***– Ja także - szepnął Piotr. Wszyscy kolejno powtórzyli:***

#### ***– I ja także.***

#### ***– Bo przecież Tim nie był ciężki – mówiła dalej matka, pochylając się nad robotą. – Przy tym***

#### ***tak bardzo go kochał, że nawet nie czuł jego ciężaru. Zdaje się, że ojciec wraca...***

#### ***Pani Cratchit poderwała się i szybko pobiegła na spotkanie męża. Bob wszedł do pokoju.***

#### ***Szyję miał owiniętą wełnianym szalikiem, a bardzo go ten biedak potrzebował. Herbata już***

#### ***grzała się dla niego, a dwoje najmłodszych dzieci od razu wdrapało się na kolana ojca i przytuliły***

#### ***twarzyczki do jego twarzy, jak gdyby chciały powiedzieć:***

#### ***– Nie myśl już o tym, tatusiu! Nie martw się!...***

#### 

#### ***Bob wesoło bawił się z nimi, dla każdego zresztą miał dobre słowo. Spostrzegłszy rozłożoną***

#### ***na stole robotę, chwalił pracowitość i zręczność żony i córek.***

#### ***– Skończycie to przed niedzielą – zauważył. – Dzielne z was robotnice.***

#### ***– Niedziela? – powtórzyła żona. – Więc dziś tam byłeś, Robercie?***

#### ***– Tak, moja droga – odpowiedział Bob. – Bardzo żałowałem, że nie poszłaś ze mną. Jak tam***

#### ***się wszystko zieleni. Ale ty często tam chodzisz, więc wiesz, jak tam jest pięknie. Ja przyrzekłem***

#### ***sobie, że będę go odwiedzać w każdą niedzielę... Moje maleństwo!***

#### ***Po tych słowach Bob się rozpłakał. Tak kochał małego Tima, że na jego wspomnienie nie***

#### ***mógł się powstrzymać od łez.***

#### ***Wstał i poszedł do pokoju na górze, oświetlonego i przyozdobionego zielenią, jak na dzień***

#### ***wigilijny. Przy łóżeczku dziecka stało krzesełko i można było wyczuć, że jeszcze niedawno ktoś***

#### ***na nim siedział. Teraz Bob tam usiadł i oddał się bolesnym myślom. Kiedy się uspokoił,***

#### ***ucałował łóżeczko, a jego twarz przybrała spokojny wyraz – człowieka pogodzonego z ciężkim***

#### ***ciosem. Wrócił na dół już w innym nastroju.***

#### ***Teraz wszyscy usiedli wokół kominka i zaczęli gwarzyć. Matka i córki wciąż pracowały. Bob***

#### ***z ożywieniem opowiadał o szczególnej życzliwości jaką mu okazał siostrzeniec Scrooge’a,***

#### ***którego spotkał na ulicy. Widział go tylko raz jeden, i to przelotnie, tymczasem dziś, gdy się***

#### ***spotkali, siostrzeniec Scrooge’a przywitał go serdecznie i zapytał, czy nie spotkało go coś złego...***

#### ***– Oczywiście – mówił Bob – nie mogłem tego ukryć przed nim. To miły, dobry człowiek. Czy***

#### ***uwierzysz, droga żono, że bardzo się tym przejął. Powiedział mi: „Szczerze panu współczuję,***

#### ***panie Cratchit, i proszę przekazać moje serdeczne ubolewanie zacnej małżonce”. Nawiasem***

#### ***mówiąc, nie pojmuję, skąd on wie o tym?***

#### ***– O czym, mój drogi?***

#### ***– Że jesteś zacna i dobra.***

#### ***– Wszyscy o tym wiedzą! – zawołał Piotr.***

#### ***– Dobrze powiedziane, mój chłopcze – pochwalił go ojciec. – Mam nadzieję, że tak jest***

#### ***naprawdę. „Szczerze wam obojgu współczuję, moi państwo” – powtórzył siostrzeniec Scrooge’a***

#### ***i wręczając mi swój bilet, nadmienił: „Oto mój bilet. Może będę mógł być panu w czymkolwiek***

#### ***pomocny, proszę zwrócić się do mnie z całą otwartością”. Byłem wprost oczarowany, nie tyle***

#### ***jego propozycją i nie myślą o tym, że może nam istotnie dopomóc, lecz jego uprzejmością.***

#### ***Bardzo mnie tym ujął. Mógłby kto pomyśleć, że znał Tima i żałuje go na równi z nami.***

#### ***– Jestem pewna, że ma dobre serce – rzekła pani Cratchit.***

#### ***– Byłabyś jeszcze bardziej przekonana, gdybyś go widziała i rozmawiała z nim – podchwycił***

#### ***Bob. – Wcale bym się nie dziwił – uważajcie, co powiem! – gdyby pomógł Piotrowi znaleźć***

#### ***lepszą pracę.***

#### ***– Słyszysz, Piotrze? – rzekła pani Cratchit.***

#### ***– A wtedy – zawołała jedna z dziewcząt – Piotr się ożeni i zamieszka u siebie!***

#### ***– Co ty wygadujesz... – mruknął Piotr niby z oburzeniem, ale po jego oczach widać było, że***

#### ***uśmiecha mu się ta myśl.***

#### ***– Nie ma w tym nic niezwykłego – rzekł Bob – chociaż, prawdę mówiąc, masz jeszcze na to***

#### ***dosyć czasu, mój drogi. Lecz jeżeli kiedykolwiek przyjdzie nam się rozstać z sobą, jestem***

#### ***przekonany, że żaden z nas nie zapomni małego Tima. Prawda, że wszyscy będziemy zawsze***

#### ***pamiętali to pierwsze rozstanie?***

#### ***– Zawsze, ojcze! - odpowiedzieli wszyscy.***

#### ***– Wiem o tym, moi drodzy – ciągnął Bob – jak również i o tym, że przez pamięć o nim, jaki***

#### ***był dobry, kochający, cierpliwy i łagodny, chociaż tak mały, nigdy żadna waśń nas nie poróżni.***

#### ***– Z pewnością, ojcze! – znów odpowiedzieli wszyscy.***

#### 

#### ***– Dziękuję wam – rzekł Bob. – Jestem bardzo szczęśliwy! Pani Cratchit ucałowała go, potem,***

#### ***kolejno, ucałowały go dzieci, wreszcie uścisnął jego rękę Piotr.***

#### ***Nad tą zacną rodziną unosił się, jak błogosławieństwo Boże, duch maleńkiego Tima.***

#### ***– Duchu – odezwał się Scrooge – coś mi mówi, że chwila naszego rozstania zbliża się. Czuję***

#### ***to, chociaż nie wiem, jak się to odbędzie. Powiedz mi teraz, kim był ten człowiek, którego***

#### ***widzieliśmy na śmiertelnym łożu?***

#### ***Duch Wigilii przyszłości poprowadził go w taki sam sposób, jak wcześniej prowadził do***

#### ***dzielnicy giełdowej. Teraz posuwał się bardzo szybko, nie zatrzymując się nigdzie. Ten pośpiech***

#### ***niepokoił Scrooge’a. Zaczął prosić, aby się chociaż na chwilę zatrzymał.***

#### ***– Na tej ulicy – tłumaczył się – przez którą tak pędzimy, znajduje się mój kantor. Tu ogniskują***

#### ***się wszystkie moje interesy. Oto dom, w którym jest mój kantor. Pozwól mi zobaczyć, co się tam***

#### ***będzie działo w przyszłości.***

#### ***Duch zatrzymał się, lecz wskazywał ręką w inną stronę.***

#### ***– Przecież mój dom jest tutaj? – zauważył Scrooge. – Dlaczego wskazujesz inne miejsce i***

#### ***chcesz mnie tam prowadzić?***

#### ***Nieubłagany duch wciąż trzymał wyciągniętą rękę wskazującą inny kierunek.***

#### ***Scrooge jednak pobiegł do okna swego kantoru i chciwie przylgnął do szyby. W lokalu i teraz***

#### ***był kantor, ale już nie jego. Zmieniło się umeblowanie, a na miejscu szefa siedział ktoś nieznany.***

#### ***Ręka ducha wciąż nie zmieniała kierunku.***

#### ***Scrooge wrócił do zjawy i posłusznie udał się za nią, starając się rozwiązać w myśli pytanie:***

#### ***dlaczego nie zobaczył siebie w kantorze i co się mogło z nim stać?***

#### ***Nagle zatrzymali się przed żelaznymi sztachetami, wśród których znajdowała się wielka***

#### ***brama. Scrooge uważnie rozejrzał się wokoło, chciał bowiem ustalić, gdzie się znajdują.***

#### ***Byli na cmentarzu.***

#### ***Tu, pod ziemią, na głębokości kilku łokci, leżał ten nieszczęsny człowiek, którego nazwisko***

#### ***miał niebawem poznać.***

#### ***Cmentarz otaczało nieskończone mnóstwo ścian domów, a cała jego powierzchnia zarośnięta***

#### ***była trawami i chwastami – roślinami śmierci, a nie życia.***

#### ***Duch, stojąc wśród mogił, wskazywał na jedną z nich.***

#### ***Scrooge, drżąc cały, zbliżył się do niej.***

#### ***Duch pozornie wcale się nie zmienił, lecz Scrooge’owi zdawało się, iż w jego ponurej,***

#### ***majestatycznej postaci spostrzega coś nowego, co go do głębi poruszało...***

#### ***– Zanim zbliżę się do grobowca, który mi wskazujesz – rzekł – odpowiedz mi na jedno jedyne***

#### ***pytanie. Chcę mianowicie wiedzieć, czy to, co widzę, jest obrazem tego, co musi się spełnić, czy***

#### ***też tego, co może nastąpić?***

#### ***Zamiast odpowiedzi, duch dotknął ręką mogiły, przy której stali.***

#### ***– Zapewne – mówił Scrooge dalej – człowiek w życiu musi iść tą drogą, jaką sam obrał i dojść***

#### ***do pewnych, odpowiadających jej, rezultatów. Ale jeżeli człowiek opuści dawną swoją drogę i***

#### ***skieruje się na inną, to przecież osiągnie też i inny rezultat. Powiedz, czy takie znaczenie mają***

#### ***obrazy, jakie mi pokazałeś? Duch wciąż stał nieruchomy, wskazując grobowiec. Scrooge, drżąc***

#### ***całym ciałem ze strachu, niemal pełznąc, przysunął się do grobowca i przeczytał na nim swoje***

#### ***własne nazwisko:***

#### ***EBENEZER SCROOGE***

#### ***– Więc to samego siebie widziałem?! – zawołał, padając na kolana. Teraz palec ducha***

#### ***przesuwał się, raz po raz, od jego osoby do mogiły.***

#### 

#### ***– Nie, duchu! O, nie! – zawołał Scrooge. Duch wciąż powtarzał ten sam ruch ręką.***

#### ***– Duchu! – krzyknął Scrooge, chwytając płaszcz widma. – Wysłuchaj mnie... Ja już nie jestem***

#### ***tym człowiekiem, jakim byłem do chwili spotkania się z tobą... Nie jestem i nie będę przenigdy...***

#### ***Dlaczego pokazałeś mi tak straszne rzeczy? Czy dla mnie nie ma już ratunku?***

#### ***Ręka ducha po raz pierwszy zadrżała.***

#### ***– O, dobry duchu! – błagał Scrooge, leżąc u stóp widma z twarzą zwróconą do ziemi. – Zmiłuj***

#### ***się nade mną, ratuj mnie! Powiedz, że jeżeli zmienię życie, to zmienię też obrazy, jakie mi***

#### ***pokazałeś...***

#### ***Ręka widma poruszyła się, jakby przytakująco.***

#### ***– Odtąd z całej duszy będę czcił święta Bożego Narodzenia – przyrzekał ze skruchą Scrooge –***

#### ***i przez cały rok będę na nie z radością czekał. Będę też pamiętał o przeszłości, teraźniejszości i***

#### ***przyszłości. Wszystkie trzy duchy, które mnie odwiedziły, żyć będą we mnie. O, duchu, powiedz,***

#### ***że mogę zetrzeć napis z tego grobowca...***

#### ***Z rozpaczą chwycił dłoń ducha.***

#### ***Ten usiłował ją wydrzeć, ale Scrooge trzymał z całej siły. Duch jednak był silniejszy od niego***

#### ***i uwolnił rękę.***

#### ***Scrooge jeszcze raz wzniósł dłonie, aby znów błagać o zmianę swego losu. Nagle zobaczył, że***

#### ***płaszcz i kaptur widma zmniejszają się, kurczą, aż wreszcie całe zjawisko przemieniło się w***

#### ***poręcz jego własnego łóżka...***

#### 

#### ***Rozdział 5***

#### ***Koniec historii***

#### ***Tak, to była rzeczywiście poręcz jego własnego łóżka. Jeszcze więcej ucieszyło go***

#### ***przekonanie, że ma jeszcze tyle czasu, iż wystarczy go na gruntowne zreformowanie swego***

#### ***życia.***

#### ***– Będę żył, pamiętając o przeszłości, teraźniejszości i przyszłości! – przyrzekał sobie wstając.***

#### ***– Duchy trzech czasów pokonały mnie zupełnie. O, Jakubie Marley! Cześć i błogosławieństwo***

#### ***Niebiosom i wigilii Bożego Narodzenia za ich dobrodziejstwo! Składam im dzięki na kolanach,***

#### ***stary Jakubie Marley; tak jest, na kolanach!***

#### ***Był tak podniecony i ożywiony dobrymi zamiarami, że jego słaby, drżący głos nie odpowiadał***

#### ***sile przepełniających go uczuć. Łkał gwałtownie, a twarz jego zlewały strumienie łez.***

#### ***– Są na swoim miejscu! – zawołał, całując kotary łóżka. – Nikt ich nie zerwał, nikt nie***

#### ***naruszył ich pierścieni. Jestem tutaj, a obrazy tego, co się zdarzyć mogło, mogą jeszcze być***

#### ***rozwiane. Wiem, że one znikną, jestem o tym przekonany.***

#### ***Jego drżące ze wzruszenia ręce nie mogły sobie poradzić z ubraniem; wdziewał rzeczy na***

#### ***lewą stronę, szarpał je, upuszczał, słowem – wyprawiał z nimi istne awantury.***

#### ***– Nie pojmuję doprawdy, co się ze mną dzieje! – mówił, śmiejąc się i płacząc jednocześnie,***

#### ***przy czym wdziewał skarpetki na ręce, stając się podobnym do statui Laokoona opasanego***

#### ***wężami. – Jestem lekki jak piórko; szczęśliwy jak anioł; wesoły jak student; oszołomiony jak***

#### ***pijak! Życzę wszystkim, całemu światu, wesołych świąt i pomyślnego Nowego Roku! Wiwat!***

#### ***W podskokach pobiegł do pokoju bawialnego i tam przystanął zadyszany.***

#### ***– Wszystko w porządku! – wołał, rozglądając się dokoła. – Oto rondelek, w którym***

#### ***odgrzewałem swój kleik! A to drzwi, przez które wszedł duch Marleya! Oto miejsce, gdzie***

#### ***siedział duch świąt dzisiejszych! Okno, z którego patrzyłem na błądzące w powietrzu duchy!***

#### ***Wszystko w porządku! Wszystko na swoim miejscu! To się naprawdę działo! Ha! ha! ha!***

#### ***U człowieka, który przez tyle lat nie wiedział, co to śmiech – teraz brzmiał on dziwnie... Był***

#### ***to jakby początek radosnego uśmiechu przyszłości.***

#### 

#### ***– Nie wiem, którego dziś mamy – mówił sam do siebie Scrooge – nie wiem też, jak długo***

#### ***przebywałem z duchami. Jestem jak nowo narodzone dziecko. Mniejsza z tym. Właściwie pragnę***

#### ***być dzieckiem. Wiwat!...***

#### ***Jego okrzyki przytłumiły dzwony kościelne, które wydobywały z siebie wyjątkowo radosne***

#### ***dźwięki.***

#### ***– Diń, diń, don, bum! Diń, diń, don, bum! Ding, dong! Ding, dong! Cudownie! Wspaniale!***

#### ***Zachwycająco! Pobiegł do okna, otworzył je i wychylił się. Ani mgły, ani wilgoci.***

#### ***Jasny, pogodny, mroźny dzień, jeden z tych, które orzeźwiają i rozweselają duszę, pobudzając***

#### ***krew do szybszego krążenia. Wspaniale!***

#### ***– Co to dziś mamy za dzień? – zapytał przez okno małego chłopca w odświętnym ubraniu,***

#### ***który zatrzymał się przed oknem, bo może chciał się Scrooge’owi przypatrzeć.***

#### ***– Co? – mruknął zdziwiony chłopiec.***

#### ***– Pytam, jaki dzień dziś mamy, mój chłopcze – powtórzył Scrooge.***

#### ***– Dzisiaj? Oczywiście Boże Narodzenie.***

#### ***– Boże Narodzenie? – szepnął Scrooge. – Więc go nie straciłem. Duchy dokonały wszystkiego***

#### ***w ciągu jednej nocy. Pewnie mogą one robić wszystko, co im się żywnie podoba. Kto by w to***

#### ***śmiał wątpić. Hej! Podejdź tu bliżej, miły chłopcze!***

#### ***– Czego pan sobie życzy?***

#### ***– Czy wiesz, gdzie jest sklep z drobiem? Z bitym drobiem? O tam, na rogu drugiej ulicy.***

#### ***– Wiem. Znam doskonale ten sklep.***

#### ***– Mądry chłopak! – szepnął do siebie Scrooge. – Bardzo roztropny chłopak. A głośno dodał:***

#### ***– Nie wiesz przypadkiem, czy nie sprzedali tego wielkiego indyka, który wczoraj wieczorem***

#### ***jeszcze wisiał w oknie wystawy?***

#### ***– Aha, tego, jak nie przymierzając, ja cały?***

#### ***– Dowcipny chłopak! – zachwycał się Scrooge. – Prawdziwa przyjemność rozmawiać z takim***

#### ***malcem... Tak, tak, mój koteczku, ten sam.***

#### ***– Wisi jeszcze.***

#### ***– Czy to możliwe?! - zawołał Scrooge uradowany - A więc biegnij i kup go.***

#### ***– Pan sobie ze mnie żartuje... – wzruszył ramionami chłopiec.***

#### ***– Ależ nie, wcale nie żartuję – zapewniał Scrooge – mówię najzupełniej serio. Idź, kup tego***

#### ***indyka i każ go przynieść tutaj, a ja wskażę, komu go należy doręczyć. Wróć tu ze służącym***

#### ***sklepowym, dostaniesz za to szylinga.***

#### ***Chłopiec pomknął jak kula.***

#### ***– Poślę tego indyka mojemu pomocnikowi – szeptał do siebie Scrooge, zacierając ręce i***

#### ***uśmiechając się wesoło. – Ręczę, że mu nawet na myśl nie przyjdzie, kto mu go przysyła. Indyk***

#### ***jest co najmniej dwa razy tak duży, jak Tiny Tim. Jestem pewien, że Bob nie będzie się gniewał***

#### ***za tę niespodziankę. To się nazywa figiel!***

#### ***Napisał adres niezupełnie pewną ręką, zszedł na dół otworzyć drzwi i czekał tam na indyka.***

#### ***Gdy stał przed drzwiami, uwagę jego zwróciła kołatka.***

#### ***– Poczciwa! Będę cię kochał, dopóki życia mi starczy... – zawołał, głaszcząc ją pieszczotliwie.***

#### ***– Dziwna rzecz, że nigdy przedtem nie zwróciłem na nią uwagi. Jak ona sympatycznie wygląda!***

#### ***Lecz oto indyk. Hej, daj go tutaj! Jak się masz, chłopcze! Życzę ci wesołych świąt.***

#### ***Indyk był ogromny. Trudno było wprost uwierzyć, żeby tak wielki i ciężki ptak mógł się***

#### ***utrzymać na własnych nogach.***

#### ***– Ależ przyjacielu – rzekł Scrooge – nie dodźwigasz go do Camden Town. Musisz wziąć***

#### ***dorożkę.***

#### 

#### ***Mówiąc to odliczył należność za indyka i za dorożkę, śmiejąc się przy tym bez przerwy.***

#### ***Potem wrócił na górę, cały spocony i zadyszany, ale wciąż się jeszcze śmiał.***

#### ***Niełatwo mu przyszło z ogoleniem, ponieważ ręce mu drżały. Wiadomo przecież, że czynność***

#### ***ta wymaga wielkiej uwagi. Ale gdyby nawet odciął sobie brzytwą kawałek nosa, to i wówczas***

#### ***nie straciłby dobrego humoru.***

#### ***Ogoliwszy się, przywdział najlepsze ubranie i wyszedł przejść się nieco.***

#### ***Ludzie już wyroili się z domów i snuli się tłumnie, weseli, ożywieni, jak wtedy, kiedy***

#### ***odbywał wędrówkę po ulicach Londynu z duchem obecnych świąt.***

#### ***Z założonymi w tył rękoma, Scrooge szedł powoli, patrzył na ludzi wesoło się uśmiechał.***

#### ***Miał tak sympatyczną minę, że kilku jegomościów, już w dobrych humorach, zaczepiło go***

#### ***słowami:***

#### ***– Dzień dobry, sir! Życzymy wesołych świąt!***

#### ***Scrooge często potem zapewniał, że nigdy w życiu nie słyszał słów, które by równie***

#### ***przyjemnie brzmiały.***

#### ***Przeszedłszy kilka kroków, spostrzegł idącego naprzeciw poważnego dżentelmena, który***

#### ***odwiedził go wczoraj w kantorze, pytając: „Firma Scrooge i Marley, jeżeli się nie mylę?”***

#### ***Scrooge doznał uczucia wstydu na myśl, że człowiek ten obrzuci go pogardliwym wzrokiem,***

#### ***lecz jednocześnie zrozumiał, jak powinien postąpić. Zbliżył się do niego, chwycił za obie ręce i***

#### ***ściskając je, rzekł;***

#### ***– Witam pana. Jakże zdrowie? Spodziewam się, że wczorajsza kwesta udała się? Nieprawdaż?***

#### ***Pański sposób myślenia jest bardzo szlachetny, zaszczyt panu przynosi. Życzę panu wesołych***

#### ***świąt.***

#### ***– Pan Scrooge?***

#### ***– Tak, to moje nazwisko. Niech mi będzie wolno usprawiedliwić się przed panem... Otóż, czy***

#### ***nie mógłbym prosić pana... Tu Scrooge coś mu szepnął do ucha.***

#### ***– Czyja dobrze usłyszałem? – zawołał tamten oszołomiony. – Drogi panie Scrooge, czy pan to***

#### ***mówi serio?***

#### ***– Najzupełniej serio! – zapewniał Scrooge. – Ani pensa mniej. Przecież płacę stary dług. Więc***

#### ***kiedy mogę się pana spodziewać?***

#### ***– Ale, drogi panie – odpowiedział jegomość, serdecznie ściskając dłoń Scrooge’a – nie wiem***

#### ***doprawdy, jak mam panu dziękować za tak hojną ofia...***

#### ***– Ani słowa o tym – przerwał Scrooge – bardzo pana proszę, niech to zostanie między nami.***

#### ***Zechce mnie pan tylko odwiedzić? Czy mogę na to liczyć?***

#### ***– Ależ z całą pewnością! – zawołał skwapliwie poważny jegomość. Nie ulegało wątpliwości,***

#### ***że ma szczery i niezłomny zamiar jak najrychlej złożyć wizytę Scrooge’owi.***

#### ***– Dziękuję panu – rzekł Scrooge – nieskończenie jestem panu wdzięczny! Do miłego***

#### ***zobaczenia!***

#### ***Wszedł do kościoła, potem przeszedł kilka ulic, uważnie obserwując spotykanych ludzi.***

#### ***Głaskał pieszczotliwie główki mijających go dzieci, wypytywał i hojnie obdarzał żebraków,***

#### ***zaglądał do suteren i w okna mieszkań parterowych. Wszystko mu się nadzwyczajnie podobało.***

#### ***Nigdy nie przypuszczał, żeby zwykła przechadzka mogła dostarczyć takiej przyjemności.***

#### ***Po południu skierował się ku dzielnicy, w której mieszkał jego siostrzeniec.***

#### ***Kilkanaście razy przeszedł przed domem, zanim odważył się wejść do sieni i zapukać do***

#### ***drzwi.***

#### ***– Czy pan w domu, moje dziecko? – zapytał służącej, młodej i ładnej dziewczyny.***

#### ***– W domu, panie.***

#### ***– Gdzie jest?***

#### 

#### ***– W jadalni, razem z panią. Niech pan pozwoli, zaprowadzę.***

#### ***– Dziękuję ci, piękne dziecko, sam pójdę. Pan twój zna mnie dobrze. To rzekłszy, Scrooge***

#### ***zbliżył się do jadalni, ostrożnie nacisnął klamkę i wsunął głowę przez uchylone drzwi.***

#### ***W tej chwili właśnie odbywało się sprawdzanie świątecznie zastawionego stołu. Małżonkowie***

#### ***dokonywali tej czynności skrupulatnie, jak przystoi na młodą parę, która jest zwykle na tym***

#### ***punkcie bardzo wrażliwa i pragnęłaby pod tym względem stać ponad wszelką krytyką.***

#### ***– Fred! – szepnął Scrooge.***

#### ***Żona siostrzeńca nerwowo drgnęła, jakby usłyszała coś bardzo przykrego. Gdyby Scrooge***

#### ***zauważył, że siedziała w wygodnym fotelu, ze stołeczkiem pod nogami, przypatrując się z całą***

#### ***uwagą nakryciu, nigdy nie ośmieliłby się jej zaniepokoić w ten sposób.***

#### ***– Kto tam? – krzyknął Fred. – Któż, u Boga?***

#### ***– To ja, twój wuj, Scrooge. Przychodzę zjeść z wami obiad. Czy mogę wejść?***

#### ***Czy może wejść? Także pytanie! Scrooge powinien był podziękować Bogu, że siostrzeniec z***

#### ***radości nie urwał mu ręki przy powitaniu...***

#### ***Po upływie dziesięciu minut Scrooge czuł się tutaj jak we własnym domu. Niepodobna sobie***

#### ***wyobrazić coś serdeczniejszego nad to, jak go tu przyjęto. Żona Freda nie dała się wyprzedzić***

#### ***mężowi, jak również Topper i mała, pulchna siostra żony Freda, i wszyscy goście, którzy się***

#### ***kolejno zjawiali. Całe towarzystwo było zachwycające, uroczo się bawili, miła harmonia***

#### ***panowała w tym gronie... Prawdziwe szczęście!***

#### ***Nazajutrz Scrooge udał się do kantoru.***

#### ***Wstał wcześniej niż zwykle, gdyż postanowił złapać Boba na spóźnieniu. Bardzo tego pragnął***

#### ***i udało mu się. Miał tę przyjemność. Zegar wybił dziewiątą, a Boba jeszcze nie było. Kwadrans***

#### ***po dziewiątej – jeszcze go nie ma. Spóźnił się o całe osiemnaście i pół minuty. Scrooge otworzył***

#### ***szeroko drzwi swego pokoju, aby widzieć, jak Cratchit będzie się przemykał do swej wyziębionej***

#### ***komórki.***

#### ***Bob już w sieni zdjął kapelusz i szalik, a otworzywszy drzwi – natychmiast usiadł na swoim***

#### ***stołku i jego pióro zaczęło tak szybko posuwać się po papierze, jakby chciało dogonić stracony***

#### ***czas.***

#### ***– A to co? – burknął Scrooge, starając się swemu głosowi nadać ton jak najbardziej surowy. –***

#### ***Jak można tak się opóźniać? Co pan sobie myśli?***

#### ***– Wiem, zawiniłem – szepnął pokornie Cratchit – bardzo pana przepraszam za spóźnienie...***

#### ***– Spóźnienie! – burknął znów Scrooge. – Ja sądzę, że to porządne spóźnienie. Proszę tu do***

#### ***mnie!***

#### ***– Przecież zdarzyło się to tylko raz w ciągu całego roku... – usprawiedliwiał się Cratchit,***

#### ***wychodząc ze swej nory. – Nie powtórzy się to więcej, zapewniam pana. Wczoraj zabawiłem się***

#### ***trochę.***

#### ***– Wszystko to bardzo pięknie – przerwał mu Scrooge – muszę jednak oświadczyć panu, że***

#### ***wcale nie myślę dłużej znosić czegoś podobnego. Dlatego – ciągnął dalej, zeskakując szybko z***

#### ***krzesła i dając Bobowi takiego kuksańca, aż ten zatoczył się do swojej komórki – dlatego...***

#### ***podwyższam panu pensję!***

#### ***Bob, przerażony, rzucił się do linii leżącej na kantorku. Miał zamiar schwycić Scrooge’a za***

#### ***kołnierz, zawołać ludzi i przy ich pomocy wpakować pryncypała w kaftan bezpieczeństwa.***

#### ***Nie doszło do tego.***

#### ***– Życzę ci wesołych świąt, Robercie! – odezwał się Scrooge tak poważnie i tak serdecznie, że***

#### ***nie można było wątpić w szczerość jego słów, tym bardziej, że jednocześnie poklepał Boba po***

#### ***ramieniu z poufałością dobrego przyjaciela. - Z całego serca pragnę, aby tegoroczne święta***

#### ***wynagrodziły ci wszystkie święta, któreś tu ze mną spędził. Tak jest, Robercie, podwyższam ci***

#### 

#### ***pensję i dołożę wszelkich starań, aby postawić na nogi twoją rodzinę, padającą z przepracowania.***

#### ***Rozpatrzymy tę sprawę dziś po południu, przy szklance gorącego grogu. A teraz, Robercie,***

#### ***rozpal ogień na kominku i nie żałuj węgla!***

#### ***Scrooge zrobił więcej niż obiecał. Co zaś do maleńkiego Tima, który wcale nie umarł – stał***

#### ***się dlań drugim ojcem.***

#### ***Zmienił się zupełnie. Odtąd był dobrym przyjacielem i chlebodawcą, słowem – takim***

#### ***człowiekiem jakimi bywali ludzie za dobrych, starych czasów, w dobrym, starym kraju.***

#### ***Niektórzy szydzili z tej zmiany, lecz on nie zwracał na to uwagi. Miał tyle rozumu, że wiedział,***

#### ***iż to, co na świecie dobre zawsze jest przedmiotem szyderstwa ze strony niektórych ludzi. Ich***

#### ***należy uważać za ślepych. Scrooge sądził też, że lepiej, aby kalectwo ujawniało się w postaci***

#### ***zmarszczek dokoła oczu, wywołanych ciągłym uśmiechaniem się do bliźnich, niż w innej mniej***

#### ***przyjemnej postaci. Jego dusza pełna była pogody i radości – i to mu wystarczało do szczęścia. Z***

#### ***duchami więcej spotkań nie miał, natomiast pozawiązywał przyjaźnie z ludźmi i podtrzymywał***

#### ***je, a całe jego życie toczyło się wśród dobrych uczynków. Jakoż mówiono później, że nikt tak***

#### ***przykładnie nie obchodzi świąt Bożego Narodzenia, jak on.***

#### ***Życzę Wam z całej duszy, żeby tak o Was mówiono, drodzy Czytelnicy, a także o mnie i o***

#### ***wszystkich, a wtedy – jak pięknie powiedział maleńki Tim – Bóg będzie błogosławił wszystkim i***

#### ***każdemu z osobna.***

